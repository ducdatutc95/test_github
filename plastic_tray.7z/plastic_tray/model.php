<?php
include('database.php');

// Two m_class
//  + mUser
//  + mEms
class mBase extends database
{
    public function mGet()
    {
        $sql = "SELECT * FROM tableName";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mEdit($a, $b)
    {
        $sql = "UPDATE tableName SET colum1 = '$a', colum2 = '$b' WHERE colum3 = ''";
        $this->setQuery($sql);
        return $this->execute(array($a, $b));
    }

    public function mAdd($a, $b)
    {
        $sql = "INSERT INTO tableName(colum1, colum2) VALUES ('$a', '$b')";
        $this->setQuery($sql);
        return $this->execute(array($a, $b));
    }

    public function mDel()
    {
        $sql = "DELETE FROM tableName";
        $this->setQuery($sql);
        return $this->execute(array());
    }
}

class mUser extends databaseUser
{
    public function mGetUser($token)
    {
        $sql = "SELECT * FROM user WHERE token = '$token'";
        $this->setQuery($sql);
        return $this->loadRow(array());
    }

    public function mLogin($id, $pass)
    {
        $sql = "SELECT * FROM user WHERE id = '$id' AND pass = md5('$pass')";
        $this->setQuery($sql);
        return $this->loadRow(array());
    }

    public function mSetToken($token, $id)
    {
        $sql = "UPDATE user Set token = md5('$token') WHERE id = '$id'";
        $this->setQuery($sql);
        return $this->execute();
    }

    public function mChangePass($id, $newPass)
    {
        $sql = "UPDATE user SET pass = md5('$newPass') WHERE id = '$id'";
        $this->setQuery($sql);
        return $this->execute();
    }

    public function mEditLanguage($user, $language)
    {
        $sql = "UPDATE user SET language = '$language' WHERE manv = '$user'";
        $this->setQuery($sql);
        return $this->execute(array($user, $language));
    }
}

class mEms extends database
{
    public function mGetLanguage($lang)
    {
        $sql = "SELECT id, $lang AS lang FROM plastic_tray__language";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetModel($code_hm, $model, $size, $type)
    {
        $arr = array();
        if ($code_hm != '') $arr[] = "code_hm = '$code_hm'";
        if ($model != '') $arr[] = "model = '$model'";
        if ($size != '') $arr[] = "size = '$size'";
        if ($type != '') $arr[] = "type = '$type'";
        $queryArr = implode(" AND ", $arr);

        $sql = "SELECT * FROM plastic_tray__model";

        if (count($arr) > 0) {
            $sql .= " WHERE " . $queryArr;
        }

        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetRack($name, $position)
    {
        $arr = array();
        if ($name != '') $arr[] = "name = '$name'";
        if ($position != '') $arr[] = "position = '$position'";
        $queryArr = implode(" AND ", $arr);

        $sql = "SELECT * FROM plastic_tray__rack";

        if (count($arr) > 0) {
            $sql .= " WHERE " . $queryArr;
        }

        $this->setQuery($sql);
        return $this->loadAllRows();
    }
}
