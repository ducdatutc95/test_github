<?php
date_default_timezone_set("Asia/Ho_Chi_Minh");
include('model.php');

class cBase
{
    public function cGet()
    {
        $data = new mBase();
        $result = $data->mGet();
        return $result;
    }

    public function cEdit($a, $b)
    {
        $data = new mBase();
        $data->mEdit($a, $b);
    }

    public function cAdd($a, $b)
    {
        $data = new mBase();
        $data->mAdd($a, $b);
    }

    public function cDel()
    {
        $data = new mBase();
        $data->mDel();
    }
}

class cEms
{
    // Start User Query
    public function cGetUser($token)
    {
        $data = new mUser();
        $result = $data->mGetUser($token);
        return $result;
    }

    public function cCheckToken()
    {
        if (isset($_COOKIE['token'])) {
            $token = $_COOKIE['token'];
            $data = new mUser();
            $userInfo = $data->mGetUser($token);

            if (empty($userInfo)) {
                $res = ["status" => false, "data" => "Token Expried. Please login again !"];
            } else {
                $res = ["status" => true, "data" => $userInfo];
            }
        } else {
            $res = ["status" => false, "data" => "Token Expried. Please login again !"];
        }

        return $res;
    }

    public function cLogin($id, $pass)
    {
        $data = new mUser();
        $result = $data->mLogin($id, $pass);
        if ($result) {
            $sTime = date("Y-m-d h:i:s");
            $token = $result->id . $sTime;
            setcookie('token', md5($token), time() + 7 * 24 * 3600);
            $data->mSetToken($token, $id);
            if (isset($_SESSION['logError'])) {
                unset($_SESSION['logError']);
            }
            header('Location:index');
            exit();
        } else {
            echo '<script>alert("Sai Thông Tin Tài Khoản");</script>';
        }
    }

    public function cChangePass($id, $pass, $newpass, $cfpass)
    {
        $data = new mUser();
        $result = $data->mLogin($id, $pass);
        if ($result) {
            if ($newpass == $cfpass) {
                $res = $data->mChangePass($id, $newpass);
                // echo $res;
                echo '<script>alert("Change pass success!");</script>';
                header('Location:index');
                exit();
            } else {
                echo '<script>alert("New pass and Pass confirm do not match");</script>';
                // header('Location:changePass');
                // exit();
            }
        } else {
            echo '<script>alert("Wrong old password");</script>';
            // header('Location:changePass');
            // exit();
        }
    }

    public function cEditLanguage($user, $language)
    {
        $data = new mUser();
        $data->mEditLanguage($user, $language);
    }


    // End User Query


    // Start Main Query
    // Start Main Query
    // Start Main Query
    public function cGetLanguage($lang)
    {
        $data = new mEms();
        $result = $data->mGetLanguage($lang);

        $arr = array();
        foreach ($result as $key) {
            $arr[0][$key->id] =  $key->lang;
        }

        return $arr[0];
    }

    public function cGetModel($code_hm, $model, $size, $type)
    {
        $data = new mEms();
        $result = $data->mGetModel($code_hm, $model, $size, $type);
        return $result;
    }

    public function cGetRack($name, $position)
    {
        $data = new mEms();
        $result = $data->mGetRack($name, $position);
        return $result;
    }



    // End Main Query
}

?>

<!--  -->