<?php
session_start();

include('../controller/_controller.php');
$data = new cEms;

$lang  = isset($_SESSION['lg']) ? $_SESSION['lg'] : 'en';
$translations = $data->cGetLanguage($lang);


$code_hm = isset($_POST['code_hm']) ? $_POST['code_hm'] : '';
$model = isset($_POST['model']) ? $_POST['model'] : '';

$fromTime = isset($_POST['fromTime']) ? $_POST['fromTime'] : '';
$toTime = isset($_POST['toTime']) ? $_POST['toTime'] : '';

$resMain = $data->cGetMainShow($code_hm, $model, $fromTime, $toTime);
// print_r($resMain);
$arrMain = json_encode($resMain);
?>

<table class="table table-hover table-bordered display" id="tableConfigModel" style="min-width: 100%; overflow-x: auto;">
    <thead class="text-center dd_table_thead_color_blue">
        <tr>
            <th>No.</th>
            <th> <?php echo $translations['barcode']; ?> </th>
            <th>Model</th>
            <th> <?php echo $translations['position']; ?> </th>
            <th> <?php echo 'Sub - ' . $translations['position']; ?> </th>
            <th> <?php echo $translations['qty']; ?> </th>
            <th> <?php echo $translations['author']; ?> </th>
            <th> <?php echo $translations['time']; ?> </th>
        </tr>
    </thead>

    <tbody id="mainEx">
    </tbody>
</table>

<div class="modal fade bd-example-modal-xl" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content" id="modal-content">
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        var arrMain = <?php echo $arrMain; ?>;
        // console.log(arrMain);

        var translations = <?php echo json_encode($translations); ?>;

        for (var x in arrMain) {
            arrMain[x]['stt'] = parseInt(x) + 1;
            arrMain[x]['_qty'] = formatNumber(arrMain[x]['qty']);
        }

        tableConfigModel(arrMain, translations);

        $('#dd_container_sidebar_input').click(function() {
            setTimeout(function() {
                $("#tableConfigModel").DataTable().columns.adjust(); // Adjust columns after sidebar toggle
            }, 600); // Delay for sidebar animation
        })
    });

    function tableConfigModel(data_in, translations) {
        var arrDid = [];

        var example = $('#tableConfigModel').DataTable({
            "lengthMenu": [
                [10, -1],
                [10, "All"]
            ],

            "order": [
                [0, "desc"]
            ],

            "responsive": true,

            "scrollX": "auto",

            "scrollY": "600px",
            "scrollCollapse": true,
            "paging": false,

            dom: 'Bfrtip',
            buttons: [
                'excel',
                'selectAll',
                'selectNone',
                {
                    text: ' <i class="fas fa-plus-circle i-right" style="color:blue;"></i> ' + translations['import'],
                    className: 'btnPractice',
                    action: function(e, dt, node, config) {
                        window.open("view/mainImport.php", "_blank", "scrollbars=yes,resizable=yes,top=100,left=100,width=1000,height=500");
                    }
                },
                {
                    text: ' <i class="fas fa-edit i-right" style="color:black;"></i> ' + translations['export'],
                    className: 'btnPractice',
                    action: function(e, dt, node, config) {
                        window.open("view/mainExport.php", "_blank", "scrollbars=yes,resizable=yes,top=100,left=100,width=1000,height=500");
                    }
                },
                {
                    text: ' <i class="fas fa-qrcode i-right" style="color:red;"></i> ' + translations['create'] + ' ' + translations['barcode'],
                    className: 'btnPractice',
                    action: function(e, dt, node, config) {
                        window.open("view/mainCreateBarcode.php", "_blank", "scrollbars=yes,resizable=yes,top=100,left=100,width=1000,height=500");
                    }
                },
                {
                    text: ' <i class="fas fa-upload i-right" style="color:brown;"></i> ' + translations['move_out'],
                    className: 'btnPractice',
                    action: function(e, dt, node, config) {
                        window.open("view/mainMoveOut.php", "_blank", "scrollbars=yes,resizable=yes,top=100,left=100,width=1000,height=500");
                    }
                },
                {
                    text: ' <i class="fas fa-download i-right" style="color:gray;"></i> ' + translations['move_in'],
                    className: 'btnPractice',
                    action: function(e, dt, node, config) {
                        window.open("view/mainMoveIn.php", "_blank", "scrollbars=yes,resizable=yes,top=100,left=100,width=1000,height=500");
                    }
                }
            ],

            data: data_in,
            rowCallback: function(row, data, index) {

            },

            columns: [{
                    data: "stt"
                },

                {
                    data: "barcode"
                },

                {
                    data: "model"
                },
                {
                    data: "sub_position"
                },
                {
                    data: "position"
                },

                {
                    data: "_qty"
                },

                {
                    data: "author"
                },

                {
                    data: "stime"
                }
            ],
            select: {
                style: 'multi'
            }
        });

        example
            .on('select', function(e, dt, type, indexes) {
                var rowData = example.rows(indexes).data().toArray();

                for (var i = 0; i < rowData.length; i++) {
                    var x = arrDid.indexOf(rowData[i]);
                    if (x === -1) //neu ko ton tai
                        arrDid.unshift(rowData[i]); //thi push 
                }
            })

            .on('deselect', function(e, dt, type, indexes) {
                var rowDataUn = example.rows(indexes).data().toArray();

                for (var i = 0; i < rowDataUn.length; i++) {
                    var x = arrDid.indexOf(rowDataUn[i]);
                    arrDid.splice(x, 1);
                }
                // console.log(arrDid);
            })


        // example.columns.adjust().draw();
    }
</script>