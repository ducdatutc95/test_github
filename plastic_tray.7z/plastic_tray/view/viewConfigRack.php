<?php
session_start();

include('../controller/_controller.php');
$data = new cEms;

$lang  = isset($_SESSION['lg']) ? $_SESSION['lg'] : 'en';
$translations = $data->cGetLanguage($lang);


$name = isset($_POST['name']) ? $_POST['name'] : '';
$position = isset($_POST['position']) ? $_POST['position'] : '';

$resRack = $data->cGetRack($name, $position);
// print_r($resRack);
$arrRack = json_encode($resRack);
?>

<table class="table table-hover table-bordered " id="tableConfigRack" style="width: 100%;">
    <thead class="text-center dd_table_thead_color_blue">
        <tr>
            <th>No.</th>
            <th> <?php echo $translations['name']; ?> </th>
            <th> <?php echo $translations['area']; ?> </th>
            <th> <?php echo $translations['width']; ?> </th>
            <th> <?php echo $translations['length']; ?> </th>
            <th> <?php echo $translations['height']; ?> </th>

            <th> <?php echo $translations['o'] . ' ' . $translations['width']; ?> </th>
            <th> <?php echo $translations['o'] . ' ' . $translations['length']; ?> </th>
            <th> <?php echo $translations['o'] . ' ' . $translations['height']; ?> </th>



            <th> <?php echo $translations['author']; ?> </th>
            <th> <?php echo $translations['time']; ?> </th>
        </tr>
    </thead>

    <tbody id="mainEx">
    </tbody>
</table>

<div class="modal fade bd-example-modal-xl" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content" id="modal-content">
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        var arrRack = <?php echo $arrRack; ?>;

        var translations = <?php echo json_encode($translations); ?>;

        for (var x in arrRack) {
            arrRack[x]['stt'] = parseInt(x) + 1;

            var _area = '';
            if (arrRack[x]['area'] == 'STAIR') {
                _area = translations['stair']
            } else if (arrRack[x]['area'] == 'PRODUCTION') {
                _area = translations['production']
            } else {
                _area = 'ERROR';
            }
            arrRack[x]['_area'] = _area;
        }

        tableConfigRack(arrRack, translations);
    });

    function tableConfigRack(data_in, translations) {
        var arrDid = [];

        var example = $('#tableConfigRack').DataTable({
            "lengthMenu": [
                [10, -1],
                [10, "All"]
            ],

            "order": [
                [0, "desc"]
            ],

            "responsive": true,

            "scrollX": "auto",

            "scrollY": "600px",
            "scrollCollapse": true,
            "paging": false,

            dom: 'Bfrtip',
            buttons: [
                'excel',
                'selectAll',
                'selectNone',
                {
                    text: ' <i class="fas fa-plus-circle i-right" style="color:blue;"></i> ' + translations['add'],
                    className: 'btnPractice',
                    action: function(e, dt, node, config) {
                        $.post('view/configRackAdd.php',
                            function(data) {
                                $("#modal-content").html(data);
                                $('#exampleModal').modal('show');
                            });
                    }
                },
                {
                    text: ' <i class="fas fa-edit i-right" style="color:black;"></i> ' + translations['edit'],
                    className: 'btnPractice',
                    action: function(e, dt, node, config) {

                        var arr_len = arrDid.length;
                        if (arr_len == 0) {
                            Notify_Basic_Error(translations['error'], translations['must_select_one_line'] + ' !');
                        } else if (arr_len > 1) {
                            Notify_Basic_Error(translations['error'], translations['just_select_one_line'] + ' !');
                        } else {
                            $.post('view/configRackEdit.php', {
                                    dataPost: arrDid
                                },
                                function(data) {
                                    $("#modal-content").html(data);
                                    $('#exampleModal').modal('show');
                                });
                        }
                    }
                }
            ],

            data: data_in,
            rowCallback: function(row, data, index) {},

            columns: [{
                    data: "stt"
                },

                {
                    data: "name"
                },

                {
                    data: "_area"
                },

                {
                    data: "width"
                },

                {
                    data: "length"
                },

                {
                    data: "height"
                },

                {
                    data: "part_width"
                },

                {
                    data: "part_length"
                },
                {
                    data: "part_height"
                },

                {
                    data: "author"
                },
                {
                    data: "stime"
                }
            ],
            select: {
                style: 'multi'
            }
        });

        example
            .on('select', function(e, dt, type, indexes) {
                var rowData = example.rows(indexes).data().toArray();

                for (var i = 0; i < rowData.length; i++) {
                    var x = arrDid.indexOf(rowData[i]);
                    if (x === -1) //neu ko ton tai
                        arrDid.unshift(rowData[i]); //thi push 
                }
            })

            .on('deselect', function(e, dt, type, indexes) {
                var rowDataUn = example.rows(indexes).data().toArray();

                for (var i = 0; i < rowDataUn.length; i++) {
                    var x = arrDid.indexOf(rowDataUn[i]);
                    arrDid.splice(x, 1);
                }
            })
            .on('dblclick', 'tr', function(e, dt, type, indexes) {
                var dataDb = example.rows(this).data().toArray();
                // console.log(dataDb[0]);

                $.post('view/configRackEdit.php', {
                        dataPost: dataDb
                    },
                    function(data) {
                        $("#modal-content").html(data);
                        $('#exampleModal').modal('show');
                    });
            });
    }
</script>