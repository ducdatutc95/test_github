<?php
date_default_timezone_set("Asia/Ho_Chi_Minh");
$stime = date('Y-m-d H:i:s');

session_start();
$author = "ERROR";
if (isset($_SESSION['id'])) {
    $author = $_SESSION['id'];
}

include('../controller/_controller.php');
$data = new cEms();

$arrDatas = $_POST['arrDatas'];
// print_r($arrDatas);

for ($i = 0; $i < count($arrDatas); $i++) {
    $code_hm = $arrDatas[$i][0];
    $model = $arrDatas[$i][1];
    $qty = $arrDatas[$i][2];
    $qty = intval($qty);

    $data->cAddDestroy($code_hm, $qty, $author, $stime);
}
