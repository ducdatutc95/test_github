<?php
session_start();

include('../controller/_controller.php');
$data = new cEms();

$lang  = isset($_SESSION['lg']) ? $_SESSION['lg'] : 'en';
$translations = $data->cGetLanguage($lang);


if (($_SESSION['type'] != 'TRAY' && $_SESSION['type'] != 'ADMIN')) {
    echo '<span class="dd_no_access__text">' . $translations['no_access'] . ' ! <br> ' . $translations['let_contact_admin_for_support'] . '.</span>';
    exit();
}

// if ($_SESSION['role'] < 2) {
//     echo '<span class="dd_no_access__text">' . $translations['no_access'] . ' ! <br> ' . $translations['let_contact_admin_for_support'] . '.</span>';
//     exit();
// }

$dataPost = $_POST['dataPost'][0];
// print_r($dataPost);

$name = $dataPost['name'];

$resMain = $data->cGetMain($name);
$arrMain = json_encode($resMain);
?>

<div class="modal-header">
    <h5 class="modal-title card-title" style="color: blue; font-size: 2rem; font-weight: 600;"> <?php echo $translations['add'] . ' ' . $translations['rack']; ?>:</h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true" style="font-size: 2rem;">&times;</span>
    </button>
</div>

<div class="modal-body">

    <div class="dd_grid">
        <div class="dd_row">

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6">
                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="add_name" class="dd_input_group_label dd_input_group_label-nowrap"><?php echo $translations['name']; ?></label>
                    </div>

                    <input
                        id="add_name"
                        list="list_name"
                        type="text"
                        placeholder="<?php echo $translations['enter'] . ' ' . $translations['name']; ?>"
                        class="dd_input_group_control" autocomplete="off" value="<?php echo $dataPost['name'] ?>" disabled />
                </div>

                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="add_width" class="dd_input_group_label dd_input_group_label-nowrap"><?php echo $translations['width']; ?></label>
                    </div>

                    <input
                        id="add_width"
                        type="text"
                        placeholder="<?php echo $translations['enter'] . ' ' . $translations['width']; ?> "
                        class="dd_input_group_control" autocomplete="off" value="<?php echo $dataPost['width'] ?>" />
                </div>

                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="add_length" class="dd_input_group_label dd_input_group_label-nowrap"><?php echo $translations['length']; ?></label>
                    </div>

                    <input
                        id="add_length"
                        type="text"
                        placeholder="<?php echo $translations['enter'] . ' ' . $translations['length']; ?> "
                        class="dd_input_group_control" autocomplete="off" value="<?php echo $dataPost['length'] ?>" />
                </div>

                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="add_height" class="dd_input_group_label dd_input_group_label-nowrap"><?php echo $translations['height']; ?></label>
                    </div>

                    <input
                        id="add_height"
                        type="text"
                        placeholder="<?php echo $translations['enter'] . ' ' . $translations['height']; ?> "
                        class="dd_input_group_control" autocomplete="off" value="<?php echo $dataPost['height'] ?>" />
                </div>
            </div>

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6">

                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="add_area" class="dd_input_group_label dd_input_group_label-nowrap"><?php echo $translations['area']; ?></label>
                    </div>

                    <select id="add_area" class="dd_input_group_control">
                        <option value=""></option>
                        <option value="STAIR" <?php if ($dataPost['area'] == 'STAIR') { ?> selected <?php } ?>><?php echo $translations['stair']; ?></option>
                        <option value="PRODUCTION" <?php if ($dataPost['area'] == 'PRODUCTION') { ?> selected <?php } ?>><?php echo $translations['production']; ?></option>
                    </select>
                </div>

                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="add_o_width" class="dd_input_group_label dd_input_group_label-nowrap"><?php echo $translations['o'] . ' ' . $translations['width']; ?></label>
                    </div>

                    <input
                        id="add_o_width"
                        type="text"
                        placeholder="<?php echo $translations['enter'] . ' ' . $translations['width']; ?> "
                        class="dd_input_group_control" autocomplete="off" value="<?php echo $dataPost['part_width'] ?>" />
                </div>

                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="add_o_length" class="dd_input_group_label dd_input_group_label-nowrap"><?php echo $translations['o'] . ' ' . $translations['length']; ?></label>
                    </div>

                    <input
                        id="add_o_length"
                        type="text"
                        placeholder="<?php echo $translations['enter'] . ' ' . $translations['length']; ?> "
                        class="dd_input_group_control" autocomplete="off" value="<?php echo $dataPost['part_length'] ?>" />
                </div>

                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="add_o_height" class="dd_input_group_label dd_input_group_label-nowrap"><?php echo $translations['o'] . ' ' . $translations['height']; ?></label>
                    </div>

                    <input
                        id="add_o_height"
                        type="text"
                        placeholder="<?php echo $translations['enter'] . ' ' . $translations['height']; ?> "
                        class="dd_input_group_control" autocomplete="off" value="<?php echo $dataPost['part_height'] ?>" />
                </div>
            </div>

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6">
                <div class="dd_btn-group">
                    <button
                        class="dd_btn dd_btn--size-small dd_btn--success"
                        id="add_confirm">
                        <?php echo $translations['confirm']; ?>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {

        var arrMain = <?php echo $arrMain; ?>;

        var translations = <?php echo json_encode($translations); ?>;

        $("#add_width").keyup(function(event) {
            var num_old = this.value;
            this.value = formatNumber(num_old);
        })
        $("#add_length").keyup(function(event) {
            var num_old = this.value;
            this.value = formatNumber(num_old);
        })
        $("#add_height").keyup(function(event) {
            var num_old = this.value;
            this.value = formatNumber(num_old);
        })

        $("#add_o_width").keyup(function(event) {
            var num_old = this.value;
            this.value = formatNumber(num_old);
        })
        $("#add_o_length").keyup(function(event) {
            var num_old = this.value;
            this.value = formatNumber(num_old);
        })
        $("#add_o_height").keyup(function(event) {
            var num_old = this.value;
            this.value = formatNumber(num_old);
        })

        $("#add_confirm").click(function() {

            var name = $('#add_name').val().toUpperCase();
            var area = $('#add_area').val();

            var width = $('#add_width').val();
            var length = $('#add_length').val();
            var height = $('#add_height').val();

            var o_width = $('#add_o_width').val();
            var o_length = $('#add_o_length').val();
            var o_height = $('#add_o_height').val();

            if (width != '') {
                width = width.replace(/,/g, '');
                width = parseInt(width);
            }
            if (length != '') {
                length = length.replace(/,/g, '');
                width = parseInt(width);
            }
            if (height != '') {
                height = height.replace(/,/g, '');
                width = parseInt(width);
            }

            if (o_width != '') {
                o_width = o_width.replace(/,/g, '');
                o_width = parseInt(o_width);
            }

            if (o_length != '') {
                o_length = o_length.replace(/,/g, '');
                o_length = parseInt(o_length);
            }

            if (o_height != '') {
                o_height = o_height.replace(/,/g, '');
                o_height = parseInt(o_height);
            }

            var checkMain = arrMain.filter(e => {
                return e.barcode != '';
            })


            if (width == '' || width == 0) {
                Notify_Basic_Error(translations['error'], translations['width'] + ': ' + translations['empty'] + ' ! ' + translations['let_check_again']);
            } else if (length == '' || length == 0) {
                Notify_Basic_Error(translations['error'], translations['length'] + ': ' + translations['empty'] + ' ! ' + translations['let_check_again']);
            } else if (height == '' || height == 0) {
                Notify_Basic_Error(translations['error'], translations['height'] + ': ' + translations['empty'] + ' ! ' + translations['let_check_again']);
            } else if (o_width == '' || o_width == 0) {
                Notify_Basic_Error(translations['error'], translations['o'] + ' ' + translations['width'] + ': ' + translations['empty'] + ' ! ' + translations['let_check_again']);
            } else if (o_length == '' || o_length == 0) {
                Notify_Basic_Error(translations['error'], translations['o'] + ' ' + translations['length'] + ': ' + translations['empty'] + ' ! ' + translations['let_check_again']);
            } else if (o_height == '' || o_height == 0) {
                Notify_Basic_Error(translations['error'], translations['o'] + ' ' + translations['height'] + ': ' + translations['empty'] + ' ! ' + translations['let_check_again']);
            } else if (name == '') {
                Notify_Basic_Error(translations['error'], translations['name'] + ': ' + translations['empty'] + ' ! ' + translations['let_check_again']);
            } else if (area == '') {
                Notify_Basic_Error(translations['error'], translations['area'] + ': ' + translations['empty'] + ' ! ' + translations['let_check_again']);
            } else if (checkMain.length != 0) {
                Notify_Basic_Error(translations['error'], translations['rack'] + ': ' + translations['still'] + ' Tray ! ' + translations['let_check_again']);
            } else {

                $("#add_confirm").remove();

                $.post('view/configRackEditing.php', {
                        name: name,
                        area: area,

                        width: width,
                        length: length,
                        height: height,

                        o_width: o_width,
                        o_length: o_length,
                        o_height: o_height,
                    },
                    function(data) {

                        // alert(data);
                        Notify_Basic_Success(translations['successful'], data);

                        $(".close").click();
                        var modal = document.querySelector(".modal-backdrop.fade.show");
                        if (modal != null) {
                            modal.remove();
                        }

                        loadConfigRack();
                    });

            }
        })
    })
</script>