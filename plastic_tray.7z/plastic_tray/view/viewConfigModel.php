<?php
session_start();

include('../controller/_controller.php');
$data = new cEms;

$lang  = isset($_SESSION['lg']) ? $_SESSION['lg'] : 'en';
$translations = $data->cGetLanguage($lang);


$code_hm = isset($_POST['code_hm']) ? $_POST['code_hm'] : '';
$model = isset($_POST['model']) ? $_POST['model'] : '';
$size = isset($_POST['size']) ? $_POST['size'] : '';
$type_use = isset($_POST['type_use']) ? $_POST['type_use'] : '';


$resModel = $data->cGetModel($code_hm, $model, $size, $type_use);
// print_r($resModel);
$arrModel = json_encode($resModel);
?>

<table class="table table-hover table-bordered " id="tableConfigModel" style="width: 100%;">
    <thead class="text-center dd_table_thead_color_blue">
        <tr>
            <th>No.</th>
            <th>Code HM</th>
            <th>Model</th>
            <th> <?php echo $translations['qty']; ?> </th>
            <th> <?php echo $translations['size']; ?> </th>
            <th> <?php echo $translations['type_usage']; ?> </th>
            <th> <?php echo $translations['author']; ?> </th>
            <th> <?php echo $translations['time']; ?> </th>
        </tr>
    </thead>

    <tbody id="mainEx">
    </tbody>
</table>

<div class="modal fade bd-example-modal-xl" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content" id="modal-content">
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        var arrModel = <?php echo $arrModel; ?>;

       var translations = <?php echo json_encode($translations)?>;

        for (var x in arrModel) {
            arrModel[x]['stt'] = parseInt(x) + 1;

            arrModel[x]['_qty'] = formatNumber(arrModel[x]['qty'])

            // Size
            var _size = "";
            var size = arrModel[x]['size'];
            switch (size) {
                case 'BIG':
                    _size = translations['big'];
                    break;
                case 'MEDIUM':
                    _size = translations['medium'];
                    break;
                case 'SMALL':
                    _size = translations['small'];
                    break;
                default:
                    _size = "FAIL GET SIZE";
            }
            arrModel[x]['_size'] = _size;

            // Type use
            var _type_user = "";
            var type_user = arrModel[x]['type_use'];
            if (type_user == 'SINGLE') {
                _type_user = translations['single_use_short'];
            } else if (type_user == 'MULTIPLE') {
                _type_user = translations['multiple_use_short'];
            } else {
                _type_user = "FAIL TYPE USE";
            }
            arrModel[x]['_type_use'] = _type_user;

        }

        tableConfigModel(arrModel, translations);
    });

    function tableConfigModel(data_in, translations) {
        var arrDid = [];

        var example = $('#tableConfigModel').DataTable({
            "lengthMenu": [
                [10, -1],
                [10, "All"]
            ],

            "order": [
                [0, "desc"]
            ],

            "responsive": true,

            "scrollX": "auto",

            "scrollY": "600px",
            "scrollCollapse": true,
            "paging": false,

            dom: 'Bfrtip',
            buttons: [
                'excel',
                'selectAll',
                'selectNone',
                {
                    text: ' <i class="fas fa-plus-circle i-right" style="color:blue;"></i> ' + translations['add'],
                    className: 'btnPractice',
                    action: function(e, dt, node, config) {
                        $.post('view/configModelAdd.php',
                            function(data) {
                                $("#modal-content").html(data);
                                $('#exampleModal').modal('show');
                            });
                    }
                },
                {
                    text: ' <i class="fas fa-edit i-right" style="color:black;"></i> ' + translations['edit'],
                    className: 'btnPractice',
                    action: function(e, dt, node, config) {

                        var arr_len = arrDid.length;
                        if (arr_len == 0) {
                            Notify_Basic_Error(translations['error'], translations['must_select_one_line'] + ' !');
                        } else if (arr_len > 1) {
                            Notify_Basic_Error(translations['error'], translations['just_select_one_line'] + ' !');
                        } else {
                            $.post('view/configModelEdit.php', {
                                    arrDid: arrDid
                                },
                                function(data) {
                                    $("#modal-content").html(data);
                                    $('#exampleModal').modal('show');
                                });
                        }
                    }
                }
            ],

            data: data_in,
            rowCallback: function(row, data, index) {

            },

            columns: [{
                    data: "stt"
                },

                {
                    data: "code_hm"
                },

                {
                    data: "model"
                },

                {
                    data: "_qty"
                },

                {
                    data: "_size"
                },

                {
                    data: "_type_use"
                },

                {
                    data: "author"
                },

                {
                    data: "stime"
                }

            ],
            select: {
                style: 'multi'
            }
        });

        example
            .on('select', function(e, dt, type, indexes) {
                var rowData = example.rows(indexes).data().toArray();

                for (var i = 0; i < rowData.length; i++) {
                    var x = arrDid.indexOf(rowData[i]['code_hm']);
                    if (x === -1) //neu ko ton tai
                        arrDid.unshift(rowData[i]['code_hm']); //thi push 
                }
            })

            .on('deselect', function(e, dt, type, indexes) {
                var rowDataUn = example.rows(indexes).data().toArray();

                for (var i = 0; i < rowDataUn.length; i++) {
                    var x = arrDid.indexOf(rowDataUn[i]['code_hm']);
                    arrDid.splice(x, 1);
                }
            })
    }
</script>