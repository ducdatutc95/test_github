<?php
date_default_timezone_set("Asia/Ho_Chi_Minh");
$stime = date('Y-m-d H:i:s');

session_start();
$author = "ERROR";
if (isset($_SESSION['id'])) {
    $author = $_SESSION['id'];
}

include('../controller/_controller.php');
$data = new cEms();

$code_hm = $_POST['code_hm'];
$qty_pay = $_POST['qty_pay'];
$qty = $_POST['qty'];

if (intval($qty_pay) > intval($qty)) {
    $data->cEditDecreaseAssy($code_hm, $qty, $author, $stime);
} else {
    $data->cDelAssy($code_hm);
}

$data->cAddAssyExport($code_hm, $qty, $author, $stime);
