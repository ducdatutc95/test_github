<?php
date_default_timezone_set("Asia/Ho_Chi_Minh");
$stime = date('Y-m-d H:i:s');

session_start();
$author = "ERROR";
if (isset($_SESSION['id'])) {
    $author = $_SESSION['id'];
}

include('../controller/_controller.php');
$data = new cEms;

$code_hm =  $_POST['code_hm'];
$model =  $_POST['model'];
$qty =  $_POST['qty'];
$size =  $_POST['size'];
$type_use =  $_POST['type_use'];

$data->cEditModel($code_hm, $model, $qty, $size, $type_use, $author, $stime);

echo "Edit Model: OK";
// echo "Add Model: NG";
?>
