<?php

date_default_timezone_set("Asia/Ho_Chi_Minh");
$stime = date('Y-m-d H:i:s');

session_start();
$author = "ERROR";
if (isset($_SESSION['id'])) {
    $author = $_SESSION['id'];
}

include('../controller/_controller.php');
$data = new cEms();

$im = $_POST['im'];
// print_r($im);

for ($i = 0; $i < count($im); $i++) {
    $barcode = $im[$i]['barcode'];
    $position = $im[$i]['position'];
    $code_hm = $im[$i]['code_hm'];
    $size = $im[$i]['size'];
    $qty = $im[$i]['qty'];

    $data->cEditAddMain($barcode, $position, $code_hm, $size, $qty, $author, $stime);
    $data->cEditCreateBarcode($barcode);
    $data->cAddImport($barcode, $code_hm, $qty, $author, $stime);
}


?>
<!--  -->