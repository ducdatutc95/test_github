<?php
session_start();

include('../controller/_controller.php');
$data = new cEms();

$lang  = isset($_SESSION['lg']) ? $_SESSION['lg'] : 'en';
$translations = $data->cGetLanguage($lang);


if (($_SESSION['type'] != 'TRAY' && $_SESSION['type'] != 'ADMIN')) {
    echo '<span class="dd_no_access__text">' . $translations['no_access'] . ' ! <br> ' . $translations['let_contact_admin_for_support'] . '.</span>';
    exit();
}

// if ($_SESSION['role'] < 2) {
//     echo '<span class="dd_no_access__text">' .$translations['no_access'] . ' ! <br> ' .$translations['let_contact_admin_for_support'] . '.</span>';
//     exit();
// }


$resModel = $data->cGetModel('', '', '', '');
$arrModel = json_encode($resModel);
?>

<div class="modal-header">
    <h5 class="modal-title card-title" style="color: blue; font-size: 2rem; font-weight: 600;"> <?php echo $translations['add']; ?> Model:</h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true" style="font-size: 2rem;">&times;</span>
    </button>
</div>

<div class="modal-body">

    <div class="dd_grid">
        <div class="dd_row">

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6">
                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="add_code_hm" class="dd_input_group_label dd_input_group_label-nowrap">Code HM</label>
                    </div>

                    <input
                        id="add_code_hm"
                        list="list_code_hm"
                        type="text"
                        placeholder="<?php echo $translations['enter']; ?> Code HM"
                        class="dd_input_group_control" autocomplete="off" />
                </div>
            </div>

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6">
                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="add_model" class="dd_input_group_label dd_input_group_label-nowrap">Model</label>
                    </div>
                    <input
                        id="add_model"
                        list="list_model"
                        type="text"
                        placeholder="<?php echo $translations['enter']; ?> Model"
                        class="dd_input_group_control" autocomplete="off" />
                </div>
            </div>

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6">
                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="add_qty" class="dd_input_group_label dd_input_group_label-nowrap "> <?php echo $translations['qty'] . ' ' . $translations['in'] . ' ' . $translations['box'] ?> </label>
                    </div>
                    <input
                        id="add_qty"
                        type="text"
                        placeholder="<?php echo $translations['enter'] . ' ' . $translations['qty'] ?>"
                        class="dd_input_group_control" autocomplete="off" />
                </div>
            </div>

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6">
                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="add_size" class="dd_input_group_label dd_input_group_label-nowrap"> <?php echo $translations['size']; ?> Tray</label>
                    </div>

                    <select id="add_size" class="dd_input_group_control">
                        <option value=""></option>
                        <option value="BIG"><?php echo $translations['big']; ?></option>
                        <option value="MEDIUM"><?php echo $translations['medium']; ?></option>
                        <option value="SMALL"><?php echo $translations['small']; ?></option>
                    </select>
                </div>
            </div>

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6">
                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="add_type_use" class="dd_input_group_label dd_input_group_label-nowrap"><?php echo $translations['type_usage']; ?></label>
                    </div>

                    <select id="add_type_use" class="dd_input_group_control">
                        <option value=""></option>
                        <option value="SINGLE"><?php echo $translations['single_use_short']; ?></option>
                        <option value="MULTIPLE"><?php echo $translations['multiple_use_short']; ?></option>
                    </select>

                </div>
            </div>

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6">
                <div class="dd_btn-group">
                    <button
                        class="dd_btn dd_btn--size-small dd_btn--success"
                        id="add_confirm">
                        <?php echo $translations['confirm']; ?>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {

        var arrModel = <?php echo $arrModel; ?>;
        var translations = <?php echo $translations; ?>;

        $("#add_qty").keyup(function(event) {
            var num_old = this.value;
            this.value = formatNumber(num_old);
        })

        $("#add_confirm").click(function() {

            var code_hm = $('#add_code_hm').val().toUpperCase();
            var model = $('#add_model').val().toUpperCase();
            var size = $('#add_size').val();
            var type_use = $('#add_type_use').val();

            var qty = $('#add_qty').val();
            if (qty != '') {
                qty = qty.replace(',', '');
            }

            var checkCodeHm = arrModel.find(e => {
                return e.code_hm == code_hm;
            })

            var checkModel = arrModel.find(e => {
                return e.model == model;
            })

            if (code_hm == '') {
                Notify_Basic_Error(translations['error'], 'Code HM: ' + translations['empty'] + ' ! ' + translations['let_check_again']);
            } else if (model == '') {
                Notify_Basic_Error(translations['error'], 'Model: ' + translations['empty'] + ' ! ' + translations['let_check_again']);
            } else if (qty == '') {
                Notify_Basic_Error(translations['error'], translations['qty'] + ': ' + translations['empty'] + ' ! ' + translations['let_check_again']);
            } else if (size == '') {
                Notify_Basic_Error(translations['error'], translations['size'] + ': ' + translations['empty'] + ' ! ' + translations['let_check_again']);
            } else if (type_use == '') {
                Notify_Basic_Error(translations['error'], translations['type_usage'] + ': ' + translations['empty'] + ' ! ' + translations['let_check_again']);
            } else if (checkCodeHm != null) {
                Notify_Basic_Error(translations['error'], 'Code HM' + ': ' + translations['exist'] + ' ! ' + translations['let_check_again']);
            } else if (checkModel != null) {
                Notify_Basic_Error(translations['error'], 'Model' + ': ' + translations['exist'] + ' ! ' + translations['let_check_again']);
            } else {

                $.post('view/configModelAdding.php', {
                        code_hm: code_hm,
                        model: model,
                        qty: qty,
                        size: size,
                        type_use: type_use
                    },
                    function(data) {

                        // alert(data);
                        Notify_Basic_Success(translations['successful'], data);

                        $(".close").click();
                        var modal = document.querySelector(".modal-backdrop.fade.show");
                        if (modal != null) {
                            modal.remove();
                        }

                        loadConfigModel();
                    });

            }
        })
    })
</script>