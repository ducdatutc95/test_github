<?php
session_start();


include('../controller/_controller.php');
$data = new cEms();

$lang  = isset($_SESSION['lg']) ? $_SESSION['lg'] : 'en';
$translations = $data->cGetLanguage($lang);

if (($_SESSION['type'] != 'TRAY' && $_SESSION['type'] != 'ADMIN')) {
    echo '<span class="dd_no_access__text">' . $translations['no_access'] . ' ! <br> ' . $translations['let_contact_admin_for_support'] . '.</span>';
    exit();
}

// if ($_SESSION['role'] < 2) {
//     echo '<span class="dd_no_access__text">' .$translations['no_access'] . ' ! <br> ' .$translations['let_contact_admin_for_support'] . '.</span>';
//     exit();
// }

$resModel = $data->cGetModel('', '', '', '');
$arrModel = json_encode($resModel);
?>

<div class="modal-header">
    <h5 class="modal-title card-title" style="color: blue; font-size: 2rem; font-weight: 600;"> <?php echo $translations['import'] . ' ' . $translations['destroy']; ?>:</h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true" style="font-size: 2rem;">&times;</span>
    </button>
</div>

<div class="modal-body">

    <div class="dd_grid">
        <div class="dd_row">

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6">
                <div class="dd_btn-group">
                    <button
                        class="dd_btn dd_btn--size-small dd_btn--success"
                        id="im_confirm">
                        <?php echo $translations['confirm']; ?>
                    </button>
                </div>
            </div>

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6">
            </div>

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6">
                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="im_model" class="dd_input_group_label dd_input_group_label-nowrap">Model</label>
                    </div>
                    <input
                        id="im_model"
                        list="list_model"
                        type="text"
                        placeholder="<?php echo $translations['enter']; ?> Model"
                        class="dd_input_group_control" autocomplete="off" />
                </div>
            </div>

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6">
                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="im_qty" class="dd_input_group_label dd_input_group_label-nowrap "> <?php echo $translations['qty'] . ' Tray'; ?> </label>
                    </div>
                    <input
                        id="im_qty"
                        type="text"
                        placeholder="<?php echo $translations['enter'] . ' ' . $translations['qty'] ?>"
                        class="dd_input_group_control" autocomplete="off" />
                </div>
            </div>

            <div class="dd_col dd_c-12 dd_m-12 dd_l-12">
                <div class="dd_responsive_table">
                    <table class="table table-hover table-bordered " id="tableAssyImport" style="width: 100%;">
                        <thead class="text-center dd_table_thead_color_blue">
                            <tr>
                                <th>No.</th>
                                <th>Code HM</th>
                                <th>Model</th>
                                <th> <?php echo $translations['qty']; ?> </th>
                                <th> <?php echo $translations['delete']; ?> </th>
                            </tr>
                        </thead>

                        <tbody id="assyIm">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {

        var arrModel = <?php echo $arrModel; ?>;
        var translations = <?php echo json_encode($translations); ?>;

        var arrEnter = [];


        $("#im_qty").keyup(function(event) {
            var num_old = this.value;
            this.value = formatNumber(num_old);

            if (event.keyCode === 13) {

                var model = $('#im_model').val().toUpperCase();
                var qty = $('#im_qty').val();

                if (qty != '') {
                    qty = qty.replace(',', '');
                    qty = parseInt(qty);
                }

                var checkModel = arrModel.find(e => e.model == model);

                if (model == '') {
                    Notify_Basic_Error(translations['error'], 'Model: ' + translations['empty'] + ' ! ' + translations['let_check_again']);
                } else if (checkModel == null) {
                    Notify_Basic_Error(translations['error'], 'Model: ' + translations['not_found'] + ' ! ' + translations['let_check_again']);
                } else if (qty == '') {
                    Notify_Basic_Error(translations['error'], translations['qty'] + ': ' + translations['empty'] + ' ! ' + translations['let_check_again']);
                } else {

                    var code_hm = checkModel['code_hm'];

                    var checkEnter = arrEnter.findIndex(e => {
                        return e.code_hm == code_hm;
                    });

                    if (checkEnter >= 0) {
                        arrEnter[checkEnter]['qty'] = parseInt(arrEnter[checkEnter]['qty']) + parseInt(qty);
                    } else {
                        arrEnter.push({
                            "code_hm": code_hm,
                            "model": model,
                            "qty": qty
                        });
                    }

                    $('#assyIm').html('');

                    for (var y in arrEnter) {
                        var stt = parseInt(y) + 1;
                        $('#assyIm').prepend('<tr><td>' + stt + '</td><td>' + arrEnter[y]['code_hm'] + '</td><td>' + arrEnter[y]['model'] + '</td> <td style="width: 200px;"><input type="text" class = "dd_input_group_control_table" value = "' + arrEnter[y]['qty'] + '" disabled></td> <td class = "text-center "><button class = "btn btn-outline-danger btn-sm">&times;</button></td></tr>');
                    }
                }

                assyImportDeleteInput();
            }
        })

        $('#assyIm').on('click', 'tr td button', function() {
            let code_hm = $(this).closest('tr').find('td:eq(1)').text();

            let indexOfIn = arrEnter.findIndex(ee => {
                return ee.code_hm == code_hm;
            });
            arrEnter.splice(indexOfIn, 1);

            $(this).closest('tr').remove();
        });


        $("#im_confirm").click(function() {
            let data = document.getElementById('assyIm');
            let arrDatas = [];

            if (arrEnter.length < 1) {

                Notify_Basic_Error(translations['error'], translations['data_enter_empty'] + ' ! ' + translations['let_check_again']);

            } else {
                $("#im_confirm").remove();

                for (let i = 0; i < data.rows.length; i++) {

                    // GET THE CELLS COLLECTION OF THE CURRENT ROW.
                    let objCells = data.rows.item(i).cells;
                    // LOOP THROUGH EACH CELL OF THE CURENT ROW TO READ CELL VALUES.
                    // if (objCells.item(objCells.length - 2).innerHTML == "OK") {
                    let arrData = [];
                    for (let j = 1; j < objCells.length - 1; j++) {
                        if (j == 3) {
                            arrData.push(objCells.item(j).children[0].value)
                        } else {
                            arrData.push(objCells.item(j).innerHTML)
                        }
                    }
                    arrDatas.push(arrData);
                    // }
                }

                // console.log(arrDatas)
                $.post('view/destroyImporting', {
                        arrDatas: arrDatas,
                    },
                    function(data) {

                        Notify_Basic_Success(translations['successful'], data);

                        $(".close").click();

                        // var modal = document.querySelector(".modal-backdrop.fade.show");
                        // if(modal != null) {
                        //     modal.remove();
                        // }

                        $(".modal-backdrop.fade.show").remove();

                        loadDestroy();
                    });
            }
        })
    })

    function assyImportDeleteInput() {
        $('#im_model').val('');
        $('#im_qty').val('');
    }
</script>