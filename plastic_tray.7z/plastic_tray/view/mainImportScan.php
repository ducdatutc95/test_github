<?php
date_default_timezone_set("Asia/Ho_Chi_Minh");
session_start();

require('../controller/_controller.php');
$data = new cEms;

if (empty($_SESSION['id'])) {
    header('Location:../../login.php');
}


if ($_SESSION['type'] != 'TRAY' && $_SESSION['type'] != 'ADMIN') {
    header('Location:../../index.php');
    exit();
}

if (isset($_COOKIE['token'])) {
    $token = $_COOKIE['token'];
    $userInfo = $data->cGetUser($token);
    if (empty($userInfo)) {
        header("Location:../../login");
        exit();
    }
} else {
    header("Location:../../login");
    exit();
}


$lang  = isset($_SESSION['lg']) ? $_SESSION['lg'] : 'en';
$translations = $data->cGetLanguage($lang);



$area = $_POST['area'];
// print_r($area);

$resModel = $data->cGetModel('', '', '', '');
$resCreate = $data->cGetCreateBarcode();
$resMainExist = $data->cGetMainBarcode('FULL');
$resMainEmpty = $data->cGetMainBarcode('EMPTY');

$resMainSubPosUnique = $data->cMainSubPosUnique($area, '');
// print_r($resMainSubPosUnique);

$arrModel = json_encode($resModel);
$arrCreate = json_encode($resCreate);
$arrMainExist = json_encode($resMainExist);
$arrMainEmpty = json_encode($resMainEmpty);
$arrMainSubPosUnique = json_encode($resMainSubPosUnique);
?>


<div class="dd_row">
    <div class="dd_col dd_c-12 dd_m-12 dd_l-6 mt-3 mb-3">
        <h2 class="dd_create_barcode_title"> <?php echo $translations['import'] . ' ' . $translations['barcode'] . ': ' . ($area == 'STAIR' ? $translations['stair'] : $translations['production']); ?> </h2>
    </div>

    <div class="dd_col dd_c-12 dd_m-12 dd_l-6 mt-3 mb-3">
        <div class="dd_btn-group">
            <button
                class="dd_btn dd_btn--size-small dd_btn--success"
                id="confirm">
                <?php echo $translations['confirm'];
                ?>
            </button>
        </div>
    </div>
</div>

<div class="dd_row" id="dd_after_confirm">

    <div class="dd_col dd_c-12 dd_m-12 dd_l-6 dd_l-o-3">
        <div class="dd_input_group">
            <div class="dd_input_group_prepend">
                <label for="barcode" class="dd_input_group_label dd_input_group_label-nowrap"><?php echo $translations['barcode']; ?></label>
            </div>

            <input
                id="barcode"
                type="text"
                placeholder="<?php echo $translations['enter'] . ' ' . $translations['barcode']; ?>"
                class="dd_input_group_control" autocomplete="off" />
        </div>

    </div>

    <div class="dd_col dd_c-12 dd_m-12 dd_l-12">

        <div class="dd_container_right_main dd_responsive_table">

            <table class="table table-hover table-bordered " id="tableIm" style="width: 100%;">
                <thead class="text-center dd_table_thead_color_blue">
                    <tr>
                        <th>No.</th>
                        <th> <?php echo $translations['barcode']; ?> </th>
                        <th>Model</th>
                        <th> <?php echo $translations['position']; ?> </th>
                        <th> <?php echo $translations['qty']; ?> </th>
                        <th> <?php echo $translations['status']; ?> </th>
                        <th> <?php echo $translations['delete']; ?> </th>
                    </tr>
                </thead>

                <tbody id="dataEx">
                </tbody>
            </table>

        </div>

    </div>

</div>

<script>
    $(document).ready(function() {

        var area = '<?php echo $area ?>';

        var im = [];
        var i = 0;

        var translations = <?php echo json_encode($translations); ?>;

        var arrCreate = <?php echo $arrCreate; ?>;
        var arrModel = <?php echo $arrModel; ?>;
        // console.log(arrCreate);

        var arrMainExist = <?php echo $arrMainExist; ?>;
        var arrEmpty = <?php echo $arrMainEmpty; ?>;
        var arrSubPos = <?php echo $arrMainSubPosUnique; ?>;

        // console.log(arrMainExist);
        // console.log(arrEmpty);
        // console.log(arrMainSubPosUnique);

        for (var w in arrEmpty) {
            arrEmpty[w]['empty'] = 1;
        }
        // console.log("Arr empty");
        // console.log(arrEmpty);

        var arrCapacity = [];
        for (var x in arrSubPos) {
            var sub_position = arrSubPos[x]['sub_position'];
            var oo_max = arrSubPos[x]['oo_max'];
            var checkExist = arrMainExist.filter(e => {
                return e.sub_position == sub_position;
            });

            var capacity = 0;
            capacity = parseFloat(capacity);
            for (var y in checkExist) {
                var code_hm_size = checkExist[y]['code_hm_size'];

                if (code_hm_size == 'BIG') {
                    capacity += 1.8;
                } else if (code_hm_size == 'MEDIUM') {
                    capacity += 1.5;
                } else {
                    capacity += 1;
                }
            }

            if ((capacity + 1) <= oo_max) {
                arrCapacity.push({
                    'sub_position': sub_position,
                    'capacity': capacity,
                    'oo_max': oo_max
                })
            }
        }
        // console.log(arrCapacity);

        $("#barcode").focus();
        $("#barcode").keyup(function(event) {
            if (event.keyCode === 13) {

                var barcode = $('#barcode').val().toUpperCase();
                var code_hm = barcode.substring(0, 12);
                var qty = barcode.substring(barcode.length - 6);
                qty = parseInt(qty);

                var checkBarcode = arrCreate.find(e => {
                    return (e.barcode == barcode)
                });

                var checkModel = arrModel.find(e => {
                    return (e.code_hm == code_hm)
                });

                var checkExist = im.find(e => {
                    return e.barcode == barcode;
                })

                var Stt = '';
                var model = '';
                var size = '';
                var flagTrue = 1;
                if (/[^0-9a-z\-\_\+$]/i.test(barcode) || barcode.length < 10) {
                    Stt = translations['error'];
                } else if (checkBarcode == null) {
                    Stt = translations['not_found'];
                } else if (checkExist != null) {
                    Stt = translations['duplicate'];
                } else {

                    model = checkModel['model'];
                    size = checkModel['size'];
                    // console.log(size);

                    var sub_position = '';
                    var position = '';
                    for (var u in arrCapacity) {

                        if ((arrCapacity[u]['capacity'] + 1) > 9) {
                            continue;
                        }

                        var capacity = arrCapacity[u]['capacity'];
                        capacity = parseFloat(capacity);

                        if (area == 'STAIR') {
                            capacity += 1;
                        } else {
                            if (size == 'BIG') {
                                capacity += 1.8;
                            } else if (size == 'MEDIUM') {
                                capacity += 1.5;
                            } else {
                                capacity += 1;
                            }
                        }

                        var oo_max = arrCapacity[u]['oo_max'];
                        if (capacity <= oo_max) {
                            sub_position = arrCapacity[u]['sub_position'];
                            arrCapacity[u]['capacity'] = capacity;

                            var checkPositionEmpty = arrEmpty.find(e => {
                                return e.sub_position == sub_position && e.empty == 1;
                            });
                            // console.log(checkPositionEmpty);

                            position = checkPositionEmpty['position'];

                            // console.log('|||' + position);

                            var indexArrEmpty = arrEmpty.findIndex(ee => {
                                return ee.position == position
                            });

                            // console.log(indexArrEmpty);

                            if (indexArrEmpty == -1) {
                                flagTrue = 0;
                            } else {
                                arrEmpty[indexArrEmpty]['empty'] = 0;
                            }

                            break;
                        }
                    }

                    Stt = translations['rack_is_full'];
                    if (sub_position != '') {
                        Stt = 'OK';

                        i++;

                        im.push({
                            "position": position,
                            "sub_position": sub_position,
                            "barcode": barcode,
                            "code_hm": code_hm,
                            "size": size,
                            "qty": qty
                        });
                    }
                }

                if (Stt != 'OK') {
                    $('#dataEx').prepend('<tr><td>' + i + '</td><td>' + barcode + '</td><td></td><td></td><td></td> <td id = "st">' + Stt + '</td>  <td><button style="width: 40px; color: red; border: 2px solid red;">x</button></td></tr>');
                    $("#st").css("color", "Red");
                } else {
                    $('#dataEx').prepend('<tr><td>' + i + '</td><td>' + barcode + '</td><td>' + model + '</td><td>' + sub_position + ' | ' + position + '</td><td>' + qty + '</td> <td id = "st">' + Stt + '</td>  <td><button style="width: 40px; color: red; border: 2px solid red;">x</button></td></tr>');
                }

                $('#barcode').val('');
                $('#barcode').focus();

                console.log(arrEmpty);
                console.log(arrCapacity);
                console.log(im);
            }
        })

        $('#dataEx').on('click', 'tr td button', function() {
            let barcode = $(this).closest('tr').find('td:eq(1)').text();

            let stt = $(this).closest('tr').find('td:eq(5)').text();

            if (stt == 'OK') {

                let index = im.findIndex(ee => {
                    return ee.barcode == barcode;
                });

                var position_edit = im[index]['position'];
                var sub_position_edit = im[index]['sub_position'];
                var size_edit = im[index]['size'];

                let indexCapacital = arrCapacity.findIndex(ee => {
                    return ee.sub_position == sub_position_edit;
                });

                if (area == 'STAIR') {
                    arrCapacity[indexCapacital]['capacity'] -= 1;
                } else {
                    if (size_edit == 'BIG') {
                        arrCapacity[indexCapacital]['capacity'] -= 1.8;
                    } else if (size_edit == 'MEDIUM') {
                        arrCapacity[indexCapacital]['capacity'] -= 1.5;
                    } else {
                        arrCapacity[indexCapacital]['capacity'] -= 1;
                    }
                }


                let indexArrEmpty = arrEmpty.findIndex(ee => {
                    return ee.position == position_edit;
                });
                arrEmpty[indexArrEmpty]['empty'] = 1;

                console.log(arrEmpty);
                console.log(arrCapacity);
                console.log(im);

                im.splice(index, 1);
                i--;
            }

            $(this).closest('tr').remove();
        });

        $("#confirm").click(function() {


            $("#confirm").remove();

            $.post('mainImporting.php', {
                im: im
            }, function(data) {
                Notify_Basic_Success(translations['successful'], data);

                $('#dd_after_confirm').html('<h1>OK</h1>');
            });


        });

    })
</script>