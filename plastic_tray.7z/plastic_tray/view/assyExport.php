<?php
session_start();

include('../controller/_controller.php');
$data = new cEms();

$lang  = isset($_SESSION['lg']) ? $_SESSION['lg'] : 'en';
$translations = $data->cGetLanguage($lang);


if (($_SESSION['type'] != 'TRAY' && $_SESSION['type'] != 'ADMIN')) {
    echo '<span class="dd_no_access__text">' . $translations['no_access'] . ' ! <br> ' . $translations['let_contact_admin_for_support'] . '.</span>';
    exit();
}

// if ($_SESSION['role'] < 2) {
//     echo '<span class="dd_no_access__text">' . $no_access . ' ! <br> ' . $let_contact_admin_for_support . '.</span>';
//     exit();
// }

$arrTran = $_POST['arrTran'][0];
// print_r($arrTran);
$arrInput = json_encode($arrTran);
?>

<div class="modal-header">
    <h5 class="modal-title card-title" style="color: blue; font-size: 2rem; font-weight: 600;"> <?php echo $translations['export'] . ' ' . $translations['production']; ?> :</h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true" style="font-size: 2rem;">&times;</span>
    </button>
</div>

<div class="modal-body">

    <div class="dd_grid">
        <div class="dd_row">

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6">
                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="ex_code_hm" class="dd_input_group_label dd_input_group_label-nowrap">Code HM</label>
                    </div>

                    <input
                        id="ex_code_hm"
                        type="text"
                        placeholder="<?php echo $translations['enter']; ?> Code HM"
                        class="dd_input_group_control" autocomplete="off" value="<?php echo $arrTran['code_hm']; ?>" />
                </div>
            </div>

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6">
                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="ex_model" class="dd_input_group_label dd_input_group_label-nowrap">Model</label>
                    </div>
                    <input
                        id="ex_model"
                        type="text"
                        placeholder="<?php echo $translations['enter']; ?> Model"
                        class="dd_input_group_control" autocomplete="off" value="<?php echo $arrTran['model']; ?>" />
                </div>
            </div>

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6">
                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="ex_qty_pay" class="dd_input_group_label dd_input_group_label-nowrap "> <?php echo $translations['qty'] . ' ' . $translations['pay']; ?> </label>
                    </div>

                    <input
                        id="ex_qty_pay"
                        type="text"
                        placeholder="<?php echo$translations['enter'] . ' ' .$translations['qty'] ?>"
                        class="dd_input_group_control" autocomplete="off" value="<?php echo $arrTran['qty']; ?>" />
                </div>
            </div>

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6">
                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="ex_qty" class="dd_input_group_label dd_input_group_label-nowrap"> <?php echo $translations['qty'] . ' ' . $translations['export']; ?></label>
                    </div>

                    <input
                        id="ex_qty"
                        type="text"
                        placeholder="<?php echo $translations['enter'] . ' ' . $translations['qty'] ?>"
                        class="dd_input_group_control" autocomplete="off" />
                </div>
            </div>

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6 dd_l-o-6">
                <div class="dd_btn-group">
                    <button
                        class="dd_btn dd_btn--size-small dd_btn--success"
                        id="ex_confirm">
                        <?php echo $translations['confirm']; ?>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {

        var arrInput = <?php echo $arrInput; ?>;
        // console.log(arrInput);
        var code_hm = arrInput['code_hm'];

       var translations = <?php echo json_encode($translations)?>;

        var qty_temp = $("#ex_qty_pay").val();
        if (qty_temp != '') {
            $("#ex_qty_pay").val(formatNumber(qty_temp));
        }

        // Modal open, focus input
        $('#exampleModal').on('shown.bs.modal', function() {
            $('#ex_qty').focus();
        })

        $("#ex_qty").keyup(function(event) {
            var num_old = this.value;
            this.value = formatNumber(num_old);

            if (event.keyCode === 13) {

                var qty_pay = arrInput['qty'];

                var qty = $("#ex_qty").val();
                if (qty != '') {
                    qty = qty.replace(/,/g, '');
                    qty = parseInt(qty);
                }

                if (qty == '') {
                    Notify_Basic_Error(translations['error'], translations['qty'] + ': ' + translations['empty'] + ' ! ' + translations['let_check_again']);

                } else if (parseInt(qty_pay) < parseInt(qty)) {
                    Notify_Basic_Error(translations['error'], translations['qty_ex_port_bigger_qrt_pay'] + ' ! ' + translations['let_check_again']);
                } else {

                    $.post('view/assyExporting.php', {
                            code_hm: code_hm,
                            qty_pay: qty_pay,
                            qty: qty
                        },
                        function(data) {

                            Notify_Basic_Success(translations['successful'], data);

                            $(".close").click();
                            var modal = document.querySelector(".modal-backdrop.fade.show");
                            if (modal != null) {
                                modal.remove();
                            }

                            loadAssy();
                        });

                }
            }
        })


        $('#ex_confirm').click(function() {
            var qty_pay = arrInput['qty'];

            var qty = $("#ex_qty").val();
            if (qty != '') {
                qty = qty.replace(/,/g, '');
                qty = parseInt(qty);
            }

            if (qty == '') {
                Notify_Basic_Error(translations['error'], translations['qty'] + ': ' + translations['empty'] + ' ! ' + translations['let_check_again']);

            } else if (parseInt(qty_pay) < parseInt(qty)) {
                Notify_Basic_Error(translations['error'], translations['qty_ex_port_bigger_qrt_pay'] + ' ! ' + translations['let_check_again']);
            } else {

                $.post('view/assyExporting.php', {
                        code_hm: code_hm,
                        qty_pay: qty_pay,
                        qty: qty
                    },
                    function(data) {

                        Notify_Basic_Success(translations['successful'], data);

                        $(".close").click();
                        var modal = document.querySelector(".modal-backdrop.fade.show");
                        if (modal != null) {
                            modal.remove();
                        }

                        loadAssy();
                    });
            }
        })
    })
</script>