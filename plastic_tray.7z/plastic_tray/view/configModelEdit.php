<?php
session_start();


include('../controller/_controller.php');
$data = new cEms();

$lang  = isset($_SESSION['lg']) ? $_SESSION['lg'] : 'en';
$translations = $data->cGetLanguage($lang);


if (($_SESSION['type'] != 'TRAY' && $_SESSION['type'] != 'ADMIN')) {
    echo '<span class="dd_no_access__text">' . $translations['no_access'] . ' ! <br> ' . $translations['let_contact_admin_for_support'] . '.</span>';
    exit();
}

if ($_SESSION['role'] < 2) {
    echo '<span class="dd_no_access__text">' . $translations['no_access'] . ' ! <br> ' . $translations['let_contact_admin_for_support'] . '.</span>';
    exit();
}

$code_hm = $_POST['arrDid'][0];
// print_r($code_hm);
$resModelCurrent = $data->cGetModel($code_hm, '', '', '');
?>

<div class="modal-header">
    <h5 class="modal-title card-title" style="color: blue; font-size: 2rem; font-weight: 600;"> <?php echo $translations['edit']; ?> Model:</h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true" style="font-size: 2rem;">&times;</span>
    </button>
</div>

<div class="modal-body">

    <div class="dd_grid">
        <div class="dd_row">

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6">
                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="edit_code_hm" class="dd_input_group_label dd_input_group_label-nowrap">Code HM</label>
                    </div>

                    <input
                        id="edit_code_hm"
                        list="list_code_hm"
                        type="text"
                        placeholder="<?php echo $translations['enter']; ?> Code HM"
                        class="dd_input_group_control" autocomplete="off" value="<?php echo $resModelCurrent[0]->code_hm; ?>" disabled />
                </div>
            </div>

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6">
                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="edit_model" class="dd_input_group_label dd_input_group_label-nowrap">Model</label>
                    </div>
                    <input
                        id="edit_model"
                        list="list_model"
                        type="text"
                        placeholder="<?php echo $translations['enter']; ?> Model"
                        class="dd_input_group_control" autocomplete="off" value="<?php echo $resModelCurrent[0]->model; ?>" />
                </div>
            </div>

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6">
                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="edit_qty" class="dd_input_group_label dd_input_group_label-nowrap "> <?php echo $translations['qty'] . ' ' . $translations['in'] . ' ' . $translations['box'] ?> </label>
                    </div>
                    <input
                        id="edit_qty"
                        type="text"
                        placeholder="<?php echo $translations['enter'] . ' ' . $translations['qty'] ?>"
                        class="dd_input_group_control" autocomplete="off" value="<?php echo $resModelCurrent[0]->qty; ?>" />
                </div>
            </div>

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6">
                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="edit_size" class="dd_input_group_label dd_input_group_label-nowrap"> <?php echo $translations['size']; ?> Tray</label>
                    </div>

                    <select id="edit_size" class="dd_input_group_control">
                        <option value=""></option>
                        <option value="BIG" <?php if ($resModelCurrent[0]->size == "BIG") echo "selected"; ?>><?php echo $translations['big']; ?></option>
                        <option value="MEDIUM" <?php if ($resModelCurrent[0]->size == "MEDIUM") echo "selected"; ?>><?php echo $translations['medium']; ?></option>
                        <option value="SMALL" <?php if ($resModelCurrent[0]->size == "SMALL") echo "selected"; ?>><?php echo $translations['small']; ?></option>
                    </select>
                </div>
            </div>

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6">
                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="edit_type_use" class="dd_input_group_label dd_input_group_label-nowrap"><?php echo $translations['type_usage']; ?></label>
                    </div>

                    <select id="edit_type_use" class="dd_input_group_control">
                        <option value=""></option>
                        <option value="SINGLE" <?php if ($resModelCurrent[0]->type_use == "SINGLE") echo "selected"; ?>><?php echo $translations['single_use_short']; ?></option>
                        <option value="MULTIPLE" <?php if ($resModelCurrent[0]->type_use == "MULTIPLE") echo "selected"; ?>><?php echo $translations['multiple_use_short']; ?></option>
                    </select>

                </div>
            </div>

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6">
                <div class="dd_btn-group">
                    <button
                        class="dd_btn dd_btn--size-small dd_btn--success"
                        id="edit_confirm">
                        <?php echo $translations['confirm']; ?>
                    </button>
                </div>
            </div>

        </div>
    </div>
</div>

<script>
    $(document).ready(function() {

        var translations = <?php echo json_encode($translations); ?>;

        $("#edit_qty").keyup(function(event) {
            var num_old = this.value;
            this.value = formatNumber(num_old);
        })

        $("#edit_confirm").click(function() {

            var code_hm = $('#edit_code_hm').val().toUpperCase();
            var model = $('#edit_model').val().toUpperCase();
            var size = $('#edit_size').val();
            var type_use = $('#edit_type_use').val();

            var qty = $('#edit_qty').val();
            if (qty != '') {
                qty = qty.replace(',', '');
            }

            if (code_hm == '') {
                Notify_Basic_Error(translations['error'], 'Code HM: ' + translations['empty'] + ' ! ' + translations['let_check_again']);
            } else if (model == '') {
                Notify_Basic_Error(translations['error'], 'Model: ' + translations['empty'] + ' ! ' + translations['let_check_again']);
            } else if (qty == '') {
                Notify_Basic_Error(translations['error'], translations['qty'] + ': ' + translations['empty'] + ' ! ' + translations['let_check_again']);
            } else if (size == '') {
                Notify_Basic_Error(translations['error'], translations['size'] + ': ' + translations['empty'] + ' ! ' + translations['let_check_again']);
            } else if (type_use == '') {
                Notify_Basic_Error(translations['error'], translations['type_usage'] + ': ' + translations['empty'] + ' ! ' + translations['let_check_again']);
            } else {
                $.post('view/configModelEditing.php', {
                        code_hm: code_hm,
                        model: model,
                        qty: qty,
                        size: size,
                        type_use: type_use
                    },
                    function(data) {

                        // alert(data);
                        Notify_Basic_Success(translations['successful'], data);

                        $(".close").click();
                        var modal = document.querySelector(".modal-backdrop.fade.show");
                        if (modal != null) {
                            modal.remove();
                        }

                        loadConfigModel();
                    });
            }
        })
    })
</script>