<?php
session_start();

include('../controller/_controller.php');
$data = new cEms;

$lang  = isset($_SESSION['lg']) ? $_SESSION['lg'] : 'en';
$translations = $data->cGetLanguage($lang);


$code_hm = isset($_POST['code_hm']) ? $_POST['code_hm'] : '';
$model = isset($_POST['model']) ? $_POST['model'] : '';

$fromTime = isset($_POST['fromTime']) ? $_POST['fromTime'] : '';
$toTime = isset($_POST['toTime']) ? $_POST['toTime'] : '';


$resAssy = $data->cGetAssy($code_hm, $model, $fromTime, $toTime);
// print_r($resAssy);
$arrAssy = json_encode($resAssy);
?>

<table class="table table-hover table-bordered " id="tableConfigModel" style="width: 100%;">
    <thead class="text-center dd_table_thead_color_blue">
        <tr>
            <th>No.</th>
            <th>Code HM</th>
            <th>Model</th>
            <th> <?php echo $translations['qty']; ?> </th>
            <th> <?php echo $translations['author']; ?> </th>
            <th> <?php echo $translations['time']; ?> </th>
        </tr>
    </thead>

    <tbody id="mainEx">
    </tbody>
</table>

<div class="modal fade bd-example-modal-xl" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content" id="modal-content">
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        var arrAssy = <?php echo $arrAssy; ?>;

       var translations = <?php echo json_encode($translations); ?>;

        for (var x in arrAssy) {
            arrAssy[x]['stt'] = parseInt(x) + 1;

            arrAssy[x]['_qty'] = formatNumber(arrAssy[x]['qty']);
        }

        tableConfigModel(arrAssy, translations);
    });

    function tableConfigModel(data_in, translations) {
        var arrDid = [];

        var example = $('#tableConfigModel').DataTable({
            "lengthMenu": [
                [10, -1],
                [10, "All"]
            ],

            "order": [
                [0, "desc"]
            ],

            "responsive": true,

            "scrollX": "auto",

            "scrollY": "600px",
            "scrollCollapse": true,
            "paging": false,

            dom: 'Bfrtip',
            buttons: [
                'excel',
                'selectAll',
                'selectNone',
                {
                    text: ' <i class="fas fa-plus-circle i-right" style="color:blue;"></i> ' + translations['import'],
                    className: 'btnPractice',
                    action: function(e, dt, node, config) {
                        $.post('view/assyImport.php',
                            function(data) {
                                $("#modal-content").html(data);
                                $('#exampleModal').modal('show');
                            });
                    }
                },
                {
                    text: ' <i class="fas fa-edit i-right" style="color:black;"></i> ' + translations['export'],
                    className: 'btnPractice',
                    action: function(e, dt, node, config) {

                        var arr_len = arrDid.length;

                        if (arr_len == 0) {
                            Notify_Basic_Error(translations['error'], translations['must_select_one_line'] + ' !');
                        } else if (arr_len > 1) {
                            Notify_Basic_Error(translations['error'], translations['just_select_one_line'] + ' !');
                        } else {
                            $.post('view/assyExport.php', {
                                    arrTran: arrDid
                                },
                                function(data) {
                                    $("#modal-content").html(data);
                                    $('#exampleModal').modal('show');
                                });
                        }
                    }
                }
            ],

            data: data_in,
            rowCallback: function(row, data, index) {

            },

            columns: [{
                    data: "stt"
                },

                {
                    data: "code_hm"
                },

                {
                    data: "model"
                },

                {
                    data: "_qty"
                },

                {
                    data: "author"
                },

                {
                    data: "stime"
                }
            ],
            select: {
                style: 'multi'
            }
        });

        example
            .on('select', function(e, dt, type, indexes) {
                var rowData = example.rows(indexes).data().toArray();

                for (var i = 0; i < rowData.length; i++) {
                    var x = arrDid.indexOf(rowData[i]);
                    if (x === -1) //neu ko ton tai
                        arrDid.unshift(rowData[i]); //thi push 
                }
            })

            .on('deselect', function(e, dt, type, indexes) {
                var rowDataUn = example.rows(indexes).data().toArray();

                for (var i = 0; i < rowDataUn.length; i++) {
                    var x = arrDid.indexOf(rowDataUn[i]);
                    arrDid.splice(x, 1);
                }
                // console.log(arrDid);
            })
            .on('dblclick', 'tr', function(e, dt, type, indexes) {
                var dataDb = example.rows(this).data().toArray();
                // console.log(dataDb[0]);

                $.post('view/assyExport.php', {
                        arrTran: dataDb
                    },
                    function(data) {
                        $("#modal-content").html(data);
                        $('#exampleModal').modal('show');
                    });
            });
    }
</script>