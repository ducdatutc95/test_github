<?php
date_default_timezone_set("Asia/Ho_Chi_Minh");
session_start();

require('../controller/_controller.php');
$data = new cEms;

if (empty($_SESSION['id'])) {
    header('Location:../../login.php');
}

if ($_SESSION['type'] != 'TRAY' && $_SESSION['type'] != 'ADMIN') {
    header('Location:../../index.php');
    exit();
}

if (isset($_COOKIE['token'])) {
    $token = $_COOKIE['token'];
    $userInfo = $data->cGetUser($token);
    if (empty($userInfo)) {
        header("Location:../../login");
        exit();
    }
} else {
    header("Location:../../login");
    exit();
}

$lang  = isset($_SESSION['lg']) ? $_SESSION['lg'] : 'en';
$translations = $data->cGetLanguage($lang);

$resNameRack = $data->cGetNameRackUnique();
$arrNameRack = json_encode($resNameRack);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <title> Tray </title>

    <link
        rel="shortcut icon"
        href="../vendor/library_xauxa/assets/img/favicon/apple-touch-icon.png"
        type="image/x-icon" />

    <link
        rel="stylesheet"
        href="../vendor/font/fontawesome-free-5.15.4-web/css/all.min.css" />

    <link href="../vendor/bootstrap/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="../vendor/bootstrap/bootstrap.css" rel="stylesheet" type="text/css">

    <link href="../vendor/datatable/dataTables.min.css" rel="stylesheet" type="text/css" />
    <link href="../vendor/datatable/buttons.dataTables.min.css" rel="stylesheet" type="text/css" />
    <link href="../vendor/datatable/select.dataTables.css" rel="stylesheet" type="text/css" />

    <link rel="stylesheet" href="../vendor/library_xauxa/assets/css/base.css" />
    <link rel="stylesheet" href="../vendor/library_xauxa/assets/css/common.css" />

    <link rel="stylesheet" href="../vendor/library_xauxa/assets/css/header.css" />
    <link rel="stylesheet" href="../vendor/library_xauxa/assets/css/footer.css" />

    <link rel="stylesheet" href="../vendor/library_xauxa/assets/css/input.css" />
    <link rel="stylesheet" href="../vendor/library_xauxa/assets/css/button.css" />
    <link rel="stylesheet" href="../vendor/library_xauxa/assets/css/sidebare.css" />

    <link rel="stylesheet" href="../vendor/library_xauxa/assets/css/grid.css" />
    <link rel="stylesheet" href="../vendor/library_xauxa/assets/css/sidebare.css" />
    <link rel="stylesheet" href="../vendor/library_xauxa/assets/css/responsive.css" />
    <link rel="stylesheet" href="../vendor/library_xauxa/assets/css/breadcrumb.css" />
    <link rel="stylesheet" href="../vendor/library_xauxa/assets/css/text_long.css" />
    <link rel="stylesheet" href="../vendor/library_xauxa/assets/css/container.css" />
    <link rel="stylesheet" href="../vendor/library_xauxa/assets/css/table.css" />
    <link rel="stylesheet" href="../vendor/library_xauxa/assets/css/text_long.css" />
    <link rel="stylesheet" href="../vendor/library_xauxa/assets/css/tooltip.css" />

    <link rel="stylesheet" href="../vendor/library_xauxa/fix_default/fix_default.css">

    <link rel="stylesheet" href="../vendor/library_xauxa/locals/css/style.css" />
</head>

<body>

    <datalist id="list_rack">
        <?php foreach ($resNameRack as $key) { ?>
            <option value="<?php echo $key->name; ?>"><?php echo $key->name; ?></option>
        <?php } ?>
    </datalist>

    <div class="dd_grid dd_wide" id="dd_after_confirm">

        <div class="dd_row">
            <div class="dd_col dd_c-12 dd_m-12 dd_l-12 mt-3 mb-3">
                <h2 class="dd_create_barcode_title"> <?php echo $translations['select'] . ' ' . $translations['rack'] . ':'; ?> </h2>
            </div>
        </div>

        <div class="dd_row">

            <div class="dd_col dd_c-12 dd_m-12 dd_l-9">
                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="barcode" class="dd_input_group_label dd_input_group_label-nowrap"><?php echo $translations['rack']; ?></label>
                    </div>

                    <input type="text" id="im_rack" list="list_rack" class="dd_input_group_control" placeholder="<?php echo $translations['enter'] . ' ' . $translations['rack']; ?>" autocomplete="off">
                </div>

            </div>

            <div class="dd_col dd_c-12 dd_m-12 dd_l-3">
                <div class="dd_btn-group">
                    <button
                        class="dd_btn dd_btn--size-small dd_btn--success"
                        id="im_confirm">
                        <?php echo $translations['confirm'];
                        ?>
                    </button>
                </div>
            </div>
        </div>
    </div>
</body>

</html>

<script src="../vendor/jquery/jquery.js"></script>
<script src="../vendor/bootstrap/moment.min.js"></script>
<script src="../vendor/bootstrap/bootstrap.min.js"></script>

<script src="../vendor/jquery/tree_menu.js"></script>
<script src="../vendor/jquery/tree.min.js"></script>
<script src="../vendor/jquery/jscharting.js"></script>

<script src="../vendor/datatable/dataTables.min.js"></script>
<script src="../vendor/datatable/dataTables.select.js"></script>
<script src="../vendor/datatable/dataTables.buttons.min.js"></script>
<script src="../vendor/datatable/dataTables.buttonHtml5.min.js"></script>

<script src="../vendor/datatable/buttons.flash.min.js"></script>
<script src="../vendor/datatable/jszip.min.js"></script>
<script src="../vendor/bootstrap/moment.min.js"></script>
<script src="../vendor/bootstrap/bootstrap-datetimepicker.js"></script>
<script src="../vendor/datatable/dataTables.bootstrap4.min.js"></script>

<script src="../vendor/jquery/sweetalert2.all.min.js"></script>

<script src="../vendor/library_xauxa/locals/js/myJquery.js"></script>

<script src="../vendor/library_xauxa/assets/js/header.js"></script>

<script>
    $(document).ready(function() {

        var arrNameRack = <?php echo $arrNameRack ?>;
        var translations = <?php echo json_encode($translations); ?>;

        $("#im_confirm").click(function() {

            var rack = $("#im_rack").val().toUpperCase().trim();

            var checkRack = arrNameRack.find(e => e.name == rack);

            if (rack == '') {
                Notify_Basic_Error(translations['error'], translations['rack'] + ': ' + translations['empty'] + ' ! ' + translations['let_check_again']);
            } else if (checkRack == null) {
                Notify_Basic_Error(translations['error'], translations['rack'] + ': ' + translations['not_found'] + ' ! ' + translations['let_check_again']);
            } else {

                $("#im_confirm").remove();

                var area = checkRack['area'];

                $.post('mainMoveInScan.php', {
                    rack: rack,
                    area: area
                }, function(data) {
                    $('#dd_after_confirm').html(data);
                });

            }

        });

    })
</script>