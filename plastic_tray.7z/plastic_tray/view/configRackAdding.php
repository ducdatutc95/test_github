<?php
date_default_timezone_set("Asia/Ho_Chi_Minh");
$stime = date('Y-m-d H:i:s');

session_start();
$author = "ERROR";
if (isset($_SESSION['id'])) {
    $author = $_SESSION['id'];
}

include('../controller/_controller.php');
$data = new cEms();

$name =  $_POST['name'];
$area =  $_POST['area'];

$width =  $_POST['width'];
$length =  $_POST['length'];
$height =  $_POST['height'];

$o_width =  $_POST['o_width'];
$o_length =  $_POST['o_length'];
$o_height =  $_POST['o_height'];

$num_o_bottom = intval($width) * intval($length);
$num_o_in_o = intval($o_width) * intval($o_length) * intval($o_height);

$oo_max = $num_o_in_o;

$arrPos = array();
$position = '';

$count = 0;
$str_sql = '';
for ($i = 1; $i <= $height; $i++) {
    for ($j = 1; $j <= $num_o_bottom; $j++) {
        for ($k = 1; $k <= $num_o_in_o; $k++) {

            $sub_position = $name . $i . '-' . $j;
            $oo = $k;
            $position = $name . $i . '-' . $j . '_' . $k;

            $arrPos[] =  (object) [
                'name' => $name,
                'sub_position' => $sub_position,
                'oo' => $oo,
                'position' => $position,
                'oo_max' => $oo_max
            ];

            $count++;
            $str_sql .= "('" . $name . "', '" . $sub_position . "', '" . $oo . "', '" . $position . "', '" . $oo_max . "'),";

            if ($count == 1000) {

                if (substr($str_sql, -1, 1) == ',') {
                    $str_ok = substr($str_sql, 0, (strlen($str_sql) - 1));
                } else {
                    $str_ok = $str_sql;
                }

                $str_sql = '';
                $count = 0;

                $data->cAddPositionMain($str_ok);
            }
        }
    }
}

if (substr($str_sql, -1, 1) == ',') {
    $str_ok = substr($str_sql, 0, (strlen($str_sql) - 1));
} else {
    $str_ok = $str_sql;
}

$data->cAddPositionMain($str_ok);


$data->cAddRack($name, $area, $width, $length, $height, $o_width, $o_length, $o_height, $author, $stime);
// print_r($arrPos);
