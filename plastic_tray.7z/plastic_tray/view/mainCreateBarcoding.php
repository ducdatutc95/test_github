<?php
session_start();

$lg = 'en';
if (isset($_SESSION['lg'])) {
    $lg = $_SESSION['lg'];
}

$author = 'ERROR';
if (isset($_SESSION['id'])) {
    $author = $_SESSION['id'];
}

date_default_timezone_set("Asia/Ho_Chi_Minh");
$stime = date('Y-m-d H:i:s');
$sdate = date('Y-m-d');

$timeTime = date('YmdHis');

include('../controller/_controller.php');
$data = new cEms;

$lang  = isset($_SESSION['lg']) ? $_SESSION['lg'] : 'en';
$translations = $data->cGetLanguage($lang);


$code_hm = $_POST['code_hm'];
$model = $_POST['model'];
$qty_in_box = $_POST['qty_in_box'];
$number_box = $_POST['number_box'];

$valRandom = rand(105, 403);

$qtyBox = '000000' . $qty_in_box;
$qtyInBox = substr($qtyBox, -6, 6);


$resData = array();
for ($i = 0; $i < intval($number_box); $i++) {
    $barcode = $code_hm . 'W' . $timeTime . 'W' . ($valRandom + $i + 1) . 'W' . $qtyInBox;

    $data->cAddCreateBarcode($barcode, $qty_in_box, $code_hm, $author, $stime);

    $resData[] = (object) array('barcode' => $barcode, 'model' => $model, 'qty' => $qty_in_box, 'sdate' => $sdate);
}
// print_r($resData);

$arrData = json_encode($resData);
?>

<div class="dd_col dd_c-12 dd_m-12 dd_l-6 mt-3">
    <div class="dd_btn-group">
        <button
            class="dd_btn dd_btn--size-small dd_btn--error"
            id="confirm">
            <?php echo $translations['not_close_browser'] . '. ' . $translations['wait'] . '...';
            ?>
        </button>
    </div>

    <div class="dd_btn-group">
        <button
            class="dd_btn dd_btn--size-small dd_btn--success"
            id="confirm">
            <?php echo $translations['speed'] . ' '; ?>
            <span id="dd_count_run"></span> <?php echo ' / ' . $number_box; ?> </button>
    </div>
</div>


<script>

    // $(document).ready(function() {

    //     var arrData = <?php //echo $arrData; ?>;

    // })

</script>

<script>
    function get_respone(socket) {
        return new Promise(function(resolve, reject) {
            socket.on('battery', function(data) { // lắng nghe event 'battery' được server gửi đến

                resolve(data);

                // console.log(data); // log data để kiểm tra
                // alert(data);
            });
        })
    }

    async function handle_printer(socket, arrDid) {

        for (let i = 1; i <= arrDid.length; i++) {

            // console.log('For' + i);

            socket.emit('print_tray', {
                'barcode': arrDid[i - 1]['barcode'],
                'sdate': arrDid[i - 1]['sdate'],
                'model': arrDid[i - 1]['model'],
                'qty': arrDid[i - 1]['qty'],
            });

            let res_printer = await get_respone(socket);

            if (res_printer != 'OK') {
                console.log('Error Printer Auto');
                break;
            }

            document.getElementById("dd_count_run").innerHTML = i;

            // console.log('Run handle printer' + i);
        }
    }

    $(document).ready(function() {

        var arrData = <?php echo $arrData ?>;
        // console.log(arrData);

        let socket;
        socket = io.connect('http://192.168.133.48:1666', {
            transports: ['websocket']
        });

        handle_printer(socket, arrData).then(function() {
            setTimeout(function() {
                // window.close();
                alert('Print Finish');
            }, 30000)
        });
    })
</script>