<div class="dd_footer">
  <div class="dd_footer_content">
    <span class="dd_footer_text dd_footer_security">&copy; 2020-2024 Created by Innovation Team. All Rights Reserved by
      DreamTech Company</span>
    <span class="dd_footer_text dd_footer_contact">Contact: 0975 654 808 Mr Thông</span>
  </div>
</div>
</div>


<div class="modal fade bd-example-modal-xl" id="exampleModalLanguage" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl" role="document">
    <div class="modal-content" id="modal-content">
    </div>
  </div>
</div>


</body>

</html>

<script src="./vendor/jquery/jquery.js"></script>
<script src="./vendor/bootstrap/moment.min.js"></script>
<script src="./vendor/bootstrap/bootstrap.min.js"></script>

<script src="./vendor/jquery/tree_menu.js"></script>
<script src="./vendor/jquery/tree.min.js"></script>
<script src="./vendor/jquery/jscharting.js"></script>

<script src="./vendor/datatable/dataTables.min.js"></script>
<script src="./vendor/datatable/dataTables.select.js"></script>
<script src="./vendor/datatable/dataTables.buttons.min.js"></script>
<script src="./vendor/datatable/dataTables.buttonHtml5.min.js"></script>
<!-- <script src="./vendor/datatable/dataTables.responsive.min.js"></script> -->

<script src="./vendor/datatable/buttons.flash.min.js"></script>
<script src="./vendor/datatable/jszip.min.js"></script>
<script src="./vendor/bootstrap/moment.min.js"></script>
<script src="./vendor/bootstrap/bootstrap-datetimepicker.js"></script>
<script src="./vendor/datatable/dataTables.bootstrap4.min.js"></script>

<script src="./vendor/jquery/socket.io.js"></script>

<script src="./vendor/jquery/sweetalert2.all.min.js"></script>

<script src="./vendor/library_xauxa/locals/js/myJquery.js"></script>

<script src="./vendor/library_xauxa/assets/js/header.js"></script>

<script>
  $(document).ready(function() {

    $("#dd_change_language").click(function() {

      $.post('changeLanguage.php',
        function(data) {
          $("#modal-content").html(data);
          $('#exampleModal').modal('show');
        });

    })
  })
</script>