<?php
include('_database.php');

// Therr m_class
//  + mBase
//  + mUser
//  + mEms
class mBase extends database
{
    public function mGet()
    {
        $sql = "SELECT * FROM tableName";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mAdd($a, $b)
    {
        $sql = "INSERT INTO tableName(colum1, colum2) VALUES ('$a', '$b')";
        $this->setQuery($sql);
        return $this->execute(array($a, $b));
    }

    public function mEdit($a, $b)
    {
        $sql = "UPDATE tableName SET colum1 = '$a', colum2 = '$b' WHERE colum3 = ''";
        $this->setQuery($sql);
        return $this->execute(array($a, $b));
    }

    public function mDel()
    {
        $sql = "DELETE FROM tableName";
        $this->setQuery($sql);
        return $this->execute(array());
    }
}

class mUser extends databaseUser
{
    public function mGetUser($token)
    {
        $sql = "SELECT * FROM user WHERE token = '$token'";
        $this->setQuery($sql);
        return $this->loadRow(array());
    }

    public function mLogin($id, $pass)
    {
        $sql = "SELECT * FROM user WHERE id = '$id' AND pass = md5('$pass')";
        $this->setQuery($sql);
        return $this->loadRow(array());
    }

    public function mSetToken($token, $id)
    {
        $sql = "UPDATE user Set token = md5('$token') WHERE id = '$id'";
        $this->setQuery($sql);
        return $this->execute();
    }

    public function mChangePass($id, $newPass)
    {
        $sql = "UPDATE user SET pass = md5('$newPass') WHERE id = '$id'";
        $this->setQuery($sql);
        return $this->execute();
    }
}

class mEms extends database
{
    // Sort: Get - Add - Edit - Delete

    public function mGetLanguage($lang)
    {
        $sql = "SELECT id, $lang AS lang FROM plastic_tray__language";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetMain($name)
    {
        $arr = array();
        if ($name != '') $arr[] = "name = '$name'";
        $queryArr = implode(" AND ", $arr);

        $sql = "SELECT * FROM plastic_tray__main";

        if (count($arr) > 0) {
            $sql .= " WHERE " . $queryArr;
        }

        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetMainExist()
    {
        $sql = "SELECT * FROM plastic_tray__main WHERE barcode <> ''";

        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetMainShow($code_hm, $model, $fromTime, $toTime)
    {

        $arr = array();
        if ($code_hm != '') $arr[] = "main.code_hm = '$code_hm'";
        if ($model != '') $arr[] = "model.model = '$model'";

        if ($fromTime != '' && $toTime != '') {
            $arr[] = "DATE(main.stime) BETWEEN '$fromTime' AND '$toTime'";
        } else if ($fromTime == '' && $toTime != '') {
            $arr[] = "DATE(main.stime) <= '$toTime'";
        } else if ($fromTime != '' && $toTime == '') {
            $arr[] = "DATE(main.stime) >= '$fromTime'";
        }

        $queryArr = implode(" AND ", $arr);

        $sql = "SELECT main.*, model.model AS model FROM plastic_tray__main AS main LEFT JOIN plastic_tray__model AS model ON  main.code_hm = model.code_hm WHERE barcode <> '' ";

        if (count($arr) > 0) {
            $sql .= " AND " . $queryArr;
        }

        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mMainSubPosUnique($area, $name)
    {

        $arr = array();
        if ($area != '') $arr[] = "rack.area = '$area'";
        if ($name != '') $arr[] = "rack.name = '$name'";
        $queryArr = implode(" AND ", $arr);

        $sql = "SELECT DISTINCT main.sub_position AS sub_position, main.oo_max FROM plastic_tray__main AS main INNER JOIN plastic_tray__rack AS rack ON main.name = rack.name";

        if (count($arr) > 0) {
            $sql .= " WHERE " . $queryArr;
        }

        $this->setQuery($sql);

        // print_r($sql);

        return $this->loadAllRows();
    }

    public function mGetMainBarcode($type)
    {
        if ($type == 'FULL') {
            $sql = "SELECT * FROM plastic_tray__main WHERE barcode <> ''";
        } else if ($type == 'EMPTY') {
            $sql = "SELECT * FROM plastic_tray__main WHERE barcode = ''";
        } else if ($type == 'ALL') {
            $sql = "SELECT * FROM plastic_tray__main";
        }

        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetModel($code_hm, $model, $size, $type_use)
    {
        $arr = array();
        if ($code_hm != '') $arr[] = "code_hm = '$code_hm'";
        if ($model != '') $arr[] = "model = '$model'";
        if ($size != '') $arr[] = "size = '$size'";
        if ($type_use != '') $arr[] = "type_use = '$type_use'";
        $queryArr = implode(" AND ", $arr);

        $sql = "SELECT * FROM plastic_tray__model";

        if (count($arr) > 0) {
            $sql .= " WHERE " . $queryArr;
        }

        $sql .= ' ORDER BY stime';

        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetAssy($code_hm, $model, $fromTime, $toTime)
    {
        $arr = array();
        if ($code_hm != '') $arr[] = "assy.code_hm = '$code_hm'";
        if ($model != '') $arr[] = "model.model = '$model'";

        if ($fromTime != '' && $toTime != '') {
            $arr[] = "DATE(assy.stime) BETWEEN '$fromTime' AND '$toTime'";
        } else if ($fromTime == '' && $toTime != '') {
            $arr[] = "DATE(assy.stime) <= '$toTime'";
        } else if ($fromTime != '' && $toTime == '') {
            $arr[] = "DATE(assy.stime) >= '$fromTime'";
        }

        $queryArr = implode(" AND ", $arr);

        $sql = "SELECT assy.*, model.model AS model FROM plastic_tray__assy AS assy LEFT JOIN plastic_tray__model AS model ON  assy.code_hm = model.code_hm ";

        if (count($arr) > 0) {
            $sql .= " WHERE " . $queryArr;
        }

        $sql .= ' ORDER BY stime';

        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetAssyImport($code_hm, $model, $fromTime, $toTime)
    {
        $arr = array();
        if ($code_hm != '') $arr[] = "assy.code_hm = '$code_hm'";
        if ($model != '') $arr[] = "model.model = '$model'";

        if ($fromTime != '' && $toTime != '') {
            $arr[] = "DATE(assy.stime) BETWEEN '$fromTime' AND '$toTime'";
        } else if ($fromTime == '' && $toTime != '') {
            $arr[] = "DATE(assy.stime) <= '$toTime'";
        } else if ($fromTime != '' && $toTime == '') {
            $arr[] = "DATE(assy.stime) >= '$fromTime'";
        }

        $queryArr = implode(" AND ", $arr);

        $sql = "SELECT assy.*, model.model AS model FROM plastic_tray__assy_import AS assy LEFT JOIN plastic_tray__model AS model ON  assy.code_hm = model.code_hm ";

        if (count($arr) > 0) {
            $sql .= " WHERE " . $queryArr;
        }

        $sql .= ' ORDER BY stime';

        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetImport($code_hm, $model, $fromTime, $toTime)
    {
        $arr = array();
        if ($code_hm != '') $arr[] = "import.code_hm = '$code_hm'";
        if ($model != '') $arr[] = "model.model = '$model'";

        if ($fromTime != '' && $toTime != '') {
            $arr[] = "DATE(import.stime) BETWEEN '$fromTime' AND '$toTime'";
        } else if ($fromTime == '' && $toTime != '') {
            $arr[] = "DATE(import.stime) <= '$toTime'";
        } else if ($fromTime != '' && $toTime == '') {
            $arr[] = "DATE(import.stime) >= '$fromTime'";
        }

        $queryArr = implode(" AND ", $arr);

        $sql = "SELECT import.*, model.model AS model FROM plastic_tray__import AS import LEFT JOIN plastic_tray__model AS model ON  import.code_hm = model.code_hm ";

        if (count($arr) > 0) {
            $sql .= " WHERE " . $queryArr;
        }

        $sql .= ' ORDER BY stime';

        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetExport($code_hm, $model, $fromTime, $toTime)
    {
        $arr = array();
        if ($code_hm != '') $arr[] = "export.code_hm = '$code_hm'";
        if ($model != '') $arr[] = "model.model = '$model'";

        if ($fromTime != '' && $toTime != '') {
            $arr[] = "DATE(export.stime) BETWEEN '$fromTime' AND '$toTime'";
        } else if ($fromTime == '' && $toTime != '') {
            $arr[] = "DATE(export.stime) <= '$toTime'";
        } else if ($fromTime != '' && $toTime == '') {
            $arr[] = "DATE(export.stime) >= '$fromTime'";
        }

        $queryArr = implode(" AND ", $arr);

        $sql = "SELECT export.*, model.model AS model FROM plastic_tray__export AS export LEFT JOIN plastic_tray__model AS model ON  export.code_hm = model.code_hm ";

        if (count($arr) > 0) {
            $sql .= " WHERE " . $queryArr;
        }

        $sql .= ' ORDER BY stime';

        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetAssyExport($code_hm, $model, $fromTime, $toTime)
    {
        $arr = array();
        if ($code_hm != '') $arr[] = "assy.code_hm = '$code_hm'";
        if ($model != '') $arr[] = "model.model = '$model'";

        if ($fromTime != '' && $toTime != '') {
            $arr[] = "DATE(assy.stime) BETWEEN '$fromTime' AND '$toTime'";
        } else if ($fromTime == '' && $toTime != '') {
            $arr[] = "DATE(assy.stime) <= '$toTime'";
        } else if ($fromTime != '' && $toTime == '') {
            $arr[] = "DATE(assy.stime) >= '$fromTime'";
        }

        $queryArr = implode(" AND ", $arr);

        $sql = "SELECT assy.*, model.model AS model FROM plastic_tray__assy_export AS assy LEFT JOIN plastic_tray__model AS model ON  assy.code_hm = model.code_hm ";

        if (count($arr) > 0) {
            $sql .= " WHERE " . $queryArr;
        }

        $sql .= ' ORDER BY stime';

        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetDestroy($code_hm, $model, $fromTime, $toTime)
    {
        $arr = array();
        if ($code_hm != '') $arr[] = "destroy.code_hm = '$code_hm'";
        if ($model != '') $arr[] = "model.model = '$model'";

        if ($fromTime != '' && $toTime != '') {
            $arr[] = "DATE(destroy.stime) BETWEEN '$fromTime' AND '$toTime'";
        } else if ($fromTime == '' && $toTime != '') {
            $arr[] = "DATE(destroy.stime) <= '$toTime'";
        } else if ($fromTime != '' && $toTime == '') {
            $arr[] = "DATE(destroy.stime) >= '$fromTime'";
        }

        $queryArr = implode(" AND ", $arr);

        $sql = "SELECT destroy.*, model.model AS model FROM plastic_tray__destroy AS destroy LEFT JOIN plastic_tray__model AS model ON  destroy.code_hm = model.code_hm ";

        if (count($arr) > 0) {
            $sql .= " WHERE " . $queryArr;
        }

        $sql .= ' ORDER BY stime';

        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetSumDestroy($code_hm, $model, $fromTime, $toTime)
    {
        $arr = array();
        if ($code_hm != '') $arr[] = "destroy.code_hm = '$code_hm'";
        if ($model != '') $arr[] = "model.model = '$model'";

        if ($fromTime != '' && $toTime != '') {
            $arr[] = "DATE(destroy.stime) BETWEEN '$fromTime' AND '$toTime'";
        } else if ($fromTime == '' && $toTime != '') {
            $arr[] = "DATE(destroy.stime) <= '$toTime'";
        } else if ($fromTime != '' && $toTime == '') {
            $arr[] = "DATE(destroy.stime) >= '$fromTime'";
        }

        $queryArr = implode(" AND ", $arr);

        $sql = "SELECT destroy.code_hm AS code_hm, SUM(destroy.qty) AS qty , model.model AS model FROM plastic_tray__destroy AS destroy LEFT JOIN plastic_tray__model AS model ON  destroy.code_hm = model.code_hm ";

        if (count($arr) > 0) {
            $sql .= " WHERE " . $queryArr;
        }

        $sql .= ' GROUP BY destroy.code_hm';

        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetRack($name, $area)
    {
        $arr = array();
        if ($name != '') $arr[] = "name = '$name'";
        if ($area != '') $arr[] = "area = '$area'";
        $queryArr = implode(" AND ", $arr);

        $sql = "SELECT * FROM plastic_tray__rack";

        if (count($arr) > 0) {
            $sql .= " WHERE " . $queryArr;
        }

        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetNameRackUnique()
    {
        $sql = "SELECT DISTINCT name AS name , area AS area  FROM plastic_tray__rack";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetCreateBarcode()
    {
        $sql = "SELECT * FROM plastic_tray__create_barcode WHERE status = '1'";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetMoveTemp()
    {
        $sql = "SELECT * FROM plastic_tray__move_temp";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mAddModel($code_hm, $model, $qty, $size, $type_use, $author, $stime)
    {
        $sql = "INSERT INTO plastic_tray__model(code_hm, model, qty, size, type_use, author, stime) VALUES ('$code_hm', '$model', '$qty', '$size', '$type_use', '$author', '$stime')";
        $this->setQuery($sql);
        return $this->execute(array($code_hm, $model, $qty, $size, $type_use, $author, $stime));
    }

    public function mAddAssy($code_hm, $qty, $author, $stime)
    {
        $sql = "INSERT INTO plastic_tray__assy(code_hm, qty, author, stime) VALUES ('$code_hm', '$qty', '$author', '$stime')";
        $this->setQuery($sql);
        return $this->execute(array($code_hm, $qty, $author, $stime));
    }

    public function mAddAssyImport($code_hm, $qty, $author, $stime)
    {
        $sql = "INSERT INTO plastic_tray__assy_import(code_hm, qty, author, stime) VALUES ('$code_hm', '$qty', '$author', '$stime')";
        $this->setQuery($sql);
        return $this->execute(array($code_hm, $qty, $author, $stime));
    }

    public function mAddAssyExport($code_hm, $qty, $author, $stime)
    {
        $sql = "INSERT INTO plastic_tray__assy_export(code_hm, qty, author, stime) VALUES ('$code_hm', '$qty', '$author', '$stime')";
        $this->setQuery($sql);
        return $this->execute(array($code_hm, $qty, $author, $stime));
    }

    public function mAddDestroy($code_hm, $qty, $author, $stime)
    {
        $sql = "INSERT INTO plastic_tray__destroy(code_hm, qty, author, stime) VALUES ('$code_hm', '$qty', '$author', '$stime')";
        $this->setQuery($sql);
        return $this->execute(array($code_hm, $qty, $author, $stime));
    }

    public function mAddRack($name, $area, $width, $length, $height, $part_width, $part_length, $part_height, $author, $stime)
    {
        $sql = "INSERT INTO plastic_tray__rack(name, area, width, length, height, part_width, part_length, part_height, author, stime) VALUES ('$name', '$area', '$width', '$length', '$height', '$part_width', '$part_length', '$part_height', '$author', '$stime')";
        $this->setQuery($sql);
        return $this->execute(array($name, $area, $width, $length, $height, $part_width, $part_length, $part_height, $author, $stime));
    }

    public function mAddPositionMain($str_ok)
    {
        $sql = "INSERT INTO plastic_tray__main(name, sub_position, oo, position, oo_max) VALUES $str_ok";
        $this->setQuery($sql);

        // print_r($sql);

        return $this->execute(array($str_ok));
    }

    public function mAddCreateBarcode($barcode, $qty, $code_hm, $author, $stime)
    {
        $sql = "INSERT INTO plastic_tray__create_barcode(barcode, qty, code_hm, author, stime) VALUES ('$barcode', '$qty', '$code_hm', '$author', '$stime')";
        $this->setQuery($sql);
        return $this->execute(array($barcode, $qty, $code_hm, $author, $stime));
    }

    public function mAddExport($barcode, $code_hm, $qty, $author, $stime)
    {
        $sql = "INSERT INTO plastic_tray__export(barcode, code_hm, qty, author, stime) VALUES ('$barcode', '$code_hm', '$qty', '$author', '$stime')";
        $this->setQuery($sql);
        return $this->execute(array($barcode, $code_hm, $qty, $author, $stime));
    }

    public function mAddImport($barcode, $code_hm, $qty, $author, $stime)
    {
        $sql = "INSERT INTO plastic_tray__import(barcode, code_hm, qty, author, stime) VALUES ('$barcode', '$code_hm', '$qty', '$author', '$stime')";
        $this->setQuery($sql);
        return $this->execute(array($barcode, $code_hm, $qty, $author, $stime));
    }

    public function mAddMoveTemp($barcode, $code_hm, $qty, $author, $stime)
    {
        $sql = "INSERT INTO plastic_tray__move_temp(barcode, code_hm, qty, author, stime) VALUES ('$barcode', '$code_hm', '$qty', '$author', '$stime')";
        $this->setQuery($sql);
        return $this->execute(array($barcode, $code_hm, $qty, $author, $stime));
    }

    public function mEditModel($code_hm, $model, $qty, $size, $type_use, $author, $stime)
    {
        $sql = "UPDATE plastic_tray__model SET model = '$model', qty = '$qty', size = '$size', type_use = '$type_use', author = '$author', stime = '$stime' WHERE code_hm = '$code_hm'";
        $this->setQuery($sql);
        // print_r($sql);
        return $this->execute(array($code_hm, $model, $qty, $size, $type_use, $author, $stime));
    }

    public function mEditIncreaseAssy($code_hm, $qty, $author, $stime)
    {
        $sql = "UPDATE plastic_tray__assy SET  qty = qty + '$qty', author = '$author', stime = '$stime' WHERE code_hm = '$code_hm'";
        $this->setQuery($sql);
        // print_r($sql);
        return $this->execute(array($code_hm, $qty, $author, $stime));
    }

    public function mEditDecreaseAssy($code_hm, $qty, $author, $stime)
    {
        $sql = "UPDATE plastic_tray__assy SET qty = qty - '$qty' , author = '$author', stime = '$stime' WHERE code_hm = '$code_hm'";
        $this->setQuery($sql);
        // print_r($sql);
        return $this->execute(array($code_hm, $qty, $author, $stime));
    }

    public function mEditRack($name, $area, $width, $length, $height, $part_width, $part_length, $part_height, $author, $stime)
    {
        $sql = "UPDATE plastic_tray__rack SET  area = '$area', width = '$width', length = '$length', height = '$height', part_width = '$part_width', part_length = '$part_length', part_height = '$part_height', author = '$author', stime = '$stime' WHERE name = '$name'";
        $this->setQuery($sql);
        // print_r($sql);
        return $this->execute(array($name, $area, $width, $length, $height, $part_width, $part_length, $part_height, $author, $stime));
    }

    public function mEditDeleteMain($barcode)
    {
        $sql = "UPDATE plastic_tray__main SET  barcode = '', code_hm = '', code_hm_size = '', qty = '0', author = '', stime = 'NULL' WHERE barcode = '$barcode'";
        $this->setQuery($sql);
        // print_r($sql);
        return $this->execute(array($barcode));
    }
    public function mEditAddMain($barcode, $position,  $code_hm, $size, $qty, $author, $stime)
    {
        $sql = "UPDATE plastic_tray__main SET  barcode = '$barcode', code_hm = '$code_hm', code_hm_size = '$size', qty = '$qty', author = '$author', stime = '$stime' WHERE position = '$position'";
        $this->setQuery($sql);
        // print_r($sql);
        return $this->execute(array($barcode));
    }

    public function mEditCreateBarcode($barcode)
    {
        $sql = "UPDATE plastic_tray__create_barcode SET  status = '0' WHERE barcode = '$barcode'";
        $this->setQuery($sql);
        // print_r($sql);
        return $this->execute(array($barcode));
    }

    public function mDelAssy($code_hm)
    {
        $sql = "DELETE FROM plastic_tray__assy WHERE code_hm ='$code_hm'";
        $this->setQuery($sql);
        return $this->execute(array());
    }

    public function mDelMoveTemp($barcode)
    {
        $sql = "DELETE FROM plastic_tray__move_temp WHERE barcode ='$barcode'";
        $this->setQuery($sql);
        return $this->execute(array());
    }

    public function mDelPositionMain($name)
    {
        $sql = "DELETE FROM plastic_tray__main WHERE name ='$name'";
        $this->setQuery($sql);
        return $this->execute(array());
    }
}

?>
<!--  -->