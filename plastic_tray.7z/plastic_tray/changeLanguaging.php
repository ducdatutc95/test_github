<?php
date_default_timezone_set("Asia/Ho_Chi_Minh");
$stime = date('Y-m-d H:i:s');

session_start();
$author = "ERROR";
if (isset($_SESSION['id'])) {
    $author = $_SESSION['id'];
}

include('controller.php');
$data = new cEms();

$language = $_POST['language'];

$_SESSION['lg'] = $language;
print_r($language);

$data->cEditLanguage($author, $language);
?>

<!--  -->