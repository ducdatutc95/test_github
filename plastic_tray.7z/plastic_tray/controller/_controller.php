<?php
date_default_timezone_set("Asia/Ho_Chi_Minh");
include('../model/_model.php');

// One c_class
// + cBase
// + cEms

class cBase
{
    public function cGet()
    {
        $data = new mBase();
        $result = $data->mGet();
        return $result;
    }

    public function cAdd($a, $b)
    {
        $data = new mBase();
        $data->mAdd($a, $b);
    }

    public function cEdit($a, $b)
    {
        $data = new mBase();
        $data->mEdit($a, $b);
    }

    public function cDel()
    {
        $data = new mBase();
        $data->mDel();
    }
}

class cEms
{
    // Start User Query
    // Start User Query
    // Start User Query
    public function cGetUser($token)
    {
        $data = new mUser();
        $result = $data->mGetUser($token);
        return $result;
    }

    public function cCheckToken()
    {
        if (isset($_COOKIE['token'])) {
            $token = $_COOKIE['token'];
            $data = new mUser();
            $userInfo = $data->mGetUser($token);

            if (empty($userInfo)) {
                $res = ["status" => false, "data" => "Token Expried. Please login again !"];
            } else {
                $res = ["status" => true, "data" => $userInfo];
            }
        } else {
            $res = ["status" => false, "data" => "Token Expried. Please login again !"];
        }

        return $res;
    }

    public function cLogin($id, $pass)
    {
        $data = new mUser();
        $result = $data->mLogin($id, $pass);
        if ($result) {
            $sTime = date("Y-m-d h:i:s");
            $token = $result->id . $sTime;
            setcookie('token', md5($token), time() + 7 * 24 * 3600);
            $data->mSetToken($token, $id);
            if (isset($_SESSION['logError'])) {
                unset($_SESSION['logError']);
            }
            header('Location:index');
            exit();
        } else {
            echo '<script>alert("Sai Thông Tin Tài Khoản");</script>';
        }
    }

    public function cChangePass($id, $pass, $newpass, $cfpass)
    {
        $data = new mUser();
        $result = $data->mLogin($id, $pass);
        if ($result) {
            if ($newpass == $cfpass) {
                $res = $data->mChangePass($id, $newpass);
                // echo $res;
                echo '<script>alert("Change pass success!");</script>';
                header('Location:index');
                exit();
            } else {
                echo '<script>alert("New pass and Pass confirm do not match");</script>';
                // header('Location:changePass');
                // exit();
            }
        } else {
            echo '<script>alert("Wrong old password");</script>';
            // header('Location:changePass');
            // exit();
        }
    }
    // End User Query
    // End User Query
    // End User Query


    // Start Main Query
    public function cGetLanguage($lang)
    {
        $data = new mEms();
        $result = $data->mGetLanguage($lang);

        $arr = array();
        foreach ($result as $key) {
            $arr[0][$key->id] =  $key->lang;
        }

        return $arr[0];
    }

    public function cGetMain($name)
    {
        $data = new mEms();
        $result = $data->mGetMain($name);
        return $result;
    }

    public function cGetMainExist()
    {
        $data = new mEms();
        $result = $data->mGetMainExist();
        return $result;
    }

    public function cGetMainShow($code_hm, $model, $fromTime, $toTime)
    {
        $data = new mEms();
        $result = $data->mGetMainShow($code_hm, $model, $fromTime, $toTime);
        return $result;
    }

    public function cGetMainBarcode($type)
    {
        $data = new mEms();
        $result = $data->mGetMainBarcode($type);
        return $result;
    }

    public function cMainSubPosUnique($area, $name)
    {
        $data = new mEms();
        $result = $data->mMainSubPosUnique($area, $name);
        return $result;
    }

    public function cGetModel($code_hm, $model, $size, $type_use)
    {
        $data = new mEms();
        $result = $data->mGetModel($code_hm, $model, $size, $type_use);
        return $result;
    }

    public function cGetAssy($code_hm, $model, $fromTime, $toTime)
    {
        $data = new mEms();
        $result = $data->mGetAssy($code_hm, $model, $fromTime, $toTime);
        return $result;
    }

    public function cGetAssyExport($code_hm, $model, $fromTime, $toTime)
    {
        $data = new mEms();
        $result = $data->mGetAssyExport($code_hm, $model, $fromTime, $toTime);
        return $result;
    }

    public function cGetAssyImport($code_hm, $model, $fromTime, $toTime)
    {
        $data = new mEms();
        $result = $data->mGetAssyImport($code_hm, $model, $fromTime, $toTime);
        return $result;
    }

    public function cGetImport($code_hm, $model, $fromTime, $toTime)
    {
        $data = new mEms();
        $result = $data->mGetImport($code_hm, $model, $fromTime, $toTime);
        return $result;
    }

    public function cGetExport($code_hm, $model, $fromTime, $toTime)
    {
        $data = new mEms();
        $result = $data->mGetExport($code_hm, $model, $fromTime, $toTime);
        return $result;
    }

    public function cGetDestroy($code_hm, $model, $fromTime, $toTime)
    {
        $data = new mEms();
        $result = $data->mGetDestroy($code_hm, $model, $fromTime, $toTime);
        return $result;
    }

    public function cGetSumDestroy($code_hm, $model, $fromTime, $toTime)
    {
        $data = new mEms();
        $result = $data->mGetSumDestroy($code_hm, $model, $fromTime, $toTime);
        return $result;
    }

    public function cGetRack($name, $position)
    {
        $data = new mEms();
        $result = $data->mGetRack($name, $position);
        return $result;
    }

    public function cGetNameRackUnique()
    {
        $data = new mEms();
        $result = $data->mGetNameRackUnique();
        return $result;
    }

    public function cGetCreateBarcode()
    {
        $data = new mEms();
        $result = $data->mGetCreateBarcode();
        return $result;
    }

    public function cGetMoveTemp()
    {
        $data = new mEms();
        $result = $data->mGetMoveTemp();
        return $result;
    }

    public function cAddModel($code_hm, $model, $qty, $size, $type_use, $author, $stime)
    {
        $data = new mEms();
        $data->mAddModel($code_hm, $model, $qty, $size, $type_use, $author, $stime);
    }

    public function cAddAssy($code_hm, $qty, $author, $stime)
    {
        $data = new mEms();
        $data->mAddAssy($code_hm, $qty, $author, $stime);
    }

    public function cAddDestroy($code_hm, $qty, $author, $stime)
    {
        $data = new mEms();
        $data->mAddDestroy($code_hm, $qty, $author, $stime);
    }

    public function cAddAssyImport($code_hm, $qty, $author, $stime)
    {
        $data = new mEms();
        $data->mAddAssyImport($code_hm, $qty, $author, $stime);
    }

    public function cAddAssyExport($code_hm, $qty, $author, $stime)
    {
        $data = new mEms();
        $data->mAddAssyExport($code_hm, $qty, $author, $stime);
    }

    public function cAddRack($name, $area, $width, $length, $height, $part_width, $part_length, $part_height, $author, $stime)
    {
        $data = new mEms();
        $data->mAddRack($name, $area, $width, $length, $height, $part_width, $part_length, $part_height, $author, $stime);
    }

    public function cAddPositionMain($str_ok)
    {
        $data = new mEms();
        $data->mAddPositionMain($str_ok);
    }

    public function cAddCreateBarcode($barcode, $qty, $code_hm, $author, $stime)
    {
        $data = new mEms();
        $data->mAddCreateBarcode($barcode, $qty, $code_hm, $author, $stime);
    }

    public function cAddExport($barcode, $code_hm, $qty, $author, $stime)
    {
        $data = new mEms();
        $data->mAddExport($barcode, $code_hm, $qty, $author, $stime);
    }

    public function cAddImport($barcode, $code_hm, $qty, $author, $stime)
    {
        $data = new mEms();
        $data->mAddImport($barcode, $code_hm, $qty, $author, $stime);
    }

    public function cAddMoveTemp($barcode, $code_hm, $qty, $author, $stime)
    {
        $data = new mEms();
        $data->mAddMoveTemp($barcode, $code_hm, $qty, $author, $stime);
    }

    public function cEditModel($code_hm, $model, $qty, $size, $type_use, $author, $stime)
    {
        $data = new mEms();
        $data->mEditModel($code_hm, $model, $qty, $size, $type_use, $author, $stime);
    }

    public function cEditCreateBarcode($barcode)
    {
        $data = new mEms();
        $data->mEditCreateBarcode($barcode);;
    }

    public function  cEditDecreaseAssy($code_hm, $qty, $author, $stime)
    {
        $data = new mEms();
        $data->mEditDecreaseAssy($code_hm, $qty, $author, $stime);
    }

    public function cEditIncreaseAssy($code_hm, $qty, $author, $stime)
    {
        $data = new mEms();
        $data->mEditIncreaseAssy($code_hm, $qty, $author, $stime);
    }

    public function cEditDeleteMain($barcode)
    {
        $data = new mEms();
        $data->mEditDeleteMain($barcode);
    }

    public function cEditAddMain($barcode, $position,  $code_hm, $size, $qty, $author, $stime)
    {
        $data = new mEms();
        $data->mEditAddMain($barcode, $position,  $code_hm, $size, $qty, $author, $stime);
    }

    public function cEditRack($name, $area, $width, $length, $height, $o_width, $o_length, $o_height, $author, $stime)
    {
        $data = new mEms();
        $data->mEditRack($name, $area, $width, $length, $height, $o_width, $o_length, $o_height, $author, $stime);
    }

    public function cDelAssy($code_hm)
    {
        $data = new mEms();
        $data->mDelAssy($code_hm);
    }

    public function cDelMoveTemp($barcode)
    {
        $data = new mEms();
        $data->mDelMoveTemp($barcode);
    }

    public function cDelPositionMain($name)
    {
        $data = new mEms();
        $data->mDelPositionMain($name);
    }

    // End Main Query
}
