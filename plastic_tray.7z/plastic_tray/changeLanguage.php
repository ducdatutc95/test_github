<?php
session_start();

include('controller.php');
$data = new cEms();

$lang  = isset($_SESSION['lg']) ? $_SESSION['lg'] : 'en';
$translations = $data->cGetLanguage($lang);



if (($_SESSION['type'] != 'TRAY' && $_SESSION['type'] != 'ADMIN')) {
    echo '<span class="dd_no_access__text">' . $translations['no_access'] . ' ! <br> ' . $translations['let_contact_admin_for_support'] . '.</span>';
    exit();
}

?>

<div class="modal-header">
    <h5 class="modal-title card-title" style="color: blue; font-size: 2rem; font-weight: 600;"> <?php echo $translations['change'] . ' ' . $translations['language']; ?>:</h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true" style="font-size: 2rem;">&times;</span>
    </button>
</div>

<div class="modal-body">

    <div class="dd_grid">
        <div class="dd_row">

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6">
                <div class="dd_input_group">
                    <div class="dd_input_group_prepend">
                        <label for="im_model" class="dd_input_group_label dd_input_group_label-nowrap"><?php echo $translations['language']; ?></label>
                    </div>

                    <select name="" id="lang_language" class="dd_input_group_control">
                        <option value="en" <?php if ($lang == "en") { ?> selected <?php } ?>>English</option>
                        <option value="vi" <?php if ($lang == "vi") { ?> selected <?php } ?>>Vietnamese</option>
                    </select>
                </div>
            </div>

            <div class="dd_col dd_c-12 dd_m-12 dd_l-6">
                <div class="dd_btn-group">
                    <button
                        class="dd_btn dd_btn--size-small dd_btn--success"
                        id="lang_confirm">
                        <?php echo $translations['confirm']; ?>
                    </button>
                </div>
            </div>

        </div>
    </div>
</div>

<script>
    $(document).ready(function() {

        $("#lang_confirm").click(function() {

            $("#lang_confirm").remove();

            var language = $("#lang_language").val();

            // console.log(arrDatas)
            $.post('changeLanguaging', {
                    language: language
                },
                function(data) {

                    window.location.reload();

                });
        })
    })
</script>