<?php
date_default_timezone_set("Asia/Ho_Chi_Minh");
session_start();

require('./controller.php');
$data = new cEms;

if (empty($_SESSION['id'])) {
    header('Location:../login.php');
}


if ($_SESSION['type'] != 'TRAY' && $_SESSION['type'] != 'ADMIN') {
    header('Location:../index.php');
    exit();
}

if (isset($_COOKIE['token'])) {
    $token = $_COOKIE['token'];
    $userInfo = $data->cGetUser($token);
    if (empty($userInfo)) {
        header("Location:../login");
        exit();
    }
} else {
    header("Location:../login");
    exit();
}


$lang  = isset($_SESSION['lg']) ? $_SESSION['lg'] : 'en';
$translations = $data->cGetLanguage($lang);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <title> Tray </title>

    <link
        rel="shortcut icon"
        href="./vendor/library_xauxa/assets/img/favicon/apple-touch-icon.png"
        type="image/x-icon" />

    <link
        rel="stylesheet"
        href="./vendor/font/fontawesome-free-5.15.4-web/css/all.min.css" />

    <link href="./vendor/bootstrap/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="./vendor/bootstrap/bootstrap.css" rel="stylesheet" type="text/css">

    <link href="./vendor/datatable/dataTables.min.css" rel="stylesheet" type="text/css" />
    <link href="./vendor/datatable/buttons.dataTables.min.css" rel="stylesheet" type="text/css" />
    <link href="./vendor/datatable/select.dataTables.css" rel="stylesheet" type="text/css" />
    <!-- <link href="./vendor/datatable/responsive.dataTables.min.css" rel="stylesheet" type="text/css" /> -->

    <link rel="stylesheet" href="./vendor/library_xauxa/assets/css/base.css" />
    <link rel="stylesheet" href="./vendor/library_xauxa/assets/css/common.css" />

    <link rel="stylesheet" href="./vendor/library_xauxa/assets/css/header.css" />
    <link rel="stylesheet" href="./vendor/library_xauxa/assets/css/footer.css" />

    <link rel="stylesheet" href="./vendor/library_xauxa/assets/css/input.css" />
    <link rel="stylesheet" href="./vendor/library_xauxa/assets/css/button.css" />
    <link rel="stylesheet" href="./vendor/library_xauxa/assets/css/sidebare.css" />

    <link rel="stylesheet" href="./vendor/library_xauxa/assets/css/grid.css" />
    <link rel="stylesheet" href="./vendor/library_xauxa/assets/css/sidebare.css" />
    <link rel="stylesheet" href="./vendor/library_xauxa/assets/css/responsive.css" />
    <link rel="stylesheet" href="./vendor/library_xauxa/assets/css/breadcrumb.css" />
    <link rel="stylesheet" href="./vendor/library_xauxa/assets/css/text_long.css" />
    <link rel="stylesheet" href="./vendor/library_xauxa/assets/css/container.css" />
    <link rel="stylesheet" href="./vendor/library_xauxa/assets/css/table.css" />
    <link rel="stylesheet" href="./vendor/library_xauxa/assets/css/text_long.css" />
    <link rel="stylesheet" href="./vendor/library_xauxa/assets/css/tooltip.css" />

    <link rel="stylesheet" href="./vendor/library_xauxa/fix_default/fix_default.css">

    <link rel="stylesheet" href="./vendor/library_xauxa/locals/css/style.css" />
</head>

<body>
    <div class="dd_aplication">
        <div class="dd_header">
            <div class="dd_header_part">
                <a href="../index.php" class="dd_header_logo">
                    <span class="dd_header_logo_text dd_header_logo_up"> <?php echo  $translations['tray']; ?> </span>
                    <span class="dd_header_logo_text dd_header_logo_down"> <?php echo $translations['production']; ?> </span>
                </a>

                <label for="dd_container_sidebar_input" class="dd_header_sidebar">
                    <i class="fas fa-exchange-alt dd_header_sidebar_switch"></i>
                </label>
            </div>

            <nav class="dd_header_select_pc">
                <ul class="dd_header_pc__list">
                    <li class="dd_header_pc__item">
                        <a href="index.php" class="dd_header_pc__link  dd_header_pc_tray">
                            <i class="fas fa-home dd_nav_icon"></i> <?php echo $translations['home']; ?> - Tray
                        </a>

                        <ul class="dd_header_pc_child__list">
                            <li class="dd_header_pc_child__item">
                                <a href="import.php" class="dd_header_pc_child__link dd_header_pc_tray_import">
                                    <i class="fas fa-download"></i> <?php echo $translations['history'] . ' - ' . $translations['import']; ?>
                                </a>
                            </li>

                            <li class="dd_header_pc_child__item">
                                <a href="export.php" class="dd_header_pc_child__link dd_header_pc_tray_export">
                                    <i class="fas fa-upload"></i> <?php echo $translations['history'] . ' - ' . $translations['export']; ?>
                                </a>
                            </li>
                        </ul>
                    </li>

                    <li class="dd_header_pc__item">
                        <a href="assy.php" class="dd_header_pc__link dd_header_pc_assy">
                            <i class="fab fa-asymmetrik"></i> Assy
                        </a>

                        <ul class="dd_header_pc_child__list">
                            <li class="dd_header_pc_child__item">
                                <a href="assyImport.php" class="dd_header_pc_child__link dd_header_pc_assy_import">
                                    <i class="fas fa-download"></i> <?php echo $translations['history'] . ' - ' . $translations['import']; ?>
                                </a>
                            </li>

                            <li class="dd_header_pc_child__item">
                                <a href="assyExport.php" class="dd_header_pc_child__link dd_header_pc_assy_export">
                                    <i class="fas fa-upload"></i> <?php echo $translations['history'] . ' - ' . $translations['export']; ?>
                                </a>
                            </li>
                        </ul>
                    </li>

                    <li class="dd_header_pc__item">
                        <a href="destroy.php" class="dd_header_pc__link dd_header_pc_destroy">
                            <i class="fas fa-times"></i> </i> <?php echo  $translations['destroy']; ?>
                        </a>
                    </li>

                    <li class="dd_header_pc__item">
                        <a href="javascript:void(0);" class="dd_header_pc__link dd_header_navbar_disable dd_header_pc_setting">
                            <i class="fas fa-cog"> </i> <?php echo $translations['setting']; ?>
                        </a>

                        <ul class="dd_header_pc_child__list">
                            <li class="dd_header_pc_child__item">
                                <a href="configModel.php" class="dd_header_pc_child__link dd_header_pc_setting_model">
                                    <i class="fas fa-sitemap"></i> Model
                                </a>
                            </li>

                            <li class="dd_header_pc_child__item">
                                <a href="configRack.php" class="dd_header_pc_child__link dd_header_pc_setting_rack">
                                    <i class="fab fa-buromobelexperte"></i> <?php echo $translations['rack']; ?>
                                </a>
                            </li>
                        </ul>
                    </li>

                    <li class="dd_header_pc__item dd_split">
                        <a href="javascript:void(0);" class="dd_header_pc__link dd_header_navbar_disable">
                            <i class="fas fa-user"></i> <?php echo $userInfo->name; ?>
                        </a>

                        <ul class="dd_header_pc_child__list">

                            <li class="dd_header_pc_child__item">
                                <a href="javascript:void(0);" class="dd_header_pc_child__link" id="dd_change_language">
                                    <i class="fas fa-language"></i> <?php echo $translations['language']; ?>
                                </a>
                            </li>

                            <li class="dd_header_pc_child__item">
                                <a href="../editUser.php" class="dd_header_pc_child__link">
                                    <i class="fas fa-user-edit"></i> <?php echo $translations['edit_password']; ?>
                                </a>
                            </li>

                            <li class="dd_header_pc_child__item">
                                <a href="../logout.php" class="dd_header_pc_child__link">
                                    <i class="fas fa-sign-out-alt"></i> <?php echo $translations['logout']; ?>
                                </a>
                            </li>

                        </ul>
                    </li>
                </ul>
            </nav>

            <label for="dd_header_navbar_mobile_input" class="dd_header_mobile_menu">
                <i class="fas fa-bars dd_header_mobile_menu_icon"></i>
            </label>

            <input type="checkbox" class="dd_header_navbar_mobile_toggle" id="dd_header_navbar_mobile_input" />

            <label
                for="dd_header_navbar_mobile_input"
                class="dd_header_navbar_mobile_overlay"></label>

            <nav class="dd_header_select_mobile">
                <ul class="dd_header_mobile__list">
                    <li class="dd_header_mobile__item">
                        <a href="index.php" class="dd_header_mobile__link dd_header_mobile_tray">
                            <i class="fas fa-home dd_nav_icon"></i> <?php echo $translations['home']; ?> - Tray
                        </a>

                        <ul class="dd_header_mobile_child__list">
                            <li class="dd_header_mobile_child__item">
                                <a href="trayImport.php" class="dd_header_mobile_child__link dd_header_mobile_tray_import">
                                    <i class="fas fa-download"></i> <?php echo $translations['history'] . ' - ' . $translations['import']; ?>
                                </a>
                            </li>

                            <li class="dd_header_mobile_child__item">
                                <a href="trayExport.php" class="dd_header_mobile_child__link dd_header_mobile_tray_export">
                                    <i class="fas fa-upload"></i> <?php echo $translations['history'] . ' - ' . $translations['export']; ?>
                                </a>
                            </li>
                        </ul>
                    </li>

                    <li class="dd_header_mobile__item">
                        <a href="assy.php;" class="dd_header_mobile__link dd_header_mobile_assy">
                            <i class="fab fa-asymmetrik"></i> Assy
                        </a>

                        <ul class="dd_header_mobile_child__list">
                            <li class="dd_header_mobile_child__item">
                                <a href="assyImport.php" class="dd_header_mobile_child__link dd_header_mobile_assy_import">
                                    <i class="fas fa-download"></i> <?php echo $translations['history'] . ' - ' . $translations['import']; ?>
                                </a>
                            </li>

                            <li class="dd_header_mobile_child__item">
                                <a href="assyExport.php" class="dd_header_mobile_child__link dd_header_mobile_assy_export">
                                    <i class="fas fa-upload"></i> <?php echo $translations['history'] . ' - ' . $translations['export']; ?>
                                </a>
                            </li>
                        </ul>
                    </li>

                    <li class="dd_header_mobile__item">
                        <a href="destroy.php" class="dd_header_mobile__link dd_header_mobile_admin">
                            <i class="fas fa-user-shield"></i> <?php echo $translations['setting']; ?>
                        </a>
                    </li>

                    <li class="dd_header_mobile__item">
                        <a href="javascript:void(0);" class="dd_header_mobile__link dd_header_navbar_disable dd_header_mobile_setting">
                            <i class="fas fa-cog"> </i> <?php echo $translations['setting']; ?>
                        </a>

                        <ul class="dd_header_mobile_child__list">
                            <li class="dd_header_mobile_child__item">
                                <a href="configModel.php" class="dd_header_mobile_child__link dd_header_mobile_assy_model">
                                    <i class="fas fa-sitemap"></i> Model
                                </a>
                            </li>

                            <li class="dd_header_mobile_child__item">
                                <a href="configRack.php" class="dd_header_mobile_child__link dd_header_mobile_assy_rack">
                                    <i class="fab fa-buromobelexperte"></i> <?php echo $translations['rack']; ?>
                                </a>
                            </li>
                        </ul>
                    </li>


                    <li class="dd_header_mobile__item dd_split">
                        <a href="javascript:void(0);" class="dd_header_mobile__link dd_header_navbar_disable">
                            <i class="fas fa-user"></i> <?php echo $userInfo->name; ?>
                        </a>

                        <ul class="dd_header_mobile_child__list">
                            <li class="dd_header_mobile_child__item">
                                <a href="javascript:void(0);" class="dd_header_mobile_child__link">
                                    <i class="fas fa-language"></i> <?php echo $translations['language']; ?>
                                </a>
                            </li>

                            <li class="dd_header_mobile_child__item">
                                <a href="../editUser.php" class="dd_header_mobile_child__link">
                                    <i class="fas fa-user-edit"></i> <?php echo $translations['edit_password']; ?>
                                </a>
                            </li>

                            <li class="dd_header_mobile_child__item">
                                <a href="../logout.php" class="dd_header_mobile_child__link">
                                    <i class="fas fa-sign-out-alt"></i> <?php echo $translations['logout']; ?>
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>

                <label
                    for="dd_header_navbar_mobile_input"
                    class="dd_header_mobile__close">
                    <i class="fas fa-times"></i>
                </label>
            </nav>
        </div>