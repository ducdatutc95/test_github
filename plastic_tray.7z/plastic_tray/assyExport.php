<?php
include("header.php");

$timeTemp = strtotime("-10 Day");
$fromTime = date("Y-m-d", $timeTemp);

$timeTemp = strtotime("0 Day");
$toTime = date("Y-m-d", $timeTemp);

$resModel = $data->cGetModel('', '', '', '');
?>

<datalist id="list_code_hm">
    <?php foreach ($resModel as $key) { ?>
        <option value="<?php echo $key->code_hm; ?>"><?php echo $key->code_hm; ?></option>
    <?php } ?>
</datalist>

<datalist id="list_model">
    <?php foreach ($resModel as $key) { ?>
        <option value="<?php echo $key->model; ?>"><?php echo $key->model; ?></option>
    <?php } ?>
</datalist>

<div class="dd_container">
    <input
        type="checkbox"
        class="dd_container_sidebar_toggle"
        id="dd_container_sidebar_input" />

    <label
        for="dd_container_sidebar_input"
        class="dd_container_sidebar_overlay"></label>

    <div class="dd_container_sidebar dd_container_sidebar_responsive">
        <div class="dd_container_sidebar_content">

            <h3 class="dd_sidebar_filter"> <?php echo $translations['filter_data']; ?> </h3>


            <div class="dd_input_group">
                <div class="dd_input_group_prepend">
                    <label for="code_hm" class="dd_input_group_label">Code HM</label>
                </div>
                <input
                    id="code_hm"
                    list="list_code_hm"
                    type="text"
                    placeholder="<?php echo $translations['enter']; ?> Code HM"
                    class="dd_input_group_control" autocomplete="off" />
            </div>

            <div class="dd_input_group">
                <div class="dd_input_group_prepend">
                    <label for="model" class="dd_input_group_label">Model</label>
                </div>
                <input
                    id="model"
                    list="list_model"
                    type="text"
                    placeholder="<?php echo $translations['enter']; ?> Mode"
                    class="dd_input_group_control" autocomplete="off" />
            </div>

            <div class="dd_input_group">
                <div class="dd_input_group_prepend">
                    <label for="beginTime" class="dd_input_group_label"><?php echo $translations['from']; ?></label>
                </div>
                <input
                    id="beginTime"
                    type="date"
                    class="dd_input_group_control" value="<?php echo $fromTime ?>" />
            </div>

            <div class="dd_input_group">
                <div class="dd_input_group_prepend">
                    <label for="endTime" class="dd_input_group_label"><?php echo $translations['to']; ?></label>
                </div>
                <input
                    id="endTime"
                    type="date"
                    class="dd_input_group_control" value="<?php echo $toTime ?>" />
            </div>

            <div class="dd_btn-group_inline">
                <button
                    class="dd_btn dd_btn--size-small dd_btn--error"
                    id="reset">
                    <?php echo $translations['reset']; ?>
                </button>

                <button
                    class="dd_btn dd_btn--size-small dd_btn--success"
                    id="search">
                    <?php echo $translations['search']; ?>
                </button>
            </div>

        </div>
    </div>

    <div class="dd_container_right">
        <ul class="dd_container_right_breadcrumb">
            <li>
                <a href="index.php">
                    <i class="fas fa-map-marker-alt" style="color: red"></i> <?php echo $translations['home']; ?> - Tray
                </a>
            </li>

            <li>
                <a href="assy.php">
                    Assy
                </a>
            </li>

            <li> <?php echo $translations['history'] . ' ' . $translations['export']; ?> </li>

            <!-- <li>
                <i class="fas fa-map-marker-alt" style="color: red"></i> Home
            </li> -->
        </ul>

        <div class="dd_container_right_main dd_responsive_table" id="dd_main_content">
        </div>
    </div>
</div>

<?php
include('footer.php');
?>

<script>
    change_navbar_active(".dd_header_pc_assy", ".dd_header_mobile_assy");

    $(document).ready(function() {

        var fromTime = '<?php echo $fromTime; ?>';
        var toTime = '<?php echo $toTime; ?>';

        loadAssyExport();

        $("#reset").click(function() {
            $("#code_hm").val("");
            $("#model").val("");

            $("#beginTime").val(fromTime);
            $("#endTime").val(toTime);

            loadAssyExport();
        })

        $("#search").click(function() {
            loadAssyExport();
        })
    });
</script>