<?php
include('header.php');

?>

<body>
   <div class="container-fluid">
    <div class="row main-bar">
      <div class="location">
        <i class="fa fa-map-marker i-right" style="color:red;"> </i><span>PRODUCTION >> [SET] Octa QR Code - Stock Management</span>
        
      </div>
      <div class="bar-center">

      </div>
      <div class="option_box">
      </div>
    </div>
      <div class="row">
        <div class="mg0 left-filter" id="left-filter">
          
          <div class="panel panel-primary">
            <div class="panel-heading">
              <i class="fas fa-filter i-right"></i>Filters
            </div>
            <div class="panel-body filters-plan">
              <label>QR :</label>
             <input type="text" id="qr_filter" class="form-control form-control-sm">
              
            <label>Line :</label>
             <input type="text" id="line_filter" class="form-control form-control-sm" list="arrLine">
               <datalist id="arrLine">
                <option value="LINE1">LINE1</option>
              </datalist>
            <label>Model Code :</label>
             <input type="text" id="model_filter" class="form-control form-control-sm" list="arrCode">
               <datalist id="arrCode">
                <option value="S24">S24</option>
              </datalist>
            <label>Date Start :</label>
            <input type="date" id="dateStart" class="form-control form-control-sm" value="<?php 
            $start = strtotime("-0 Day");
          echo date('Y-m-d'); ?>">
           <label>Date End :</label>
           <input type="date" id="dateEnd" class="form-control form-control-sm" value="<?php 
            $start = strtotime("+1 Day");
          echo date('Y-m-d', $start); ?>">
            </div>

          </div>
          <div class="panel panel-primary resouce-rack">
            <div class="panel-heading">
              <i class="fas fa-database i-right"></i>Stock
            </div>
            <div class="panel-body" id="resouce_stock"></div>
          </div>
          <button class="btn btn-primary btn-sm appy-filter form-control" id="apply"><i class="fa fa-check i-right"></i>Apply</button>
        </div>
        <div class="body-right mg0">

          <div class="mgl-5 data-content">

            <div class="panel panel-primary">
              <div class="panel-heading-content">
                <div class="title_box">
                  <i class="fas fa-info-circle i-right"></i>[SET] Octa QR Code - Stock Management
                </div>
              </div>
              <div class="panel-body-content row" id="show">
              </div>
            </div>
          </div>
        </div>
      </div>
   </div>
   
<?php
include('footer.php');
?>
<script type="text/javascript">
  $(document).ready(function(){
    let dataStock = [
      {"id":"LINE","text":"LINE"},
      {"id":"REPAIR","text":"REPAIR"},
      {"id":"QC","text":"QC"},
      {"id":"OUT","text":"OUT"}
    ]
  
    listFilterStock = dataStock.map(e=>{
      return e.id
    });
    let treeStatus = new Tree('#resouce_stock', {
        data: [{ id: '-1', text: 'SET', children: dataStock }],
        closeDepth: 3,
        loaded: function () {
            this.values = listFilterStock

        },
        onChange: function () {
            listFilterStock = this.values
        }
    })
      // loadHisStock(listFilterStock)
      $('#apply').click(function(){
        loadHisStock(listFilterStock)
      });
  })
</script>

