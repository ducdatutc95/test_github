<?php
include('header.php');
$listModel = $data->cGetListModel();

?>

<body>
   <div class="container-fluid">
    <div class="row main-bar">
      <div class="location">
        <i class="fa fa-map-marker i-right" style="color:red;"> </i><span>PRODUCTION >> [SET] Production Plan</span>
        
      </div>
      <div class="bar-center">

      </div>
      <div class="option_box">
      </div>
    </div>
      <div class="row">
        <div class="mg0 left-filter" id="left-filter">
          <div class="panel panel-primary">
            <div class="panel-heading">
              <i class="fas fa-filter i-right"></i>Filters
            </div>
            <div class="panel-body filters-plan">
            <label>Direct :</label>
             
              <select id="line_filter" class="form-control form-control-sm">
                    <option></option>
                    <?php
                        for ($i=1; $i <= 7; $i++) { 
                           echo '<option value="'.($i < 10 ? 'DMC-0'.$i : "DMC-".$i).'">Line '.($i < 10 ? 'DMC-0'.$i : "DMC-".$i).'</option>';
                        }
                        for ($i=1; $i <= 7; $i++) { 
                           echo '<option value="'.($i < 10 ? 'EMS-0'.$i : "EMS-".$i).'">Line '.($i < 10 ? 'EMS-0'.$i : "EMS-".$i).'</option>';
                        }
                    ?>
                    <option value="01" selected>Line 01</option>
                    <?php
                        for ($i=2; $i <= 32; $i++) { 
                           echo '<option value="'.($i < 10 ? '0'.$i : $i).'">Line '.($i < 10 ? '0'.$i : $i).'</option>';
                        }
                    ?>
                </select>
            <label>Model Code :</label>
             <input type="text" id="model_filter" class="form-control form-control-sm" list="arrModelCode">
               <datalist id="arrModelCode">
                <?php
                foreach ($listModel as $key) {
                  ?>
                      <option value="<?php echo $key->model; ?>"><?php echo $key->model; ?></option>
                  <?php
                  }
                ?>
              </datalist>
              <datalist id="arrProcess">
                <?php
                foreach ($listProcess as $key) {
                  ?>
                      <option value="<?php echo $key->process; ?>"><?php echo $key->process; ?></option>
                  <?php
                  }
                ?>
              </datalist>
            <label>Date Start :</label>
            <input type="date" id="dateStart" class="form-control form-control-sm" value="<?php 
            $start = strtotime("-30 Day");
            echo date('Y-m-d', $start); ?>">
           <label>Date End :</label>
           <input type="date" id="dateEnd" class="form-control form-control-sm" value="<?php 
            $start = strtotime("+1 Day");
            echo date('Y-m-d', $start); ?>">
            </div>
          </div>
          
          <button class="btn btn-primary btn-sm appy-filter form-control" id="apply"><i class="fa fa-check i-right"></i>Apply</button>
        </div>
        <div class="body-right mg0">
          <div class="mgl-5 data-content">
            <div class="panel panel-primary">
              <div class="panel-heading-content">
                <div class="title_box">
                  <i class="fas fa-info-circle i-right"></i>[SET] Production Plan - Production Plan
                </div>
              </div>
              <div class="panel-body-content row" id="show">
              </div>
            </div>
          </div>
        </div>
      </div>
   </div>
   
<?php
include('footer.php');
?>
<script type="text/javascript">
  $(document).ready(function(){
    
      loadPlan()
      $('#apply').click(function(){
        loadPlan()
      });
  })
</script>

