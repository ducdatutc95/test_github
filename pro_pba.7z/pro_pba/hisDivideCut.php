<?php include('header.php');
$resListCode = $data->cGetHisCode();
$resListLine = $data->cGetHisLine();
?>

<body>
    <div class="container-fluid">
        <div class="row main-bar">
            <div class="location">
                <i class="fa fa-map-marker i-right" style="color:red;"> </i><span>PRODUCTION >> [PBA] History Input Line</span>

            </div>
            <div class="bar-center">

            </div>
            <div class="option_box">
            </div>
        </div>

        <div class="row">

            <div class="col-md-2" style="padding-right: 2px;">
                <div class="panel panel-primary">

                    <div class="panel-heading">
                        <i class="fas fa-filter i-right"></i>Filters
                    </div>

                    <div class="panel-body filters-plan" style="position: relative;">
                        <label>Line :</label>
                        <input type="text" id="line_filter" list="listLine" class="form-control form-control-sm" placeholder="Enter Line">
                        <datalist id="listLine">
                            <?php
                            foreach ($resListLine as $key) {
                            ?>
                                <option value="<?php echo $key->line; ?>"><?php echo $key->line; ?></option>
                            <?php
                            }
                            ?>
                        </datalist>

                        <label>Code :</label>
                        <input type="text" id="code_filter" list="listCode" class="form-control form-control-sm" placeholder="Enter Line">
                        <datalist id="listCode">
                            <?php
                            foreach ($resListCode as $key) {
                            ?>
                                <option value="<?php echo $key->code; ?>"><?php echo $key->code; ?></option>
                            <?php
                            }
                            ?>
                        </datalist>

                        <label>Date Start :</label>
                        <input type="date" id="dateStart" class="form-control form-control-sm" style="margin-bottom: 4px;" value="<?php $start = strtotime("-1 Day");
                                                                                                                                    echo date('Y-m-d', $start); ?>">

                        <div class="input-group mb-3 mt-1">
                            <input type="number" list="list_hour_start" id="hour_start" class="form-control" placeholder="Hour" value="20">
                            <datalist id="list_hour_start">
                                <?php for ($i = 0; $i <= 23; $i++) { ?>
                                    <option value="<?php echo $i < 10 ? '0' . $i : $i; ?>"><?php echo $i < 10 ? '0' . $i : $i; ?></option>
                                <?php } ?>
                            </datalist>

                            <input type="number" list="list_minute_start" id="minute_start" class="form-control" placeholder="Minute" value="00">
                            <datalist id="list_minute_start">
                                <?php for ($i = 0; $i <= 59; $i++) { ?>
                                    <option value="<?php echo $i < 10 ? '0' . $i : $i; ?>"><?php echo $i < 10 ? '0' . $i : $i; ?></option>
                                <?php } ?>
                            </datalist>
                        </div>


                        <label>Date End :</label>
                        <input type="date" id="dateEnd" class="form-control form-control-sm" style="margin-bottom: 4px;" value="<?php $start = strtotime("+1 Day");
                                                                                                                                echo date('Y-m-d', $start); ?>">

                        <div class="input-group mb-3 mt-1">
                            <input type="number" list="list_hour_end" id="hour_end" class="form-control" placeholder="Hour" value="08">
                            <datalist id="list_hour_end">
                                <?php for ($i = 0; $i <= 23; $i++) { ?>
                                    <option value="<?php echo $i < 10 ? '0' . $i : $i; ?>"><?php echo $i < 10 ? '0' . $i : $i; ?></option>
                                <?php } ?>
                            </datalist>

                            <input type="number" list="list_minute_end" id="minute_end" class="form-control" placeholder="Minute" value="00">
                            <datalist id="list_minute_end">
                                <?php for ($i = 0; $i <= 59; $i++) { ?>
                                    <option value="<?php echo $i < 10 ? '0' . $i : $i; ?>"><?php echo $i < 10 ? '0' . $i : $i; ?></option>
                                <?php } ?>
                            </datalist>
                        </div>
                    </div>

                </div>
                <button class="btn btn-primary btn-sm appy-filter form-control" id="apply"><i class="fa fa-check i-right"></i>Apply</button>
            </div>

            <div class="col-md-10" style="padding-left: 2px;">
                <div class="mgl-5 data-content">

                    <div class="panel panel-primary">
                        <div class="panel-heading-content">
                            <div class="title_box">
                                <i class="fas fa-info-circle i-right"></i>[PBA] History Input Line
                            </div>
                        </div>
                        <div class="panel-body-content row" id="show">

                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>


    <?php
    include('footer.php');
    ?>

    <script type="text/javascript">
        $(document).ready(function() {

            loadHisDivideCut();
            $('#apply').click(function() {
                loadHisDivideCut();
            });
            
        })
    </script>