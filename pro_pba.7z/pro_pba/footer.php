<section class="copyright" style="margin-top: 0.2em;">
	<div class="container">
		<div class="row">
			<div class="col-md-12 ">
				<div class="text-center text-black">
					&copy; System 2022 Created by 44247.
					All Rights Reserved by DreamTech Company
				</div>
			</div>
		</div>
	</div>
</section>
<script src='./vendor/js/socket.io.js'></script>
<script src="./vendor/js/jquery.js"></script>
<script src="./vendor/js/myQuery.js"></script>
<script src="./vendor/js/tree_menu.js"></script>
<script src="./vendor/chart/chartist.min.js"></script>
<script src="./vendor/chart/utils.js"></script>
<script src="./vendor/chart/chart.bundle.min.js"></script>
<script src="./vendor/js/tree.min.js"></script>
<script src="./vendor/js/sweetalert2.all.min.js"></script>
<script src="./vendor/bootstrap/bootstrap.min.js"></script>
<script src="./vendor/datatable/dataTables.min.js"></script>
<script src="./vendor/datatable/dataTables.select.js"></script>
<script src="./vendor/datatable/dataTables.buttons.min.js"></script>
<script src="./vendor/datatable/dataTables.buttonHtml5.min.js"></script>
<script src="./vendor/datatable/buttons.flash.min.js"></script>
<script src="./vendor/datatable/jszip.min.js"></script>
<script src="./vendor/bootstrap/moment.min.js"></script>
<script src="./vendor/bootstrap/bootstrap-datetimepicker.js"></script>
<script src="./vendor/datatable/dataTables.bootstrap4.min.js"></script>
<script src="./vendor/chart/chartjs-plugin.js"></script>
<script type="text/javascript" src="./vendor/chart/chart.min.js"></script>
<script type="text/javascript" src="./vendor/chart/chartjs-plugin-datalabels.min.js"></script>

</body>

</html>

