<?php
include ('database.php');
class mEms extends database
    {
        public function mLogin($id,$pass){
            $sql = "SELECT * FROM user WHERE id = '$id' AND pass = md5('$pass')";
            $this->setQuery($sql);
            return $this->loadRow(array());
        }

        public function mSetToken($token,$id){
			$sql = "UPDATE user Set token = md5('$token') WHERE id = '$id'";
			$this->setQuery($sql);
			return $this->execute();
		}

        public function mGetUser($token){
            $sql = "SELECT * FROM user WHERE token = '$token'";
            $this->setQuery($sql);
            return $this->loadRow(array());
        }
        public function mChangePass($id,$newPass){
            $sql = "UPDATE user SET pass = md5('$newPass') WHERE id = '$id'";
            $this->setQuery($sql);
            return $this->execute();
        }
// end user
// start all tasks

        public function mGetListModel(){
            $sql = "SELECT DISTINCT model FROM pba_pro_bom";
            $this->setQuery($sql);
            return $this->loadAllRows();
        }
        public function mGetListProcess(){
            $sql = "SELECT DISTINCT process FROM set_pro_bom";
            $this->setQuery($sql);
            return $this->loadAllRows();
        }

        public function mGetHisCode(){
            $sql = "SELECT DISTINCT code FROM pba_line_his";
            $this->setQuery($sql);
            return $this->loadAllRows();
        }

        public function mGetHisLine(){
            $sql = "SELECT DISTINCT line FROM pba_line_his";
            $this->setQuery($sql);
            return $this->loadAllRows();
        }
        
    }


