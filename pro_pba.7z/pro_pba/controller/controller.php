<?php
include('../model/model.php');
date_default_timezone_set("Asia/Ho_Chi_Minh");
class cEms
{

    public function cGetUser($token)
    {
        $data = new mEms();
        $result = $data->mGetUser($token);
        return $result;
    }
    public function cCheckToken()
    {
        if (isset($_COOKIE['token'])) {
            $token = $_COOKIE['token'];
            $data = new mEms();
            $userInfo = $data->mGetUser($token);

            if (empty($userInfo)) {
                $res = ["status" => false, "data" => "Token Expried. Please login again !"];
            } else {
                $res = ["status" => true, "data" => $userInfo];
            }
        } else {
            $res = ["status" => false, "data" => "Token Expried. Please login again !"];
        }
        return $res;
    }
    public function cFind($arr, $line, $code)
    {
        foreach ($arr as $key => $e) {
            if ($line == $e->line &&  $code == $e->code) {
                return $key;
            }
        }
        return -1;
    }
    public function cGetDataCheck()
    {
        $data = new mEms();
        $result = $data->mGetDataCheck();
        return $result;
    }
    public function cGetDataLine()
    {
        $data = new mEms();
        $result = $data->mGetDataLine();
        return $result;
    }

    public function cGetStock($qr, $line_filter, $model_filter, $diffTime, $limit)
    {
        $data = new mEms();
        $result = $data->mGetStock($qr, $line_filter, $model_filter, $diffTime, $limit);
        return $result;
    }
    public function cGetInvent($line_filter, $limit)
    {
        $data = new mEms();
        $result = $data->mGetInvent($line_filter, $limit);
        return $result;
    }

    public function cGetPlan($line_filter, $model_filter, $dateStart, $dateEnd)
    {
        $data = new mEms();
        $result = $data->mGetPlan($line_filter, $model_filter, $dateStart, $dateEnd);
        return $result;
    }

    public function cGetPlanFromMes($line_filter, $model_filter, $dateStart, $dateEnd)
    {
        $data = new mEms();
        $result = $data->mGetPlanFromMes($line_filter, $model_filter, $dateStart, $dateEnd);
        return $result;
    }

    public function cGetPlanDetailFromMes($id_plan)
    {
        $data = new mEms();
        $result = $data->mGetPlanDetailFromMes($id_plan);
        return $result;
    }

    public function cGetModelUnique($line_filter, $dateStart, $dateEnd)
    {
        $data = new mEms();
        $result = $data->mGetModelUnique($line_filter, $dateStart, $dateEnd);
        return $result;
    }

    public function cGetDetailPlanFromMes($line_filter, $shift, $sDate)
    {
        $data = new mEms();
        $result = $data->mGetDetailPlanFromMes($line_filter, $shift, $sDate);
        return $result;
    }

    public function cGetDataFuji($line_filter)
    {
        $data = new mFuji();
        $result = $data->mGetDataFuji($line_filter);
        return $result;
    }

    public function cGetQtyProd($line_filter, $model_filter)
    {
        $data = new mEms();
        $result = $data->mGetQtyProd($line_filter, $model_filter);
        return $result;
    }


    public function cGetTotalLine($line_filter)
    {
        $data = new mEms();
        $result = $data->mGetTotalLine($line_filter);
        return $result;
    }
    public function cGetRemainLine($line_filter)
    {
        $data = new mEms();
        $result = $data->mGetRemainLine($line_filter);
        return $result;
    }
    public function cGetZin($dateStart, $dateEnd)
    {
        $data = new mEms();
        $result = $data->mGetZin($dateStart, $dateEnd);
        return $result;
    }
    public function cGetPlanbyDay1($line_filter, $model_filter, $dTime, $listFilterProcess)
    {
        $data = new mEms();
        $result = $data->mGetPlanbyDay1($line_filter, $model_filter, $dTime, $listFilterProcess);
        return $result;
    }
    public function cGetStockMaterial($line_filter, $exp)
    {
        $data = new mEms();
        $result = $data->mGetStockMaterial($line_filter, $exp);
        return $result;
    }

    public function cGetBom($model_filter, $listFilterProcess)
    {
        $data = new mEms();
        $result = $data->mGetBom($model_filter, $listFilterProcess);
        return $result;
    }
    public function cGetLct()
    {
        $data = new mEms();
        $result = $data->mGetLct();
        return $result;
    }

    public function cGetLcts()
    {
        $data = new mEms();
        $result = $data->mGetLcts();
        return $result;
    }
    public function cGetCountbyLct()
    {
        $data = new mEms();
        $result = $data->mGetCountbyLct();
        return $result;
    }
    public function cGetQrByLct($lct)
    {
        $data = new mEms();
        $result = $data->mGetQrByLct($lct);
        return $result;
    }


    public function cGetExMaterialByDirect($direct, $date, $dateE)
    {
        $data = new mEms();
        $result = $data->mGetExMaterialByDirect($direct, $date, $dateE);
        return $result;
    }

    public function cGetMaterialByDirect($direct, $date, $dateE, $exp)
    {
        $data = new mEms();
        $data->mGetMaterialByDirect($direct, $date, $dateE, $exp);
    }

    public function cAddMaterialCheck($id, $start, $end, $author, $direct)
    {
        $data = new mEms();
        $result = $data->mAddMaterialCheck($id, $start, $end, $author, $direct);
        return $result;
    }
    public function cAddMaterialCheckDetail($id, $code, $qty, $realQty, $line, $note, $author, $sTime)
    {
        $data = new mEms();
        $result = $data->mAddMaterialCheckDetail($id, $code, $qty, $realQty, $line, $note, $author, $sTime);
        return $result;
    }

    public function cGetInventById($id)
    {
        $data = new mEms();
        $result = $data->mGetInventById($id);
        return $result;
    }
    public function cUpStatusCheck($id)
    {
        $data = new mEms();
        $data->mUpStatusCheck($id);
    }
    public function cDelTotal($id)
    {
        $data = new mEms();
        $data->mDelTotal($id);
    }

    public function cAddTotal($line, $code, $qty_real)
    {
        $data = new mEms();
        $data->mAddTotal($line, $code, $qty_real);
    }



    public function cGetInOutMaterialByDirect($direct, $date, $dateE, $exp)
    {
        $data = new mEms();
        $result = $data->mGetInOutMaterialByDirect($direct, $date, $dateE, $exp);
        return $result;
    }
    public function cGetInfoLastCheck($direct)
    {
        $data = new mEms();
        $result = $data->mGetInfoLastCheck($direct);
        return $result;
    }

    public function cGetInfoLastBynow($direct, $end)
    {
        $data = new mEms();
        $result = $data->mGetInfoLastBynow($direct, $end);
        return $result;
    }
    public function cGetDetailCheckById($id)
    {
        $data = new mEms();
        $result = $data->mGetDetailCheckById($id);
        return $result;
    }

    public function cGetInfoById($id)
    {
        $data = new mEms();
        $result = $data->mGetInfoById($id);
        return $result;
    }

    public function cGetListCheckByDay($direct, $dTime)
    {
        $data = new mEms();
        $result = $data->mGetListCheckByDay($direct, $dTime);
        return $result;
    }

    public function cGetInMaterialByDirect($direct, $date, $dateE)
    {
        $data = new mEms();
        $result = $data->mGetInMaterialByDirect($direct, $date, $dateE);
        return $result;
    }

    public function cGetHisStock($qr, $line_filter, $model_filter, $dateStart, $dateEnd, $listFilterProcess)
    {
        $data = new mEms();
        $result = $data->mGetHisStock($qr, $line_filter, $model_filter, $dateStart, $dateEnd, $listFilterProcess);
        return $result;
    }

    public function cGetLossTime($line_filter, $dateStart, $dateEnd)
    {
        $data = new mEms();
        $result = $data->mGetLossTime($line_filter, $dateStart, $dateEnd);
        return $result;
    }

    public function cGetQr($qr)
    {
        $data = new mEms();
        $result = $data->mGetQr($qr);
        return $result;
    }

    public function cGetMaterialCheck($id, $exp)
    {
        $data = new mEms();
        $result = $data->mGetMaterialCheck($id, $exp);
        return $result;
    }

    public function cGetZinPending()
    {
        $data = new mEms();
        $result = $data->mGetZinPending();
        return $result;
    }

    public function cGetZinRecived()
    {
        $data = new mEms();
        $result = $data->mGetZinRecived();
        return $result;
    }

    public function cConfirmZin($zin, $line, $ltime, $author)
    {
        $data = new mEms();
        $data->mConfirmZin($zin, $line, $ltime, $author);
        $data->mConfirmZinP($zin, $line, $ltime, $author);
        $data->mConfirmZinHis($zin, $line, $ltime, $author);
    }

    public function cReturnZin($zin, $ltime, $author)
    {
        $data = new mEms();
        // $data->mReturnZin($zin, $ltime, $author);
        // $data->mReturnZinP($zin, $ltime, $author);
        // $data->mReturnZinHis($zin, $ltime, $author);
    }

    public function cInQr($zin, $qr, $model, $lct, $sub_lct, $author, $direct, $status)
    {
        $data = new mEms();
        $data->mInQr($zin, $qr, $model, $lct, $sub_lct, $author, $status);
        $data->mAddHis($zin, $qr, $model, $lct, $sub_lct, $author, $direct, '', $status);
    }

    public function cExchange($qr, $model, $lct, $sub_lct, $author, $stime, $direct, $err_name)
    {
        $data = new mEms();
        $data->mExchange($qr, $lct, $sub_lct, $author, $stime, $err_name);
        $data->mAddHis('', $qr, $model, $lct, $sub_lct, $author, $direct, $err_name, 1);
    }

    public function cInputMaterial($did, $code, $sTime, $qty, $line, $author)
    {
        $data = new mEms();
        $data->mDelStockMM($did);
        $data->mAddHisLine($did, $code, $sTime, $qty, $line, $author, 1);
        $data->mAddLine($did, $code, $sTime, $qty, $line, $author);
    }

    public function cOutputMaterial($did, $code, $sTime, $qty, $line, $author)
    {
        $data = new mEms();
        $data->mAddStockMM($did, $code, $sTime, $qty, $line, $author);
        $data->mAddHisLine($did, $code, $sTime, $qty, $line, $author, 2);
        $data->mDelLine($did);
    }
    public function cUpQtyLine($line, $code, $qty)
    {
        $data = new mEms();
        $data->mUpQtyLine($line, $code, $qty);
    }
    public function cUpQtyPlan($line, $code, $qty)
    {
        $data = new mEms();
        $data->mUpQtyPlan($line, $code, $qty);
    }

    public function cDownQtyLine($line, $code, $qty)
    {
        $data = new mEms();
        $data->mDownQtyLine($line, $code, $qty);
    }
    public function cDownCfProd($line, $code, $qty)
    {
        $data = new mEms();
        $data->mDownCfProd($line, $code, $qty);
    }

    public function cUpdateOutPLan($id_plan, $line, $model_code, $qty_code)
    {
        $data = new mEms();
        $data->mUpdateOutPLan($id_plan, $line, $model_code, $qty_code);
    }

    public function cCheckQr($qr, $ltime, $author)
    {
        $data = new mEms();
        $data->mCheckQr($qr, $ltime, $author);
        $data->mAddHis('', $qr, '', 'CHECKING', 'CHECKING', $author, '', '', 1);
    }

    public function cAddZin($zin, $qty, $author, $model, $sub_lct)
    {
        $data = new mEms();
        $data->mAddZin($zin, $qty, $author, $model, $sub_lct);
    }
    public function cOut($qr, $model, $lct, $sub_lct, $author, $stime, $direct)
    {
        $data = new mEms();
        $data->mOut($qr);
        $data->mAddHis('', $qr, $model, $lct, $sub_lct, $author, $direct, '', 1);
    }
    public function cAddCause($line, $name, $detail, $start_time, $stop_time, $img, $author)
    {
        $data = new mEms();
        $data->mAddCause($line, $name, $detail, $start_time, $stop_time, $img, $author);
        return "Success";
    }
    public function cGetCauseDetail($id)
    {
        $data = new mEms();
        $result = $data->mGetCauseDetail($id);
        return $result;
    }

    public function cGetBomDetail($id_plan)
    {
        $data = new mEms();
        $result = $data->mGetBomDetail($id_plan);
        return $result;
    }

    public function cGetPlanDetail($id)
    {
        $data = new mEms();
        $result = $data->mGetPlanDetail($id);
        return $result;
    }

    public function cEditCause($id, $line, $name, $detail, $start_time, $stop_time, $img, $author)
    {
        $data = new mEms();
        $data->mEditCause($id, $line, $name, $detail, $start_time, $stop_time, $img, $author);
        return "Success";
    }

    public function cDelCause($id)
    {
        $data = new mEms();
        $data->mDelCause($id);
        return "Success";
    }
    public function cCancelZin($id)
    {
        $data = new mEms();
        $data->mDelQrbyZin($id);
        $data->mCancelZin($id);
        return "Success";
    }


    public function cGetDetailZin($arr)
    {
        $data = new mEms();
        $result = $data->mGetDetailZin($arr);
        return $result;
    }
    public function cGetListModel()
    {
        $data = new mEms();
        $result = $data->mGetListModel();
        return $result;
    }
    public function cGetListCode()
    {
        $data = new mEms();
        $result = $data->mGetListCode();
        return $result;
    }
    public function cGetListProcess()
    {
        $data = new mEms();
        $result = $data->mGetListProcess();
        return $result;
    }

    public function cAddPlan($line, $model_code, $sDate, $qty, $author)
    {
        $data = new mEms();
        $id = $data->mAddPlan($line, $model_code, $sDate, $qty, $author);
        $data->mAddBomReal($id, $line, $model_code, $qty);
    }


    public function cEditPlan($id, $line, $model_code, $sDate, $qty, $author)
    {
        $data = new mEms();
        $data->mEditPlan($id, $line, $model_code, $sDate, $qty, $author);
        return "Success";
    }
    public function cChangeLine($id, $line)
    {
        $data = new mEms();
        $data->mChangeLine($id, $line);
        return "Success";
    }
    public function cChangeCode($id, $code_change)
    {
        $data = new mEms();
        $data->mChangeCode($id, $code_change);
        return "Success";
    }

    public function cDelPlan($id)
    {
        $data = new mEms();
        $data->mDelPlan($id);
        return "Success";
    }

    public function cDelLct($id)
    {
        $data = new mEms();
        $data->mDelLct($id);
    }

    public function cDelBom()
    {
        $data = new mEms();
        $data->mDelBom();
    }
    public function cAddLct($lct, $err_name)
    {
        $data = new mEms();
        $data->mAddLct($lct, $err_name);
    }

    public function cUpBom($basic, $model_code, $process, $code, $desc, $qty, $author, $type)
    {
        $data = new mEms();

        $data->mUpBom($basic, $model_code, $process, $code, $desc, $qty, $author, $type);
        return "Success";
    }

    public function cDelProMes($sDate, $shift)
    {
        $data = new mEms();
        $data->mDelProMes($sDate, $shift);
    }
    public function cUpProMes($str)
    {
        $data = new mEms();

        $data->mUpProMes($str);
        return "Success";
    }

    public function cGetDataOut($date, $dateE)
    {
        $data = new mEms();
        $result = $data->mGetDataOut($date, $dateE);
        return $result;
    }
    public function cGetDataIn($to)
    {
        $data = new mEms();
        $result = $data->mGetDataIn($to);
        return $result;
    }
    public function cGetMaterialByPlan($id)
    {
        $data = new mEms();
        $result = $data->mGetMaterialByPlan($id);
        return $result;
    }

    public function cGetCountImByPlan($id)
    {
        $data = new mEms();
        $result = $data->mGetCountImByPlan($id);
        return $result;
    }

    public function cAddQtyProductionbyModel($direct, $dTime, $mc, $shift, $model, $qty, $author)
    {
        $data = new mEms();
        $data->mAddQtyProductionbyModel($direct, $dTime, $mc, $shift, $model, $qty, $author);
    }

    public function cGetQtyProcByModel($dTime, $direct)
    {
        $data = new mEms();
        $result = $data->mGetQtyProcByModel($dTime, $direct);
        return $result;
    }
    public function cAddMaterialHistory($id_in, $id_plan, $direct, $model_code, $code, $qty, $author, $type, $note, $status)
    {
        $data = new mEms();
        $data->mAddMaterialHistory($id_in, $id_plan, $direct, $model_code, $code, $qty, $author, $type, $note, $status);
    }
    public function cImMaterial($direct, $code, $qty, $status)
    {
        $data = new mEms();
        $data->mImMaterial($direct, $code, $qty, $status);
    }
    public function cExMaterial($direct, $code, $qty, $status)
    {
        $data = new mEms();
        $data->mExMaterial($direct, $code, $qty, $status);
    }

    public function cAddResultByPlan($id_plan, $direct, $model_code, $qty_code, $proc, $author)
    {
        $data = new mEms();
        $data->mAddResultByPlan($id_plan, $direct, $model_code, $qty_code, $proc, $author);
    }

    public function cUpdateResultByPlan($id, $qty_code)
    {
        $data = new mEms();
        $data->mUpdateResultByPlan($id, $qty_code);
    }
    public function cGetListMaterial()
    {
        $data = new mEms();
        $result = $data->mGetListMaterial();
        return $result;
    }

    public function cCheckMaterialbyBom($model_code, $proc, $direct)
    {
        $data = new mEms();
        $result = $data->mCheckMaterialbyBom($model_code, $proc, $direct);
        return $result;
    }

    public function cGetTracking($direct, $listFilterDirect, $date, $dateE)
    {
        $data = new mSet();
        $result = $data->mGetTracking($direct, $listFilterDirect, $date, $dateE);
        return $result;
    }

    public function cGetUbTracking($listFilterDirect, $date, $dateE)
    {
        $data = new mEms();
        $result1 = $data->mGetUbTrackingIn($listFilterDirect, $date, $dateE);
        $result2 = $data->mGetUbTrackingOut($listFilterDirect, $date, $dateE);
        return array_merge($result1, $result2);
    }

    public function cGetUbTrackingErrRate($listFilterDirect, $date, $dateE)
    {
        $data = new mEms();
        $result1 = $data->mGetUbTrackingIn($listFilterDirect, $date, $dateE);
        $result2 = $data->mGetUbTrackingErr($listFilterDirect, $date, $dateE);
        return array_merge($result1, $result2);
    }

    public function cGetM3Date($sTime)
    {
        $data = new mEms();
        $result = $data->mGetM3Date($sTime);
        return $result;
    }
    public function cGetM3Defect($to)
    {
        $all = new mEms();
        $result = $all->mGetM3Defect($to);
        return $result;
    }
    public function cGetDefectData($to, $listFilterDirect)
    {
        $data = new mEms();
        $result = $data->mGetDefectData($to, $listFilterDirect);
        return $result;
    }

    public function cGetTrackingAll($direct, $listFilterDirect, $date, $dateE)
    {
        $data = new mSet();
        $result = $data->mGetTrackingAll($direct, $listFilterDirect, $date, $dateE);
        return $result;
    }
    public function cGetErrTracking($direct, $listFilterDirect, $date, $dateE)
    {
        $data = new mSet();
        $result = $data->mGetErrTracking($direct, $listFilterDirect, $date, $dateE);
        return $result;
    }

    public function cGetDataTracking($direct, $listFilterDirect, $date, $dateE)
    {
        $data = new mSet();
        $result = $data->mGetDataTracking($direct, $listFilterDirect, $date, $dateE);
        return $result;
    }


    public function cGetLineConfig($direct, $listFilterDirect, $date, $dateE)
    {
        $data = new mSet();
        $result = $data->mGetLineConfig($direct, $listFilterDirect, $date, $dateE);
        return $result;
    }

    public function cGetModelLcd()
    {
        $data = new mSet();
        $result = $data->mGetModelLcd();
        return $result;
    }
    public function cGetLineByDirect($direct)
    {
        $data = new mSet();
        $result = $data->mGetLineByDirect($direct);
        return $result;
    }

    public function cGetPlanbyDay($dTime, $direct)
    {
        $data = new mEms();
        $result = $data->mGetPlanbyDay($dTime, $direct);
        return $result;
    }

    public function cAddLineTime($dTime, $direct, $line, $mc, $shift, $kg, $detail, $start_time, $stop_time, $diffTime, $type, $author)
    {
        $data = new mSet();
        $data->mAddLineTime($dTime, $direct, $line, $mc, $shift, $kg, $detail, $start_time, $stop_time, $diffTime, $type, $author);
    }

    public function cGetTimeLine($direct, $listFilterDirect, $date, $dateE)
    {
        $data = new mSet();
        $result = $data->mGetTimeLine($direct, $listFilterDirect, $date, $dateE);
        return $result;
    }

    public function cGetCal($direct, $line, $mc, $shift, $kg, $type, $date, $dateE)
    {
        $data = new mSet();
        $result = $data->mGetCal($direct, $line, $mc, $shift, $kg, $type, $date, $dateE);
        return $result;
    }
    public function cDelTimeLine($id)
    {
        $data = new mSet();
        $data->mDelTimeLine($id);
    }
    public function cGetLostTime($direct, $line, $date, $dateE)
    {
        $data = new mSet();
        $result = $data->mGetLostTime($direct, $line, $date, $dateE);
        return $result;
    }

    public function cGetInLineHis($stime)
    {
        $data = new mEms();
        $result = $data->mGetInLineHis($stime);
        return $result;
    }

    public function cGetDidDivideCut($did)
    {
        $data = new mEms();
        $result = $data->mGetDidDivideCut($did);
        return $result;
    }

    public function cHandleCutDidRoot($root_id, $root_did, $root_code, $root_qty, $qty_remain, $root_line, $root_status, $root_number_of_cut, $root_author, $root_sTime, $author_cut, $stime_cut, $did_unique)
    {
        $data = new mEms();

        $data->mEditCutLineHis($root_id, $qty_remain, $author_cut, $stime_cut);
        if ($root_status == '1') {
            $data->mEditCutLine($root_did, $qty_remain);
        }

        $root_number_of_cut = intval($root_number_of_cut) + 1;

        $data->mAddCutHisRoot($root_did, $root_code, $root_qty, $root_line, $root_status, $root_number_of_cut, $root_author, $root_sTime, $author_cut, $stime_cut, $did_unique);
        return "Success";
    }

    public function cHandleCutDidChild($did, $code, $subcode, $qty, $direct, $status, $author_cut, $stime_cut, $did_unique)
    {
        $data = new mEms();

        $data->mAddCutStockMM($did, $code, $subcode, $qty, $direct, $status, $stime_cut);
        $data->mAddCutHisChild($did, $code, $subcode, $qty, $author_cut, $stime_cut, $did_unique);
        return "Success";
    }

    public function cGetHisDivideCutFeeder($line_filter, $code_filter, $dateStart, $timeStart, $dateEnd, $timeEnd)
    {
        $data = new mEms();
        $result = $data->mGetHisDivideCutFeeder($line_filter, $code_filter, $dateStart, $timeStart, $dateEnd, $timeEnd);
        return $result;
    }

    public function cGetHisDivideCutLine($line_filter, $code_filter, $dateStart, $timeStart, $dateEnd, $timeEnd)
    {
        $data = new mEms();
        $result = $data->mGetHisDivideCutLine($line_filter, $code_filter, $dateStart, $timeStart, $dateEnd, $timeEnd);
        return $result;
    }

    public function cAddLack($code_hm, $type, $code, $point, $line, $name_err, $state, $author, $stime)
    {
        $data = new mEms();
        $data->mAddLack($code_hm, $type, $code, $point, $line, $name_err, $state, $author, $stime);
    }

    public function cGetLack($line, $type)
    {
        $data = new mEms();
        $res = $data->mGetLack($line, $type);
        return $res;
    }

    public function cDelLack()
    {
        $data = new mEms();
        $data->mDelLack();
    }

    public function cGetBom_DucDat()
    {
        $data = new mDat();
        $result = $data->mGetBom_DucDat();
        return $result;
    }
}
