<?php
    require('../controller/controller.php');
    date_default_timezone_set("Asia/Ho_Chi_Minh");
    $data = new cEms();
    $check = $data->cCheckToken();
    if ($check['status'] === false) {
        echo $check['data'];
    } else {
        if($check['data']->roler < 2){
            echo "<h4>Do not have permission to edit this content</h4>";
            exit();
        } else {
            $author  = $check['data']->manv;
            if (isset($_POST['name'])) {
                $line = $_POST['line']; 
                $name = $_POST['name'];
                $detail = $_POST['detail'];
                $start_time = $_POST['start_time'];
                $stop_time = $_POST['stop_time'];
                $img = '';
                if (isset($_FILES['img'])) {
                    $mg = '.'.strtolower(pathinfo($_FILES["img"]["name"], PATHINFO_EXTENSION));
                    move_uploaded_file($_FILES['img']['tmp_name'], '../vendor/img/causes/'.$line.time().$mg);
                    $img = $line.time().$mg;
                }
                $res = $data->cAddCause($line, $name, $detail, $start_time, $stop_time, $img, $author);
                echo $res;
            } else {
                echo "Failed";
            }
        }
    }
    
?>