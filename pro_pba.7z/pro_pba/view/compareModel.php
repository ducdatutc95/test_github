<?php

$flagPass = 1;

$idOld = isset($_GET['IdOld']) ? $_GET['IdOld'] : '';
$idNew = isset($_GET['IdNew']) ? $_GET['IdNew'] : '';
$linePlan = isset($_GET['line']) ? $_GET['line'] : '';

// print_r($idOld);
// print_r($idNew);


if ($idOld == '' || $idNew == '') {
    $flagPass = 0;
}

if ($flagPass == 0) {
    echo "<h3>Error Select Model</h3>";
    exit();
}


$resLine = array();
for ($i = 1; $i <= 32; $i++) {

    $line = ($i < 10 ? '0' . $i : $i);
    $resLine[] = (object)['line' => $line];
}

for ($i = 1; $i <= 7; $i++) {

    $line = ($i < 10 ? 'EMS-0' . $i : "EMS-" . $i);
    $resLine[] = (object)['line' => $line];
}

for ($i = 1; $i <= 7; $i++) {

    $line = ($i < 10 ? 'DMC-0' . $i : "DMC-" . $i);
    $resLine[] = (object)['line' => $line];
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PBA PRODUCTION</title>

    <!-- liên kết css -->
    <link href="./../vendor/css/style.css" rel="stylesheet" type="text/css">
    <link href="./../vendor/css/dd_style.css" rel="stylesheet" type="text/css">
    <link rel="shortcut icon" type="image/png" href="./../vendor/img/icon.jpg" />
    <!-- liên kết bootstrap css -->
    <link href="./../vendor/bootstrap/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="./../vendor/bootstrap/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="./../vendor/bootstrap/bootstrap-datetimepicker.css" rel="stylesheet" type="text/css">
    <!-- liên kết datatable css -->
    <link href="./../vendor/datatable/dataTables.min.css" rel="stylesheet" type="text/css" />

    <!-- liên kết font css -->
    <link rel="stylesheet" href="./../vendor/fontawesome/css/all.min.css">
    <link href="./../vendor/datatable/buttons.dataTables.min.css" rel="stylesheet" type="text/css" />
    <link href="./../vendor/datatable/select.dataTables.css" rel="stylesheet" type="text/css" />
    <link href="./../vendor/chart/chartist.min.css" rel="stylesheet" type="text/css" />

    <style>
        body {
            padding: 0;
            margin: 0;
            box-sizing: border-box;

            display: flex;
            justify-content: center;
        }

        .dd_application {
            height: 100%;
            min-height: 100vh;
            width: 100%;
            max-width: 1200px;
            background-color: #fff;
            padding: 16px;
        }
    </style>

</head>

<body>

    <div class="dd_application">
        <div class="row" id="dd_show_detail">

            <div class="col-md-12 mb-3 mt-3">
                <h3>Chọn Line Chạy thực tế</h3>
            </div>

            <div class="col-md-6 mb-3">

                <div class="input-group  mb-3">
                    <div class="input-group-prepend">
                        <label class="input-group-text">Line Đang Chạy thực tế :</label>
                    </div>
                    <input type="text" list="list_line" class="form-control" id="line_current" value="<?php echo $linePlan; ?>">
                    <datalist id="list_line">
                        <?php foreach ($resLine as $key) { ?>
                            <option value="<?php echo $key->line; ?>"><?php echo 'Line ' . $key->line; ?></option>
                        <?php } ?>
                    </datalist>
                </div>

            </div>

            <div class="col-md-6 mb-3">
                <button class="btn btn-primary form-control" id="confirm" style="margin-bottom:1em;">
                    <i class="fas fa-save"></i>
                    Confirm
                </button>
            </div>
        </div>
    </div>

    <footer></footer>
</body>

</html>

<script src='./../vendor/js/socket.io.js'></script>
<script src="./../vendor/js/jquery.js"></script>
<script src="./../vendor/js/myQuery.js"></script>
<script src="./../vendor/js/tree_menu.js"></script>
<script src="./../vendor/chart/chartist.min.js"></script>
<script src="./../vendor/chart/utils.js"></script>
<script src="./../vendor/chart/chart.bundle.min.js"></script>
<script src="./../vendor/js/tree.min.js"></script>
<script src="./../vendor/js/sweetalert2.all.min.js"></script>
<script src="./../vendor/bootstrap/bootstrap.min.js"></script>
<script src="./../vendor/datatable/dataTables.min.js"></script>
<script src="./../vendor/datatable/dataTables.select.js"></script>
<script src="./../vendor/datatable/dataTables.buttons.min.js"></script>
<script src="./../vendor/datatable/dataTables.buttonHtml5.min.js"></script>
<script src="./../vendor/datatable/buttons.flash.min.js"></script>
<script src="./../vendor/datatable/jszip.min.js"></script>
<script src="./../vendor/bootstrap/moment.min.js"></script>
<script src="./../vendor/bootstrap/bootstrap-datetimepicker.js"></script>
<script src="./../vendor/datatable/dataTables.bootstrap4.min.js"></script>
<script src="./../vendor/chart/chartjs-plugin.js"></script>
<script type="text/javascript" src="./../vendor/chart/chart.min.js"></script>
<script type="text/javascript" src="./../vendor/chart/chartjs-plugin-datalabels.min.js"></script>

<script>
    $(document).ready(function() {

        var idOld = '<?php echo $idOld; ?>';
        var idNew = '<?php echo $idNew; ?>';

        var arrLine = <?php echo json_encode($resLine); ?>;


        // var lineCurrent1 = $('#line_current').val().trim();
        // $.post('compareModelDetail', {
        //         idOld: idOld,
        //         idNew: idNew,
        //         lineCurrent: lineCurrent1
        //     },
        //     function(data) {
        //         $('#dd_show_detail').html(data);
        //     });


        $('#line_current').focus();

        $('#confirm').click(function() {
            var lineCurrent = $('#line_current').val().trim();

            var checkLine = arrLine.find(e => {
                return e.line == lineCurrent
            });

            if (lineCurrent == '') {
                errAlert("Line Trống !")
            } else if (checkLine == null) {
                errAlert("Line Không Tồn Tại !")
            } else {

                $.post('compareModelDetail', {
                        idOld: idOld,
                        idNew: idNew,
                        lineCurrent: lineCurrent
                    },
                    function(data) {
                        $('#dd_show_detail').html(data);
                    });
            }
        })

        $("#line_current").keyup(function(event) {
            if (event.keyCode === 13) {

                var lineCurrent = $('#line_current').val().trim();

                var checkLine = arrLine.find(e => {
                    return e.line == lineCurrent
                });

                if (lineCurrent == '') {
                    errAlert("Line Trống !")
                } else if (checkLine == null) {
                    errAlert("Line Không Tồn Tại !")
                } else {

                    $.post('compareModelDetail', {
                            idOld: idOld,
                            idNew: idNew,
                            lineCurrent: lineCurrent
                        },
                        function(data) {
                            $('#dd_show_detail').html(data);
                        });
                }

            }
        })

    })
</script>