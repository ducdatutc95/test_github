<?php
	require('../controller/controller.php');
	$data = new cEms();
	if (isset($_COOKIE['token'])) {
		$token = $_COOKIE['token'];
		$userInfo = $data->cGetUser($token);
		if (empty($userInfo)) {
      
          header("Location:../login");
          exit();
        }
	} else {
		header("Location:../login");
		exit();
	}
    $id = $_POST['arrDid'][0];
    $dataDetail = $data->cGetCauseDetail($id);
?>
<div class="modal-header">
	<h5 class="modal-title card-title" style="color: #01b1c1;">View Causes Detail</h5>
	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</button>
</div>
<div class="modal-body">
    <div class="row" id = "form_pick">	
        <div class="col-md-6 showEditInfo">
            <div class="input-group input-group-sm mb-3">
                <div class = "input-group-prepend">
                    <label class="input-group-text">Line :</label>
                </div>
                <input id="line" class="form-control form-control-sm" placeholder="Line" list="arrLine"  value="<?php echo $dataDetail->line; ?>">
                
            </div>
            <div class="input-group input-group-sm mb-3">
                <div class = "input-group-prepend">
                    <label class="input-group-text">Name :</label>
                </div>
                <input id="name" class="form-control form-control-sm" placeholder="Name"  value="<?php echo $dataDetail->name; ?>">
                
            </div>
            <div class="input-group input-group-sm mb-3">
                <div class = "input-group-prepend">
                    <label class="input-group-text">Start Time :</label>
                </div>
                <input id="start_time" type="datetime-local" class="form-control form-control-sm" placeholder="Start Time"  value="<?php echo $dataDetail->startTime; ?>">
            </div>
             <div class="input-group input-group-sm mb-3">
                <div class = "input-group-prepend">
                    <label class="input-group-text">Stop Time :</label>
                </div>
                <input id="stop_time" type="datetime-local" class="form-control form-control-sm" placeholder="Stop Time "  value="<?php echo $dataDetail->stopTime; ?>">
            </div>
            
        </div>

        <div class="col-md-6 showEditInfo">
            
            <div class="input-group input-group-sm mb-3">
                <div class = "input-group-prepend">
                    <label class="input-group-text">Detail :</label>
                </div>
                <textarea id="detail" class="form-control form-control-sm" ><?php echo $dataDetail->detail; ?></textarea>
            </div>
            <div class="input-group input-group-sm mb-3">
                
                <img src="vendor/img/causes/<?php echo $dataDetail->img; ?>">
            </div>

        </div>
	</div>
</div>

