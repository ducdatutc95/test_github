<?php
	require('../controller/controller.php');
	$data = new cEms();

	$dTime = $_POST['dTime'];
	$folderName = "//192.168.63.12/2F_Data/".str_replace("-","",$dTime);
	$date = date($dTime." 08:00:00");
	$arrFile = scandir($folderName);
	$finalDataString = "";
	// print_r($arrFile);
	// foreach ($arrFile as $key) {
	for ($i=2; $i < count($arrFile); $i++) { 
		$fileName = $folderName."/".$arrFile[$i];
		$myfile= fopen($fileName,"r");
		$dataFile= fread($myfile,filesize($fileName));  
		$finalDataString .=  $dataFile;
	}
	substr($finalDataString,0,1);
	
	// readfile("test.txt")
	$dateE = date('Y-m-d H:i:s', strtotime($date . ' +1 day'));
	$direct = $_POST['direct'];
    // $finalData = $data->cGetTracking($direct,$listFilterDirect,$date,$dateE);
    $timeLineData = $data->cGetTimeLine($direct,$listFilterDirect,$date,$dateE);
    $arrMc = $data->cGetLineConfig($direct,'',$date,$dateE);
    $arrModel = $data->cGetModelLcd();
    $arrLine = $data->cGetLineByDirect($direct);
    $qtyPlan = $data->cGetPlanbyDay($dTime,$direct);
    // $resFinal = json_encode($finalData);
    $resTimeLine = json_encode($timeLineData);
    $resMc = json_encode($arrMc);
    $resModel = json_encode($arrModel);
    $resLine = json_encode($arrLine);
    $resPlan = json_encode($qtyPlan);

?>

<div id="showNow" class="row mg0">
	
</div>

<script>
	$(document).ready(function(){
		let resFinal = [<?php echo $finalDataString; ?>];
		resFinal=resFinal.filter(e=>e.res=="PASS")
		let resTimeLine = <?php echo $resTimeLine; ?>;
		let resLine = <?php echo $resLine; ?>;
		let resModel = <?php echo $resModel; ?>;
		let resMachine = <?php echo $resMc; ?>;
		let resPlan = <?php echo $resPlan; ?>;

		let resShift = ["D","N"]
		let html = ""
		let direct = '<?php echo $direct; ?>';
		let dTime = '<?php echo $dTime; ?>';
		let data = []
		for (let i = 0; i < resFinal.length; i++) {
			let time = new Date(resFinal[i].tTime)
			let t = time.getHours();
			let pn = resFinal[i].pn
			let mc = resFinal[i].mc
			let line = resFinal[i].line
			let direct = resFinal[i].direct
			let amodel = resFinal[i].model.split('-')
			let model = amodel.at(-1).slice(0, 4)
			let m = ''
			let shift = ''
			if (model == 'A146') {
				resFinal[i].model_real = 'A145'
			} else {
				resFinal[i].model_real = model
			}
			if (t>=8 && t < 20) {
				shift = "D"
			} else {
				shift = "N"
			}
			resFinal[i].shift = shift

		}

		let modelArr = resFinal
	        .map((item) => item.model_real)
	        .filter(
	            (value, index, current_value) => current_value.indexOf(value) === index
        );
        
		for (let i = 0; i < modelArr.length; i++) {
			let model = modelArr[i]
			let pplan = resPlan.find(e=>e.basic==model)
			let qtyPlan = parseInt(pplan.qty)
			html+='<div class="col-md-6">'
				html+='<h3>Báo cáo hiện trạng sản xuất '+model+'</h3>'
				html+='<table class="table table-hover table-bordered" style="font-size: 14px;">'
					html+='<thead style="background-color: #01b1c1; color: white;line-height: 15px;" class="text-center">'
						html+='<tr>'
							html+='<th style="vertical-align: middle;" >Date </th>'
							html+='<th colspan="4" style="vertical-align: middle;" >'+dTime+'</th>'
						html+='</tr>'
						html+='<tr>'
							html+='<th style="vertical-align: middle;" >Plan </th>'
							html+='<th colspan="4" style="vertical-align: middle;" class="inputPlan" model = "'+model+'" datePlan = "'+dTime+'">'+qtyPlan.toLocaleString('en')+'</th>'
						html+='</tr>'
					html+='</thead>'
					html+='<tbody id="showTable" class="reportBody">'
						// bonding

						let bondingD = resFinal.filter(e=>e.model_real==model && e.mc == 'BONDING VISION' && e.shift =='D')
						let bondingN = resFinal.filter(e=>e.model_real==model && e.mc == 'BONDING VISION' && e.shift =='N')
						let bondingTotal = bondingN.length+bondingD.length
						html+='<tr><td rowspan="2" style="vertical-align: middle;font-weight:bold">Bonding</td>'
						html+='<td>Actual</td><td>'+bondingTotal.toLocaleString('en')+'</td><td>Day Shift</td><td>'+bondingD.length.toLocaleString('en')+'</td>'
						html+='</tr>'
						html+='<tr>'
						html+='<td>Rate</td><td>'+Math.round((bondingTotal/qtyPlan)*10000)/100+'%</td><td>Night Shift</td><td>'+bondingN.length.toLocaleString('en')+'</td>'
						html+='</tr>'

						// pba
						html+='<tr><td rowspan="2" style="vertical-align: middle;font-weight:bold">PBA & BTM</td>'
						html+='<td>Actual</td><td>'+0+'</td><td>Day Shift</td><td>'+0+'</td>'
						html+='</tr>'
						html+='<tr>'
						html+='<td>Rate</td><td>'+0+'%</td><td>Night Shift</td><td>'+0+'</td>'
						html+='</tr>'

						// lcd
						let lcdD = resFinal.filter(e=>e.model_real==model && e.mc == 'LCD TEST' && e.shift =='D')
						let lcdN = resFinal.filter(e=>e.model_real==model && e.mc == 'LCD TEST' && e.shift =='N')

						let lcdTotal = lcdN.length+lcdD.length
						html+='<tr><td rowspan="2" style="vertical-align: middle;font-weight:bold">Test LCD</td>'
						html+='<td>Actual</td><td>'+lcdTotal.toLocaleString('en')+'</td><td>Day Shift</td><td>'+lcdD.length.toLocaleString('en')+'</td>'
						html+='</tr>'
						html+='<tr>'
						html+='<td>Rate</td><td>'+Math.round((lcdTotal/qtyPlan)*10000)/100+'%</td><td>Night Shift</td><td>'+lcdN.length.toLocaleString('en')+'</td>'
						html+='</tr>'

						// rf call
						let rfD = resFinal.filter(e=>e.model_real==model && e.mc == 'RF CALL' && e.shift =='D')
						let rfN = resFinal.filter(e=>e.model_real==model && e.mc == 'RF CALL' && e.shift =='N')

						let rfTotal = rfN.length+rfD.length
						html+='<tr><td rowspan="2" style="vertical-align: middle;font-weight:bold">RF CALL</td>'
						html+='<td>Actual</td><td>'+rfTotal.toLocaleString('en')+'</td><td>Day Shift</td><td>'+rfD.length.toLocaleString('en')+'</td>'
						html+='</tr>'
						html+='<tr>'
						html+='<td>Rate</td><td>'+Math.round((rfTotal/qtyPlan)*10000)/100+'%</td><td>Night Shift</td><td>'+rfN.length.toLocaleString('en')+'</td>'
						html+='</tr>'

						// Wait confirm
						html+='<tr><td rowspan="2" style="vertical-align: middle;font-weight:bold">Wait Confirm</td>'
						html+='<td>Actual</td><td>'+0+'</td><td>Day Shift</td><td>'+0+'</td>'
						html+='</tr>'
						html+='<tr>'
						html+='<td>Rate</td><td>'+0+'%</td><td>Night Shift</td><td>'+0+'</td>'
						html+='</tr>'

						// gmes
						html+='<tr><td rowspan="2" style="vertical-align: middle;font-weight:bold">G-MES</td>'
						html+='<td>Actual</td><td>'+0+'</td><td>Day Shift</td><td>'+0+'</td>'
						html+='</tr>'
						html+='<tr>'
						html+='<td>Rate</td><td>'+0+'%</td><td>Night Shift</td><td>'+0+'</td>'
						html+='</tr>'

					html+='</tbody>'
				html+='</table>'
			html+='</div>'
		}

		$("#showNow").html(html)
	})
</script>