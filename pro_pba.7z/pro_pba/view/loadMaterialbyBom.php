<?php
    require('../controller/controller.php');
    date_default_timezone_set("Asia/Ho_Chi_Minh");
    $sTime =  date('Y-m-d H:i:s');
    $data = new cEms();
    $check = $data->cCheckToken();
    if ($check['status'] === false) {
        echo $check['data'];
    } else {
        $author  = $check['data']->manv;
        $model_code = $_POST['model'];
        $direct = $_POST['direct'];
        $note = $_POST['note'];
        $proc = $_POST['proc'];
        $qty_code = $_POST['qty_code'];
        $status = $_POST['status'];
        $dataDetail = $data->cGetBomDetail($model_code,$proc);
        ?>

        <thead style="font-size: 18px;" > 
            <tr> 
                <td>No.</td>
                <td>Model</td>
                <td>Code</td>
                <td>Qty Input</td>
            </tr>
        </thead>
        <tbody>
        	<?php
    			$i=1;
                foreach ($dataDetail as $key) {
                   ?>
                   <tr <?php if ($key->type != '') {
                          echo "style='background-color:#914242;color:white;'" ;
                      } ?>>
                        <td><?php echo $i++;?></td>    
                        <td><?php echo $key->model_code;?></td>
                        <td id="code" sub = "<?php echo $key->code;?>"><?php echo $key->code;?></td>
                        <td><input class="inputs" type="text" value="<?php echo $key->qty*$qty_code;?>" style="border: none; width: 100%; color: red; text-align: center;" tabindex="<?php echo $i; ?>"></td> 
                   </tr>
                   <?php
                }
            ?>
            </tbody>
        </tbody>
        <script type="text/javascript">
        	$(document).ready(function(){
	        	$('#submit').click(function(){
			        let code = $("#showListMaterial td[id=code]");
			        let qty_code = $("#showListMaterial td[id=qty_code]");
			        let qty_recive = $("#showListMaterial td[id=qty_recive]");
			        let qty_in = $("#showListMaterial input[type=text");

			        let id_plan = 'BOM';
			        let model_code = '<?php echo $model_code; ?>';
			        let direct = '<?php echo $direct; ?>';
			        let note = '<?php echo $note; ?>';
			        let status = '<?php echo $status; ?>';
			        let obj = [];
			        let check = 0;
			        let tit = ' Dòng : ';
			        let errContent = '';

			        for (let i = 0; i < code.length; i++) {
			            let code_val = $(code[i]).attr('sub');
			            let qty_in_val = parseFloat($(qty_in[i]).val());

			            if($(qty_in[i]).val() != ''){
			                if(/[^0-9\.\-]/i.test($(qty_in[i]).val())){
			                    check ++;
			                    tit += ','+(i+1);
			                    errContent = "Sai ký tự vui lòng kiểm tra lại "
			                } else {
			                    obj.push({'code': code_val,'qty_in' : qty_in_val});   
			                }
			            }
			        }
			        if (check >0) {
			            errAlert(errContent+tit);
			        } else{
			            quest('Are you sure "Save data"? !').then((result) => {
			                if (result.isConfirmed) {
			                    processing2()
			                    $("#submit").remove();
			                    $.post('importingMaterial.php', {
			                        obj:obj, id_plan:id_plan,model_code:model_code,direct:direct, note:note,status:status
			                    },function(data){
			                        successAlert(data);
			                    });
			                }
			            })
			        }
			    })
			    $('.inputs').keydown(function(e){
			        if (e.which === 13) {
			            var index = $('.inputs').index(this) + 1;
			            $('.inputs').eq(index).focus();
			            $('.inputs').eq(index).select();
			        }
	    		});
			})
        </script>
        <?php
    }
    
?>