<?php
	require('../controller/controller.php');
	$data = new cEms();
	$dTime = $_POST['dTime'];
	$date = date($dTime." 08:00:00");
	$dateE = date('Y-m-d H:i:s', strtotime($date . ' +1 day'));
	$direct = $_POST['direct'];
	$timeNow = date('Y-m-d H:i:s');

	$listFilterDirect = "^".implode("|^",$_POST['listFilterP']);


    $dTime = $_POST['dTime'];
    $folderName = "//192.168.63.12/2F_Data/".str_replace("-","",$dTime);
    $date = date($dTime." 08:00:00");
    $arrFile = scandir($folderName);
    $finalDataString = "";
    // print_r($arrFile);
    // foreach ($arrFile as $key) {
    for ($i=2; $i < count($arrFile); $i++) { 
        $fileName = $folderName."/".$arrFile[$i];
        $myfile= fopen($fileName,"r");
        $dataFile= fread($myfile,filesize($fileName));  
        $finalDataString .=  $dataFile;
    }
    substr($finalDataString,0,1);

    // $finalData = $data->cGetErrTracking($direct,$listFilterDirect,$date,$dateE);
    // print_r($finalData);
    // $timeLineData = $data->cGetTimeLine($direct,$listFilterDirect,$date,$dateE);
    $arrMc = $data->cGetLineConfig($direct,$listFilterDirect,$date,$dateE);
    // $arrModel = $data->cGetModelLcd();
    $arrLine = $data->cGetLineByDirect($direct);

    // $resFinal = json_encode($finalData);
    // $resTimeLine = json_encode($timeLineData);
    $resMc = json_encode($arrMc);
    // $resModel = json_encode($arrModel);
    $resLine = json_encode($arrLine);
?>
<div class="row mg0">
        <?php 
            for ($k=0; $k < 2; $k++) { 
                if ($k==0) {
                    $type = 'Day';
                } else {
                    $type = 'Time';
                }
                for ($i=0; $i <2 ; $i++) { 
                    if ($i==0) {
                        $mc = 'Bonding Vision';
                    } else {
                        $mc = 'LCD Test';
                    }
                    for ($j=1; $j <= count($_POST['listFilterP']); $j++) { 
                        ?>
                            <div class="col-md-3" style="text-align: center; border: 1px solid #ccc">

                                <canvas id="<?php echo 'line0'.$j.'_mc'.$i.'_type'.$k; ?>" style="margin-top: 1em; width: 100%;"></canvas> 
                                <h3 style="color:red;"><?php echo "LINE".$_POST['listFilterP'][$j-1].": ".$mc; ?></h3>
                                <div class="donut-inner">
                                    <h5 id="<?php echo 'total0'.$j.'_mc'.$i.'_type'.$k; ?>"></h5>
                                    <span><u><?php echo "Worst ".$type?></u></span>
                                </div>
                            </div>
                        <?php
                    }
                }
            }
         ?>
        <button class="btn btn-light btn-sm appy-filter form-control" id="next"><i class="fa fa-play i-right"></i>Next</button>
        
    </div>
    <script>
        $(document).ready(function(){
            $('#next').click(function(){
                window.clearTimeout(timer);
                loadMc1(listFilterP);
            });
            timer = window.setTimeout(function(){
                if (pause_play == 1) {
                  loadMc1(listFilterP);
                }
             }, 50000)

            let resFinal = [<?php echo $finalDataString; ?>];
            resFinal=resFinal.filter(e=>e.res=="FAIL")
            // console.log(resFinal)
                let defectArr = resFinal
                    .map((item) => item.err_code)
                    .filter(
                        (value, index, current_value) => current_value.indexOf(value) === index
                    );
            
            let resLine = <?php echo $resLine; ?>;
            let resMachine = <?php echo $resMc; ?>;
            let resM = ["A","B","C","D","E"]
            let resShift = ["D","N"]
            let direct = '<?php echo $direct; ?>';
            let dTime = '<?php echo $dTime; ?>';
            let timeNow = new Date('<?php echo $timeNow; ?>');
            let ms = getMs(timeNow)
            let mNow = ms[1]
            let shiftNow = ms[0]
            for (let i = 0; i < resFinal.length; i++) {
                let time = new Date(resFinal[i].tTime)
                let t = time.getHours();
                let pn = resFinal[i].pn
                let mc = resFinal[i].mc
                let line = resFinal[i].line
                let direct = resFinal[i].direct
                let m = ''
                let shift = ''

                if (t>=8 && t < 10 || t>=20 && t < 22) {
                    m = 'A'
                    if (t>=8 && t < 10) {
                        shift = "D"
                    } else {
                        shift = "N"
                    }
                } else if (t>=10 && t < 13 || t>=22 || t < 1){
                    m = 'B'
                    if (t>=10 && t < 13) {
                        shift = "D"
                    } else {
                        shift = "N"
                    }
                } else if (t>=13 && t < 15 || t>=1 && t < 3){
                    m = 'C'
                    if (t>=13 && t < 15) {
                        shift = "D"
                    } else {
                        shift = "N"
                    }
                } else if (t>=15 && t < 17 || t>=3 && t < 5){
                    m = 'D'
                    if (t>=15 && t < 17) {
                        shift = "D"
                    } else {
                        shift = "N"
                    }
                } else if (t>=17 && t < 20 || t>=5 && t < 8){
                    m = 'E'
                    if (t>=17 && t < 20) {
                        shift = "D"
                    } else {
                        shift = "N"
                    }
                }
                resFinal[i].m = m
                resFinal[i].shift = shift
            }
            let dataFinal = []
            for (let i = 0; i < resLine.length; i++) {
                let line = resLine[i].line
                dataFinal.push({"line":line,"data":[]})
                let resMc = resMachine.filter(e=>e.line == line && e.direct == direct)
                for (let j = 0; j < resMc.length; j++) {
                    let mc = resMc[j].proc
                    dataFinal[i].data.push({"mc":mc,data:[[],[]]})
                    for (let k = 0; k < defectArr.length; k++) {
                        let err_code = defectArr[k]
                        let dataDay = resFinal.filter(e=>e.line==line && e.mc == mc && e.direct == direct && e.err_code == err_code)
                        let dataTimeNow = resFinal.filter(e=>e.line==line && e.mc == mc && e.direct == direct && e.shift == shiftNow && e.m == mNow && e.err_code == err_code)
                        // console.log(line+"-"+shiftNow+"-"+mNow+"-"+err_code)
                        dataFinal[i].data[j].data[0].push({"err_code":err_code,"count":dataDay.length})
                        dataFinal[i].data[j].data[1].push({"err_code":err_code,"count":dataTimeNow.length})
                    }
                }
            }
            for (let i = 0; i < dataFinal.length; i++) {
                let line = dataFinal[i].line
                // console.log(line)
                let byLine = dataFinal[i].data
                for (let j = 0; j < 2; j++) {
                    let mc = byLine[j].mc
                    let byMc = byLine[j].data
                    for (let k = 0; k < byMc.length; k++) {
                        //k = 1, timenow, k=0 day
                        let arrCount = byMc[k].sort((a, b) => parseFloat(b.count) - parseFloat(a.count));
                        let label = []
                        let data = []
                        data[3]=0
                        for (let y = 0; y < arrCount.length; y++) {
                            if (y>2) {
                                label[3] = "Other"
                                data[3] += arrCount[y].count
                            } else {
                                label[y] = arrCount[y].err_code
                                data[y] = arrCount[y].count
                            }
                        }

                        let sum = data.reduce((accumulator, object) => {
                          return accumulator + object;
                        }, 0);
                        $("#total"+line+"_mc"+(j)+"_type"+k).text("Total: "+sum+"ea")
                        Chart.register(ChartDataLabels);
                        const ctx = document.getElementById("line"+line+"_mc"+(j)+"_type"+k).getContext('2d');
                        const myChart = new Chart(ctx, {
                            type: 'doughnut',
                            data: {
                                labels: label,
                                  datasets: [
                                    {
                                      data: data,
                                        backgroundColor: [
                                          'rgb(255, 99, 132)',
                                          'rgb(255, 159, 64)',
                                          'rgb(255, 205, 86)',
                                          'rgb(75, 192, 192)',
                                          
                                        ],
                                      
                                    }
                                  ]
                            },
                            options: {
                            plugins: {
                                // legend:{
                                //  position:"bottom"
                                // },
                              datalabels: {
                                formatter: (value) => {
                                  return value;
                                },
                              },
                            },
                          },
                        });
                    }
                }

                


            }
        });
    </script>