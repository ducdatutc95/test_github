<?php
    require('../controller/controller.php');
    date_default_timezone_set("Asia/Ho_Chi_Minh");
    $data = new cEms();
    $check = $data->cCheckToken();
    if ($check['status'] === false) {
        echo $check['data'];
    } else {
        $author  = $check['data']->manv;
        if (isset($_POST['qty'])) {
            $line = $_POST['line']; 
            $model_code = $_POST['model_code'];
            $sDate = $_POST['sDate'];
            $qty = $_POST['qty'];
            $data->cAddPlan($line, $model_code, $sDate, $qty, $author);
            echo "Success";
        } else {
            echo "Failed";
        }
    }
    
?>