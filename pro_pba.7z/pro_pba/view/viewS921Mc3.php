<?php
	require('../controller/controller.php');
	$data = new cEms();
	$dTime = $_POST['dTime'];
	$date = date($dTime." 08:00:00");
	$dateE = date('Y-m-d H:i:s', strtotime($date . ' +1 day'));
	$direct = $_POST['direct'];
	$timeNow = date('Y-m-d H:i:s');

	$listFilterDirect = "^".implode("|^",$_POST['listFilterP']);


    $dTime = $_POST['dTime'];
    // print_r($dTime);
    $resultDate = $data->cGetM3Date($dTime);
    
    $to = date('Y-m-d 08:00:00', strtotime($resultDate[2]->sTime)); 
    $result = $data->cGetDefectData($to,$listFilterDirect);

    $resultDefect = $data->cGetM3Defect($to);
    $res = json_encode($result);
    $resDefect = json_encode($resultDefect);
    $resDate = json_encode($resultDate);
    $arrLine = $_POST['listFilterP'];
    $resLine = json_encode($arrLine);
    for ($j=0; $j < count($_POST['listFilterP']); $j++) { 
        // echo $_POST['listFilterP'][$j];
        ?>
        <div class="row mg0">
            <?php
                for ($i=0; $i < count($resultDate); $i++) { 
                    ?>
                        <div class="col-md-4" style="text-align: center; border: 1px solid #ccc">
                            <canvas id="<?php echo 'line'.$_POST['listFilterP'][$j].$i; ?>" style="margin-top: 1em; width: 100%;"></canvas> 
                            <h3 style="color:red;"><?php echo $resultDate[$i]->sTime; ?></h3>
                            <div class="donut-inner">
                                <h5 id="<?php echo 'totalline'.$_POST['listFilterP'][$j].$i; ?>"></h5>
                                <span><u><?php echo $resultDate[$i]->sTime." Line ".$_POST['listFilterP'][$j];?></u></span>
                            </div>
                        </div>
                    <?php
                }
            ?>  
        </div>
        <?php
    }
?>


 <button class="btn btn-light btn-sm appy-filter form-control" id="next"><i class="fa fa-play i-right"></i>Next</button>
    <script>
        $(document).ready(function(){
            $('#next').click(function(){
                window.clearTimeout(timer);
                loadS921Mc1(listFilterP);

            });
            timer = window.setTimeout(function(){
                if (pause_play == 1) {
                  loadS921Mc1(listFilterP);
                }
             }, 50000)

            let resFinal = <?php echo $res; ?>;
             // console.log(resFinal)
            let dataFinal = []
            let resM = ["A","B","C","D","E"]
            let resShift = ["D","N"]
            let direct = '<?php echo $direct; ?>';
            let dTime = '<?php echo $dTime; ?>';
            let timeNow = new Date('<?php echo $timeNow; ?>');
            let ms = getMs(timeNow)
            let mNow = ms[1]
            let shiftNow = ms[0]
            let resLine = <?php echo $resLine; ?>;
            let resDate = <?php echo $resDate; ?>;
            let defectArr = <?php echo $resDefect; ?>;
            console.log(defectArr)
            for (let i = 0; i < resFinal.length; i++) {
                let time = new Date(resFinal[i].sTime)
                let qr = resFinal[i].qr
                let line = resFinal[i].line
                let defect = resFinal[i].err_name
                let d = time.getDate();
                let t = time.getHours();
                let time1 = new Date(resFinal[i].sTime)
                time1.setDate(time1.getDate() - 1)
                let d1 = time1.getDate()

                if (t<8 && t >= 0) {
                    d = d1
                }
                dataFinal.push({
                    "line":line,
                    "d":d,
                    "cn":qr,
                    "defect":defect
                })
            }
            let finalData = []
            
            for (let i = 0; i < resLine.length; i++) {
                let line = "LINE: "+resLine[i]
                for (let j = 0; j < resDate.length; j++) {
                    let date = new Date(resDate[j].sTime)
                    let label = []
                    let num = []
                    for (let k = 0; k < defectArr.length; k++) {
                        let defect = defectArr[k].err_name
                        let data = dataFinal.filter(e=>e.line == resLine[i] && e.d == date.getDate() && e.defect == defect)
                        if (data.length>0) {
                            label.push(defect)
                            num.push(data.length)
                        }
                    }
                    finalData.push({line:resLine[i],date:date,label:label,num:num})
                }
            }
            console.log(finalData)
            for (let i = 0; i < resLine.length; i++) {
                let line = "LINE: "+resLine[i]
                for (let j = 0; j < resDate.length; j++) {
                    let date = new Date(resDate[j].sTime)

                    

                    Chart.register(ChartDataLabels);
                    let data = finalData.find(e=>e.line == resLine[i] && e.date.getDate() == date.getDate())
                    // console.log(data)
                    if (data) {
                        let sum = data.num.reduce((accumulator, object) => {
                            return accumulator + object;
                        }, 0);
                        $("#totalline"+resLine[i]+(j)).text("Total: "+sum+"ea")
                        const ctx = document.getElementById("line"+resLine[i]+(j)).getContext('2d');

                        const myChart = new Chart(ctx, {
                            type: 'doughnut',
                            data: {
                                labels: data.label,
                                  datasets: [
                                    {
                                      data: data.num,
                                        backgroundColor: [
                                          'rgb(255, 99, 132)',
                                          'rgb(255, 159, 64)',
                                          'rgb(255, 205, 86)',
                                          'rgb(75, 192, 192)',
                                          'rgb(54, 162, 235)',
                                          'rgb(215, 215, 215)',
                                          
                                        ],
                                      
                                    }
                                  ]
                            },
                            options: {
                            plugins: {
                                // legend:{
                                //  position:"bottom"
                                // },
                              datalabels: {
                                formatter: (value) => {
                                  return value;
                                },
                              },
                            },
                          },
                        });
                    }
                    



                }
            }
                
        });
    </script>