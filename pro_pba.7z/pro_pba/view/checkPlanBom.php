<?php
date_default_timezone_set("Asia/Ho_Chi_Minh");
$stime = date('Y-m-d H:i:s');

require('../controller/controller.php');
$data = new cEms();

$resBom = $data->cGetBom_DucDat();
// print_r($resBom);

$resData = $_POST['arrData'];

$arrData = json_encode($resData);
$arrBom = json_encode($resBom);
?>

<script>
    $(document).ready(function() {
        var arrData = <?php echo $arrData; ?>;
        var arrBom = <?php echo $arrBom; ?>;

        // console.log(arrData);
        console.log("Data Bom");
        console.log(arrBom);

        var arrFinish = [];
        var indexFinish = 0;
        var errFinish = "";

        // Get arr code HM
        var arrCodeHM = [];
        for (var x in arrData) {
            var codeHm = arrData[x]['code_hm'];
            var checkHm = arrCodeHM.find(e => {
                return e == codeHm;
            });

            if (checkHm == null) {
                arrCodeHM.push(codeHm);
            }
        }

        // console.log(arrCodeHM);
        for (var i = 0; i < arrCodeHM.length; i++) {
            var codeHm = arrCodeHM[i];
            codeHm = String(codeHm);
            // console.log(codeHm);

            var arrBomRun = [];

            var checkMes = arrData.filter(e => {
                return e.code_hm == codeHm;
            });

            var checkBom = arrBom.filter(e => {
                return e.code_hm == codeHm;
            });

            // console.log("Mes");
            // console.log(checkMes);

            // console.log("Check Bom");
            // console.log(checkBom);

            // Asign array to array
            var checkMesSub = [];
            for (var x in checkMes) {
                checkMesSub.push(checkMes[x]);
            }

            var checkBomSub = [];
            for (var x in checkBom) {
                checkBomSub.push(checkBom[x]);
            }

            for (var j = 0; j < checkMes.length; j++) {
                var code_hm = checkMes[j]['code_hm'];
                var code = checkMes[j]['code'];
                var point = checkMes[j]['point'];

                var indexMes = findWithAttr(checkMesSub, 'code', code);
                var indexBom = findWithAttrBom(checkBomSub, 'codes', code, 'qtys', point);

                if (indexBom !== -1) {
                    var codeBomRun = checkBomSub[indexBom]['codes'];
                    var qtyBomRun = checkBomSub[indexBom]['qtys'];

                    var checkBomRun = arrBomRun.find(e => {
                        return e.codes == codeBomRun && e.qtys == qtyBomRun;
                    })

                    if (checkBomRun == null) {
                        arrBomRun.push(checkBomSub[indexBom]);
                    }
                }

                if (indexMes !== -1 && indexBom !== -1) {
                    checkMesSub.splice(indexMes, 1);
                }
            }

            for (var k in arrBomRun) {
                var code = arrBomRun[k]['codes'];
                var point = arrBomRun[k]['qtys'];
                var indexBom = findWithAttrBom(checkBomSub, 'codes', code, 'qtys' ,point);

                if (indexBom !== -1) {
                    checkBomSub.splice(indexBom, 1);
                }
            }

            // console.log("End Mes");
            // console.log(checkMesSub);
            
            // console.log("End Bom");
            // console.log(checkBomSub);

            if (checkMesSub.length > 0) {
                errFinish = "Mes Thừa Code";

                for (var k in checkMesSub) {
                    var code_hm = checkMesSub[k]['code_hm'];
                    var type = checkMesSub[k]['type'];
                    var code = checkMesSub[k]['code'];
                    var point = checkMesSub[k]['point'];
                    var line = checkMesSub[k]['line'];
                    var name_err = errFinish;

                    arrFinish.push({
                        "code_hm": code_hm,
                        "type": type,
                        "code": code,
                        "point": point,
                        "line": line,
                        name_err: name_err
                    });

                    // console.log("Run Mes");
                }

            }
            
            if (checkBomSub.length > 0) {
                errFinish = "Bom Thừa Code";

                for (var k in checkBomSub) {
                    var code_hm = checkBomSub[k]['code_hm'];
                    var type = "---";
                    var code = checkBomSub[k]['codes'];
                    var point = checkBomSub[k]['qtys'];
                    var line = "---";
                    var name_err = errFinish;

                    arrFinish.push({
                        "code_hm": code_hm,
                        "type": type,
                        "code": code,
                        "point": point,
                        "line": line,
                        name_err: name_err
                    });

                    // console.log("Run Bom");
                }
            }
        }

        // console.log("Finish");
        // console.log(arrFinish);
        
        $.post('view/pCheckPlanBom.php', {
            arrFinish: arrFinish
        }, function(data) {
            console.log(data);
            successAlert(data);
        });

    });

    function removeItemArrMes(code, arr) {
        let index = findWithAttr(arr, 'code', code);

        if (index !== -1) {

            arr.splice(index, 1);
            // console.log(arr);
            // console.log("Run splice");
        }

        return arr;
    }

    function findWithAttr(array, attr, value) {
        for (var i = 0; i < array.length; i += 1) {
            if (array[i][attr] == value) {
                return i;
            }
        }
        return -1;
    }

    function findWithAttrBom(array, attr, value, attr2, value2) {
        for (var i = 0; i < array.length; i += 1) {
            if (String(array[i][attr]).includes(value) && array[i][attr2] ==  value2) {
            // if (String(array[i][attr]).includes(value)) {
                return i;
            }
        }
        return -1;
    }
</script>