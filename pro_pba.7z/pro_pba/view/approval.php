<?php
  require('../controller/controller.php');
  date_default_timezone_set("Asia/Ho_Chi_Minh");
  $data = new cEms();
  $id = $_POST['id'];
  $data->cUpStatusCheck($id);
  $inventData = $data->cGetInventById($id);
   $data->cDelTotal($inventData[0]->line);
  foreach ($inventData as $key) {
  	$data->cAddTotal($key->line,$key->code,$key->qty_real);
  }
  echo "Success";
}