<?php
	require('../controller/controller.php');
	$data = new cEms();
    $lct = $_POST['lct'];
    $result = $data->cGetQrByLct($lct);
    $resFinal = json_encode($result);
    // print_r($result);
?>
<div class="modal-header">
	<h5 class="modal-title card-title" style="color: #01b1c1;">Detail for rack : <?php echo "REPAIR - ".$lct; ?></h5>
	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</button>
</div>
<div class="modal-body">
    <div class="row" id = "form_pick">	
        <div class="col-md-12 showEditInfo">
            <table class="table table-hover table-bordered" id="calenz" style="font-size: 14px;width: 100%;">
                <thead style="background-color: #01b1c1; color: white;line-height: 15px;" class="text-center">
	                <tr>
	                    <th>QR</th>
	                    <th>Model</th>
	                    <th>Location</th>
	                    <th>Err</th>
	                    <th>Time</th>
	                </tr>
	            </thead>
	            <tbody>
	                
	            </tbody>
        	</table>
        </div>
    </div>
</div>
<script type="text/javascript">
	resFinal = <?php echo $resFinal; ?>;
    arrDid = [];
    function tableFinal(datax){
        let example = $('#calenz').DataTable({
            "lengthMenu": [[10, -1], [10, "All"]],
            "order": [[ 3, "desc" ]],
            "scrollY":        "200px",
            "scrollCollapse": true,
            "paging":         false,
            dom: 'Bfrtip',
            buttons: [
                'excel',
                'selectNone',
            ],
            data: datax,
            columns:[
            
            {data:"qr"},
            {data:"model"},
            {data:"sub_lct"},
            
            {data:"err_name"},
            {data:"lTime"}
            ],
            select: {
                style: 'multi'
            }
        });
        
    }
    tableFinal(resFinal);
</script>