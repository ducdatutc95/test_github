<?php
	require('../controller/controller.php');
	$data = new cEms();
    $lctData = $data->cGetLcts();
    $dataCount = $data->cGetCountbyLct();
    $resLct = json_encode($lctData);
    $resData = json_encode($dataCount);
?>
<div class="row">
	<div class="col-md-10">
		<h1>REPAIR MONITOR</h1>
	</div>
	<div class="col-md-2">
		<h1 id="total">Total: </h1>
	</div>
</div>

<div class="row" id="ds">
	
</div>
<script>
	$(document).ready(function(){
		resLct = <?php echo $resLct; ?>;
		resData = <?php echo $resData; ?>;
		html = ''
		let total = 0
		for (let i = 0; i < resLct.length; i++) {
			html+= '<div class="col-md-2 oneLct" lct = "'+resLct[i].lct+'">'
			html+='<h3 class="lct-title">'+resLct[i].lct+'</h3>'
			let listData = resData.filter(e=>e.sub_lct == resLct[i].lct)
			html+= '<table class="sub_tb">'
			let subTotal = 0
			for (let j = 0; j < listData.length; j++) {
				html+= '<tr class="li_err"><td>'+listData[j].err_name+'</td><td>'+listData[j].qty+' ea</td><td>'+listData[j].dif+'</td></tr>'
				subTotal+=parseInt(listData[j].qty)
			}
			total+=subTotal
			html+= '<tr><td><b>Total</b></td><td><b>'+subTotal+'ea</b></td></tr>'
			html+= '</table>'
			
			html+= '</div>'
		}
		$('#ds').html(html)
		$('#total').html("Total: "+total+"ea")
		$('.oneLct').click(function(){
			let lct = $(this).attr("lct");
					$.post('view/viewDetailQrByLct',  
		                {lct:lct},
		                function(data){
		                $("#modal-content").html(data);
		                $('#exampleModal').modal('show');
		            });
		})
	})
</script>