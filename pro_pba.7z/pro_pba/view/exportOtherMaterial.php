<?php
require('../controller/controller.php');
$data = new cEms();
     if (isset($_COOKIE['token'])) {

        $token = $_COOKIE['token'];
        $userInfo = $data->cGetUser($token);
        if (empty($userInfo)) {
          echo '<div class="panel-alert"><i class="fas fa-bell i-right"></i>Do not have access to this function. Please contact admin</div>';
          exit();
        }
    } else {
        echo '<div class="panel-alert"><i class="fas fa-bell i-right"></i>Do not have access to this function. Please contact admin</div>';
        exit();
    }
    $direct_2f = $userInfo->direct_2f;
    $listMaterial = $data->cGetListMaterial();
    $arrMaterial = json_encode($listMaterial);
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>[SET] PRODUCT - Export Material</title>

  <!-- liên kết css -->
  <link href="../vendor/css/style.css" rel="stylesheet" type="text/css" >
  <link rel="shortcut icon" type="image/png" href="../vendor/img/icon.jpg"/>
  <!-- liên kết bootstrap css -->
  <link href="../vendor/bootstrap/bootstrap.min.css" rel="stylesheet" type="text/css" >
  <link href="../vendor/bootstrap/bootstrap.css" rel="stylesheet" type="text/css" >
  <link href="../vendor/bootstrap/bootstrap-datetimepicker.css" rel="stylesheet" type="text/css" >
  <!-- liên kết datatable css -->
  <link href="../vendor/datatable/dataTables.min.css" rel="stylesheet" type="text/css" />
  <!-- liên kết font css -->
  <link rel="stylesheet" href="../vendor/fontawesome/css/all.min.css">
  <link href="../vendor/datatable/buttons.dataTables.min.css" rel="stylesheet" type="text/css" />
  <link href="../vendor/datatable/select.dataTables.css" rel="stylesheet" type="text/css" />
  <link href="../vendor/chart/chartist.min.css" rel="stylesheet" type="text/css" />
    <style>
            table{
                border-collapse: collapse;
            }
            table, td, th{
                border:1px solid black;
            }
        </style>
</head>
<div class="fixed-top">
   <nav class="navbar fixed-top navbar-expand-lg bg-light white scrolling-navbar"  style="border-bottom: 1px solid #d5d5d5;font-size:14px; ">
      <div class="container-fluid">
        <a class="navbar-brand waves-effect padding-0" href="./index" style = "text-align:center;">
          <span class = "logo-adz"><i class="fas fa-chart-bar"></i>DREAMTECH-EMS</span> </br>
        </a>
        
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="fas fa-bars" style="font-size: 1em;color: black;"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
          </ul>
          <ul class="navbar-nav mr-auto navbar-right" style="margin-right: 0 !important;display: flex;">
              <li class="nav-item menu-admin">
                <a class="nav-link waves-effect user"><i class="fa fa-user"></i><?php echo($userInfo->name); ?> </a>             
              </li>
              <li class="">
                
          </ul>
        </div>
          
      </div>
  </nav>
</div>
<div class="container" id="scan_screen">
   <div class="row" id = "form_pick">  
      <div class="col-md-12">
        <h5 class="tit-table modal-title card-title" style="width: 100%;"><i class="fa fa-flag i-right"></i>Export Other Material </h5>
        <div class="row" id = "form_pick" style="padding-top: 1em;">    
         
              <div class="col-md-4 showEditInfo">
                  
                  <div class="input-group input-group-sm mb-3">
                      <div class = "input-group-prepend">
                          <label class="input-group-text">Direct :</label>
                      </div>
                      <select id="direct" class="form-control form-control-sm custom-select">
                          <?php
                          if ($direct_2f == 'ADMIN' || $direct_2f == 'MANAGER' ) {
                            ?>
                              <option value="1F-KITTING">1F-KITTING</option>
                              <option value="2F-OFFICE">2F-OFFICE</option>
                              <option value="2F-UB-MOLD">2F-UB-MOLD</option>
                              <option value="2F-AUTO">2F-AUTO</option>
                            <?php
                          } else {
                            ?>
                              <option value="<?php echo $direct_2f; ?>"><?php echo $direct_2f; ?></option>
                            <?php
                          }
                        ?>
                      </select>
                      <div class = "input-group-prepend">
                        <label class="input-group-text">NG :</label>
                        <div class="input-group-text">
                            <input type="checkbox" id="status">
                        </div>
                    </div>
                  </div>
                  <div class="input-group input-group-sm mb-3">
                      <div class = "input-group-prepend">
                          <label class="input-group-text">Reason :</label>
                      </div>
                      <textarea class = "form-control rounded-0" rows="20" id = "note"></textarea>
                  </div>
                 
                  <button class="btn btn-danger form-control" id="submit"><i class="fas fa-save"></i> Xác Nhận Save Data </button>
              </div>
               <div class="col-md-8 showEditInfo">
              <div class="input-group input-group-sm mb-3">
                  <div class = "input-group-prepend">
                      <label class="input-group-text" style = "color:white;background-color:#01b1c1">Material :</label>
                  </div>
                  <input list="arrMaterial" id="code" class="form-control form-control-sm" placeholder="Material">
                  <datalist id="arrMaterial">
                      <?php foreach ($listMaterial as $key) {
                          ?>
                              <option value="<?php echo $key->code; ?>"><?php echo $key->code."/".$key->detail; ?></option>
                          <?php
                          } ?>

                  </datalist>
                  <div class = "input-group-prepend">
                      <button class = "btn btn-outline-info" id = "enter">ENTER</button>
                  </div>
              </div>    
              <table class="table table-hover table-bordered" id="export">
                  <thead style="background-color:#01b1c1;color:white; font-size: 16px;font-weight: bold; text-align: center;line-height:10px;">
                      <tr>
                          <td style="width: 3%;">No.</td> 
                          <td>Code</td>
                          <td>Qty</td>  
                          <td>Status</td>  
                          <td>Del</td>  
                      </tr>
                  </thead>
                  <tbody id="dataEx"> 
                  </tbody>
              
              </table>
              </div>
          </div>
      </div>
    </div>
</div>
<section class="copyright" style="margin-top: 0.2em;">
  <div class="container">
    <div class="row">
      <div class="col-md-12 ">
        <div class="text-center text-black">
          &copy; System 2022 Created by 44247-TranHa.
          All Rights Reserved by DreamTech Company
        </div>
      </div>
    </div>
  </div>
</section>
<script src='../vendor/js/socket.io.js'></script>
<script src="../vendor/js/jquery.js"></script>
<script src="../vendor/js/myQuery.js"></script>
<script src="../vendor/js/tree_menu.js"></script>
<script src="../vendor/chart/chartist.min.js"></script>
<script src="../vendor/chart/utils.js"></script>
<script src="../vendor/chart/chart.bundle.min.js"></script>
<script src="../vendor/js/tree.min.js"></script>
<script src="../vendor/js/sweetalert2.all.min.js"></script>
<script src="../vendor/bootstrap/bootstrap.min.js"></script>
<script src="../vendor/datatable/dataTables.min.js"></script>
<script src="../vendor/datatable/dataTables.select.js"></script>
<script src="../vendor/datatable/dataTables.buttons.min.js"></script>
<script src="../vendor/datatable/dataTables.buttonHtml5.min.js"></script>
<script src="../vendor/datatable/buttons.flash.min.js"></script>
<script src="../vendor/datatable/jszip.min.js"></script>
<script src="../vendor/bootstrap/moment.min.js"></script>
<script src="../vendor/bootstrap/bootstrap-datetimepicker.js"></script>  
<script src="../vendor/datatable/dataTables.bootstrap4.min.js"></script> 
<script type="text/javascript">
  $(document).ready(function(){
        $("#code").focus();
        let arrMaterial = <?php echo $arrMaterial; ?>;
        let i = 0
        let im = []
        $("#enter").click(function(){
                i = i+1;
                let code= $('#code').val().toUpperCase();
                var check = arrMaterial.find(e => e.code == code)
                var a = im.indexOf(code);
                var Stt = '';
                if(code == ''){
                    alert('Yêu cầu nhập code code !')
                } else {
                    if(check == null) {
                    Stt = 'Không có code này ! ';
                    } else if(a != -1){
                      Stt = 'Lỗi Trùng !'; 
                    }else{
                      im.push(code);
                      Stt = 'OK';
                    }
                    $('#dataEx').prepend('<tr><td>'+i+'</td><td>'+code+'</td><td><input type = "text" class = "form-control form-control-sm" value = "1"></td><td id = "st">'+Stt+'</td><td class = "text-center "><button class = "btn btn-outline-danger btn-sm">X</button></td></tr>');
                    if (Stt != 'OK') {$("#st").css("color", "Red");}
                    $("#code").focus();
                    $("#code").val('');
                }             
        })
        $("#code").keyup(function(event){
            if(event.keyCode===13){
                i = i+1;
                let code= $('#code').val().toUpperCase();
                var check = arrMaterial.find(e => e.code == code)
                var a = im.indexOf(code);
                var Stt = '';

                if(code == ''){
                    alert('Yêu cầu nhập code code !')
                } else {
                    if(check == null) {
                    Stt = 'Không có code này ! ';
                    }else if(a != -1){
                    Stt = 'Lỗi Trùng !'; 
                    }else{
                    im.push(code);
                    Stt = 'OK';
                    }
                    
                    $('#dataEx').prepend('<tr><td>'+i+'</td><td>'+code+'</td><td><input type = "text" class = "form-control form-control-sm" value = "1"></td><td id = "st">'+Stt+'</td><td class = "text-center "><button class = "btn btn-outline-danger btn-sm">X</button></td></tr>');
                    if (Stt != 'OK') {$("#st").css("color", "Red");}
                    $("#code").focus();
                    $("#code").val('');
                }      
            }
        })
        $('#dataEx').on('click', 'tr td button', function() {
        let code = $(this).closest('tr').find('td:eq(1)').text();
            if($(this).closest('tr').find('td:eq(3)').text() == 'OK'){
                im = removeItemArray(code,im)
            }
        $(this).closest('tr').remove();
        console.log(im)
    });

    $("#submit").click(function(){
      quest('Are you sure "Save data"? !').then((result) => {
        if (result.isConfirmed) {
          processing2()
          let direct= $("#direct").val().toUpperCase();
          let note = $("#note").val().toUpperCase();
          let status = $("#status").is(":checked");
          let data = document.getElementById('dataEx');
          let obj = [];
          for (let i = 0; i < data.rows.length; i++) {
            let objCells = data.rows.item(i).cells;
              if(objCells.item(objCells.length -2).innerHTML == "OK" && parseInt(objCells.item(2).children[0].value) > 0){
                let arrData = [];
                let code_val = objCells.item(1).innerHTML
                let qty_val = objCells.item(2).children[0].value
                obj.push({'code': code_val,'qty_in' : qty_val});
              }
            }
            if (note.length < 3) {
              errAlert("Yêu cầu nhập lý do!!!")
            } else {
              $("#submit").remove();
              $.post('exportingMaterial.php', {
                  obj:obj, id_plan:"OTHER",model_code:"Other",direct:direct, note:note,status:status
              },function(data){
                  successAlert(data);
              });
            }
          
        }
      })
    });
    
    });
</script>
</body>
</html>