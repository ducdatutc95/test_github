<?php
require('../controller/controller.php');
$data = new cEms();
if (isset($_COOKIE['token'])) {
    $token = $_COOKIE['token'];
    $userInfo = $data->cGetUser($token);
    if (empty($userInfo)) {

        header("Location:../login");
        exit();
    }
} else {
    header("Location:../login");
    exit();
}
$id = $_POST['id'];
$dataDetail = $data->cGetPlanDetail($id);
$resFinal = json_encode($dataDetail);
?>
<div class="modal-header">
    <h5 class="modal-title card-title" style="color: #01b1c1;">View Bom Detail</h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<div class="modal-body">
    <div class="row" id="form_pick">
        <div class="col-md-12">
            <table class="table table-hover table-bordered table-sm dataTable no-footer" id="bomTable" style="width: 100% !important;">
                <thead style="background-color: #588cc5; color: white;line-height: 15px;" class="text-center">
                    <tr>
                        <th>ID</th>
                        <th>ID Plan</th>
                        <th>Model Basic</th>
                        <th>Code</th>
                        <th>Point</th>
                        <th>Qty</th>
                        <th>Date</th>
                        <th>Shift</th>
                    </tr>

                </thead>
                <tbody id="BomList">

                </tbody>
            </table>
        </div>
    </div>
</div>


<script>
    $(document).ready(function() {
        resFinal = <?php echo $resFinal; ?>;
        arrDidS = [];

        function tableFinal(datax) {
            let exampleChild = $('#bomTable').DataTable({
                "lengthMenu": [
                    [10, -1],
                    [10, "All"]
                ],
                "order": [
                    [3, "desc"]
                ],
                "scrollY": "200px",
                "scrollCollapse": true,
                "responsive": true,
                "paging": false,
                dom: 'Bfrtip',
                buttons: [
                    'excel',
                    'selectNone',
                    {
                        text: ' <i class="fas fa-exchange-alt i-right" style="color:red;"></i>Change Code',
                        className: 'btnPractice',
                        action: function(e, dt, node, config) {
                            if (arrDidS.length != 1) {
                                errAlert("Please! Select only 1 row");
                            } else {
                                let id = arrDidS[0];

                                $.post('view/changeCode', {
                                        id: id
                                    },
                                    function(data) {
                                        $("#modal-content").html(data);
                                        $('#exampleModal').modal('show');
                                    });
                            }
                        },
                    }
                ],
                data: datax,
                columns: [{
                        data: "id"
                    },
                    {
                        data: "id_plan"
                    },
                    {
                        data: "basic"
                    },
                    {
                        data: "code"
                    },
                    {
                        data: "point"
                    },
                    {
                        data: "qty"
                    },
                    {
                        data: "sDate"
                    },
                    {
                        data: "shift"
                    }
                ],
                select: {
                    style: 'multi'
                }
            });
            exampleChild
                .on('select', function(e, dt, type, indexes) {
                    var rowData = exampleChild.rows(indexes).data().toArray();
                    for (var i = 0; i < rowData.length; i++) {
                        var x = arrDidS.indexOf(rowData[i]['id']);
                        if (x === -1) //neu ko ton tai
                            arrDidS.unshift(rowData[i]['id']); //thi push 
                        // console.log(arrDid)
                    }
                })
                .on('deselect', function(e, dt, type, indexes) {
                    var rowDataUn = exampleChild.rows(indexes).data().toArray();
                    for (var i = 0; i < rowDataUn.length; i++) {
                        var x = arrDidS.indexOf(rowDataUn[i]['id']);
                        arrDidS.splice(x, 1);
                    }
                });


        }
        tableFinal(resFinal);


        resize_table_child_open_in_modal('#exampleModal', '#bomTable');
    })

    function resize_table_child_open_in_modal(id_modal, id_table_open) {
        // Initialize DataTable only when the modal is fully shown
        $(id_modal).on('shown.bs.modal', function() {
            // Destroy any previous DataTable initialization if it exists
            if ($.fn.DataTable.isDataTable(id_table_open)) {
                $(id_table_open).DataTable().destroy();
            }

            // Reinitialize the DataTable inside the modal
            $(id_table_open).DataTable({
                responsive: true
            }).columns.adjust().responsive.recalc(); // Adjust columns to fit modal
        });

        // Optionally, handle when the modal is closed to clean up
        $(id_modal).on('hidden.bs.modal', function() {
            $(id_table_open).DataTable().destroy(); // Optional cleanup
        });
    }
</script>