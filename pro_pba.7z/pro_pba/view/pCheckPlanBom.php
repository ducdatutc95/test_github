<?php 
date_default_timezone_set("Asia/Ho_Chi_Minh");
$stime = date('Y-m-d H:i:s');

$author = "UP FILE";

require('../controller/controller.php');
$data = new cEms();


$arrFinish = isset($_POST['arrFinish'])?$_POST['arrFinish']:[];
// print_r($arrFinish);

$data->cDelLack();
for($i=0; $i< count($arrFinish); $i++) {
    $code_hm = $arrFinish[$i]['code_hm'];
    $type = $arrFinish[$i]['type'];
    $code = $arrFinish[$i]['code'];
    $point = $arrFinish[$i]['point'];
    $line = $arrFinish[$i]['line'];
    $name_err = $arrFinish[$i]['name_err'];
    $state = 1;

    $data->cAddLack($code_hm, $type, $code, $point, $line, $name_err, $state, $author, $stime);
}

echo "Save Successful"

?>

<!--  -->