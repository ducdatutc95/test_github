<?php
	require('../controller/controller.php');
	$data = new cEms();
	$dTime = $_POST['dTime'];
	$date = date($dTime." 08:00:00");
	$dateE = date('Y-m-d H:i:s', strtotime($date . ' +1 day'));
	$direct = $_POST['direct'];
	// $timeNow = date('Y-m-d H:i:s');
	$dTime = $_POST['dTime'];
    $folderName = "//192.168.63.12/2F_Data/".str_replace("-","",$dTime);
    $date = date($dTime." 08:00:00");
    $arrFile = scandir($folderName);
    $finalDataString = "";
    // print_r($arrFile);
    // foreach ($arrFile as $key) {
    for ($i=2; $i < count($arrFile); $i++) { 
        $fileName = $folderName."/".$arrFile[$i];
        $myfile= fopen($fileName,"r");
        $dataFile= fread($myfile,filesize($fileName));  
        $finalDataString .=  $dataFile;
    }
    substr($finalDataString,0,1);


	$listFilterDirect = "^".implode("|^",$_POST['listFilterP']);
    // $finalData = $data->cGetTrackingAll($direct,$listFilterDirect,$date,$dateE);

    $arrMc = $data->cGetLineConfig($direct,$listFilterDirect,$date,$dateE);
    $arrModel = $data->cGetModelLcd();
    // $arrLine = $data->cGetLineByDirect($direct);
$arrLine = $_POST['listFilterP'];
    // $resFinal = json_encode($finalData);
    $resMc = json_encode($arrMc);
    $resModel = json_encode($arrModel);
    $resLine = json_encode($arrLine);
?>
	<div class="row mg0">
		<?php 
			for ($i=1; $i <= count($_POST['listFilterP']); $i++) { 
				?>
				<div class="col-md-6">

					<canvas id="<?php echo 'Line '.$_POST['listFilterP'][$i-1]; ?>" style="margin-top: 1em; width: 100%;"></canvas> 
					<h3><?php echo "LINE: ".$_POST['listFilterP'][$i-1]." Error Rate (%)"; ?></h3>
				</div>
				<?php
			}
		 ?>
		
	</div>
	<button class="btn btn-light btn-sm appy-filter form-control" id="next"><i class="fa fa-play i-right"></i>Next</button>
    <script>
		$(document).ready(function(){
			$('#next').click(function(){
				window.clearTimeout(timer);
				loadMc3(listFilterP);
			});
			timer = window.setTimeout(function(){
				if (pause_play == 1) {
		          loadMc3(listFilterP);
		      	}
		     }, 50000)
			let resFinal = [<?php echo $finalDataString; ?>];

			let resLine = <?php echo $resLine; ?>;
			let resModel = <?php echo $resModel; ?>;
			let resMachine = <?php echo $resMc; ?>;
			let resM = ["A","B","C","D","E"]
			let resShift = ["D","N"]
			let resRow = ['Actual','Rate']
			let html = ""
			let direct = '<?php echo $direct; ?>';
			let dTime = '<?php echo $dTime; ?>';
			
			// let data = []
			for (let i = 0; i < resFinal.length; i++) {
				let time = new Date(resFinal[i].tTime)
				let t = time.getHours();
				let pn = resFinal[i].pn
				let mc = resFinal[i].mc
				let line = resFinal[i].line
				let direct = resFinal[i].direct
				let m = ''
				let shift = ''

				if (t>=8 && t < 10 || t>=20 && t < 22) {
					m = 'A'
					if (t>=8 && t < 10) {
						shift = "D"
					} else {
						shift = "N"
					}
				} else if (t>=10 && t < 13 || t>=22 || t < 1){
					m = 'B'
					if (t>=10 && t < 13) {
						shift = "D"
					} else {
						shift = "N"
					}
				} else if (t>=13 && t < 15 || t>=1 && t < 3){
					m = 'C'
					if (t>=13 && t < 15) {
						shift = "D"
					} else {
						shift = "N"
					}
				} else if (t>=15 && t < 17 || t>=3 && t < 5){
					m = 'D'
					if (t>=15 && t < 17) {
						shift = "D"
					} else {
						shift = "N"
					}
				} else if (t>=17 && t < 20 || t>=5 && t < 8){
					m = 'E'
					if (t>=17 && t < 20) {
						shift = "D"
					} else {
						shift = "N"
					}
				}
				resFinal[i].m = m
				resFinal[i].shift = shift
			}
			let dataChart=[]
			for (let i = 0; i < resLine.length; i++) {
				let line = resLine[i]
				let resMc = resMachine.filter(e=>e.line == line)
				dataChart[i] = {"line":"Line "+line,"data":[]}
				for (let j = 0; j < resMc.length; j++) {
					let mc = resMc[j].proc
					let arrPass = []
					let arrFail = []
					let arrTotal = []
					let arrRate = []
					dataChart[i].data[j] = {"mc": mc,"detail":{"p":[],"f":[],"t":[],"r":[]}}
					for (let s = 0; s < resShift.length; s++) {
						let shift = resShift[s]
						for (let n = 0; n < resM.length; n++) {
							let kg = resM[n]
							let dataPass = resFinal.filter(e=>e.direct == direct && e.line == line && e.mc == mc && e.shift == shift && e.m == kg && e.res == 'PASS')
							let dataFail = resFinal.filter(e=>e.direct == direct && e.line == line && e.mc == mc && e.shift == shift && e.m == kg && e.res == 'FAIL')
							arrPass.push(dataPass.length)
							arrFail.push(dataFail.length)
							arrTotal.push(dataPass.length+dataFail.length)
							let rate = Math.round((dataFail.length/(dataPass.length+dataFail.length))*1000)/10
							if (isNaN(rate)) {
								rate = 0
							}
							arrRate.push(rate)
						}
					}
					dataChart[i].data[j].detail.p = arrPass
					dataChart[i].data[j].detail.f = arrFail
					dataChart[i].data[j].detail.t = arrTotal
					dataChart[i].data[j].detail.r = arrRate
				}
				
			}
			for (let i = 0; i < dataChart.length; i++) {
				let onl = dataChart[i]
				Chart.register(ChartDataLabels);
			    const ctx = document.getElementById(onl.line).getContext('2d');
			    const myChart = new Chart(ctx, {
			        type: 'bar',
			        data: {
			            labels: ["DAY-A","DAY-B","DAY-C","DAY-D","DAY-E","NIGHT-A","NIGHT-B","NIGHT-C","NIGHT-D","NIGHT-E"],

			            datasets: [
			            {
			                label: onl.data[0].mc,
			                data: onl.data[0].detail.f,
						      borderColor: 'rgb(101 165 171 / 44%)',
						      backgroundColor: 'rgb(101 165 171 / 44%)',
						      // fill: true,
						      borderWidth: 1,
						      // pointStyle: 'rectRot',
						      // pointRadius: 5,
						      pointBorderColor: 'rgb(255, 0, 0)'
			            },
			            {
			                label: onl.data[1].mc,
			                data: onl.data[1].detail.f,
						      borderColor: 'rgb(225 155 49 / 44%)',
						      backgroundColor: 'rgb(225 155 49 / 44%)',
						      // fill: true,
						      borderWidth: 1,
						      // pointStyle: 'rectRot',
						      // pointRadius: 5,
						      pointBorderColor: 'rgb(255, 0, 0)'
			            },
			            {
			                label: onl.data[0].mc,
			                data: onl.data[0].detail.r,
						      borderColor: 'rgb(101 165 171)',
						      backgroundColor: 'rgb(101 165 171)',
						      borderWidth: 3,
						      type:'line'

			            },
			            {
			                label: onl.data[1].mc,
			                data: onl.data[1].detail.r,
						      borderColor: 'rgb(225 155 49)',
						      backgroundColor: 'rgb(225 155 49)',
						      borderWidth: 3,
						      type:'line'

			            }
			            
			            ]
			        },
			        options: {
			        	scales: {
						    y: {
						      beginAtZero: true          
						    }
						  },
			        	maintainAspectRatio: true,
				        responsive: true,
				        plugins: {
				            datalabels: { // This code is used to display data values
				                anchor: 'end',
				                align: 'top',
				                // formatter: Math.round,
				                font: {
				                    // weight: 'bold',
				                    size: 12,
				                }
				            }
				        }
				        
			        }
			    });
			}
		})
	</script>
