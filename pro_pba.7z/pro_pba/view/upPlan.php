<?php
  require('../controller/controller.php');
  date_default_timezone_set("Asia/Ho_Chi_Minh");
  $data = new cEms();
        if (isset($_COOKIE['token'])) {

        $token = $_COOKIE['token'];
        $userInfo = $data->cGetUser($token);
        if (empty($userInfo)) {
          echo '<div class="panel-alert"><i class="fas fa-bell i-right"></i>Do not have access to this function. Please contact admin</div>';
          exit();
        }
    }

?>
<div class="modal-header">
	<h5 class="tit-table modal-title card-title" style="width: 100%;"><i class="fa fa-flag i-right"></i>Upload MES PROD</h5>
	
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</button>
</div>
<div class="modal-body">
  <div class="row" id = "form_pick">	
    <div class="col-md-6">
        <div class="form-group">

          <div class="input-group input-group-sm mb-3">
              <div class = "input-group-prepend">
                  <label class="input-group-text">Date :</label>
              </div>
              <input id="sDate" type = "date" class="form-control form-control-sm" value="<?php 
            $start = strtotime("+1 Day");
            echo date('Y-m-d', $start); ?>">
          </div>
          <div class="input-group input-group-sm mb-3">
              <div class = "input-group-prepend">
                  <label class="input-group-text">Shift :</label>
              </div>
              <select class="form-control form-control-sm" id="shift">
                <option>DAY</option>
                <option>NIGHT</option>
              </select>
          </div>
          <div class="input-group input-group-sm mb-3">
              <div class = "input-group-prepend">
                  <label class="input-group-text">File Attach :</label>
              </div>
              <input id="img" type = "file" class="form-control form-control-sm" >
          </div>
          <button class="btn btn-primary form-control" id="confirm" style = "margin-bottom:1em;">
              <i class="fas fa-save"></i>
              Confirm
          </button>
         
        </div>
      </div>
      <div class="col-md-6">
         <a href="./vendor/data/plan.xlsx" download style="color:blue;">     >> Document Up MES PROD</a>
         
      </div>
      
	</div>
</div>
  <script type="text/javascript">
    $('#exampleModal').modal({backdrop: 'static', keyboard: false})
    
    $("#confirm").click(function(){
      quest('You will upload Plan !').then((result) => {
        if (result.isConfirmed) {
          processing()

          let dataG = new FormData();
          let i = $('#img').val();
          let sDate = $('#sDate').val();
          let shift = $('#shift').val();
      if (i != '') {
          var img = $('#img').prop('files')[0];
          var typeImg = img.type;
          match = ['application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','.csv'];
          if (typeImg == match[0] || typeImg == match[1] || typeImg == match[2]) {
            let author = '<?php echo $userInfo->manv; ?>';
            dataG.append('img', img);
            dataG.append('sDate', sDate);
            dataG.append('shift', shift);
            dataG.append('author', author);
            $(".close").click();
            $.ajax({
              url : 'view/pUpPlan.php',
              dataType : 'html',
              data : dataG,
              type : 'post',
              cache : false,
              processData : false,
              contentType : false,
              success : function(res){
                $(".n_data_after").html(res);
                
                // Được đặt sâu hơn trong tiến trình xử lý
                // successAlert(res)

              }
            });
          } else {
            errAlert('Please, check attach file again !')
          }
        } else {
          errAlert('Please, check input again !')
        }
      }
      })
    });
</script>