<?php
	require('../controller/controller.php');
	$data = new cEms();
	if (isset($_COOKIE['token'])) {
		$token = $_COOKIE['token'];
		$userInfo = $data->cGetUser($token);
		if (empty($userInfo)) {
      
          header("Location:../login");
          exit();
        }
	} else {
		header("Location:../login");
		exit();
	}

    $direct = $_POST['direct'];
    $line = "^".implode("|^",$_POST['listFilterP']);
    $listLine = "Line : ".implode("|",$_POST['listFilterP']);
    $dTime = $_POST['dTime'];
    $date = date($dTime." 08:00:00");
    $dateE = date('Y-m-d H:i:s', strtotime($date . ' +1 day'));
    $timeCal = $data->cGetLostTime($direct,$line,$date,$dateE);
    $resFinal = json_encode($timeCal);
?>
<div class="modal-header">
	<h5 class="modal-title card-title" style="color: #01b1c1;">Line Lost Time : <?php echo $direct." ".$listLine; ?></h5>
	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</button>
</div>
<div class="modal-body">
    <div class="row" id = "form_pick">	
        <div class="col-md-12 showEditInfo">
            <table class="table table-hover table-bordered" id="calenz" style="font-size: 14px;width: 100%;">
                <thead style="background-color: #01b1c1; color: white;line-height: 15px;" class="text-center">
                <tr>
                    <th>ID</th>
                    <th>Type</th>
                    <th>Line</th>
                    <th>Start</th>
                    <th>End</th>
                    <th>Diff</th>
                    <th>Detail</th>
                    <th>Author</th>
                </tr>
            </thead>
            <tbody>
                
            </tbody>
        </table>
        </div>

       
	</div>
</div>
<script>
    $(document).ready(function(){
        let final = <?php echo $resFinal; ?>;


    resFinal = <?php echo $resFinal; ?>;
    arrDid = [];
    function tableFinal(datax){
        let example = $('#calenz').DataTable({
            "lengthMenu": [[10, -1], [10, "All"]],
            "order": [[ 3, "desc" ]],
            
            "scrollCollapse": true,
            "paging":         false,
            dom: 'Bfrtip',
            buttons: [
                'excel',
                'selectNone',
            ],
            data: datax,
            columns:[
            
            {data:"id"},

            {data:"type"},
            {data:"line"},
            {data:"start_time"},
            {data:"end_time"},
            {
                "data": function(row, type, set){
                    let ml = row["diff"];
                    return parseInt(ml)/1000/60
                }
            },
            {data:"detail"},
            {data:"author"}
            ],
            select: {
                style: 'multi'
            }
        });
        example
        .on( 'select', function ( e, dt, type, indexes ) {
            var rowData = example.rows( indexes ).data().toArray();
            for (var i = 0; i < rowData.length; i++) {
                var x = arrDid.indexOf(rowData[i]['id']);
                if (x === -1) //neu ko ton tai
                    arrDid.unshift(rowData[i]['id']); //thi push 
                // console.log(arrDid)
            }
        } )
        .on( 'deselect', function ( e, dt, type, indexes ) {
            var rowDataUn = example.rows( indexes ).data().toArray();
            for (var i = 0; i < rowDataUn.length; i++) {
                var x = arrDid.indexOf(rowDataUn[i]['id']);
                arrDid.splice(x, 1);
            }
        });
    }
    tableFinal(resFinal);
    });
</script>