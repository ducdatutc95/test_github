<?php
    require('../controller/controller.php');
    date_default_timezone_set("Asia/Ho_Chi_Minh");
    $sTime =  date('Y-m-d H:i:s');
    $data = new cEms();
    $check = $data->cCheckToken();
    if ($check['status'] === false) {
        echo $check['data'];
    } else {
        $author  = $check['data']->manv;
        $id_plan = $_POST['id_plan'];
        $id_in = 'EX'.$id_plan.'-'.$author.strtotime($sTime);
        $model_code = $_POST['model_code'];
        $direct = $_POST['direct'];
        $note = $_POST['note'];
        $status = 'OK';
        if ($_POST['status'] == 'true') {
            $status = 'NG';
        };
        if (isset($_POST['obj'])) {
            foreach ($_POST['obj'] as $key) {
                $code = $key['code'];
                $qty= $key['qty_in'];
                $data->cAddMaterialHistory($id_in, $id_plan, $direct, $model_code, $code, $qty, $author, 'EX', $note, $status);
                $data->cExMaterial($direct, $code, $qty, $status);
            }
        echo "Success";
        } else {
            echo "Failed";
        }
    }
    
?>