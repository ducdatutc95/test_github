<?php
    require('../controller/controller.php');
    date_default_timezone_set("Asia/Ho_Chi_Minh");
    $data = new cEms();
    $id = $_POST['id'];
    $code_change = $_POST['code_change']; 
    $res = $data->cChangeCode($id, $code_change);
    echo $res;
   
    
?>