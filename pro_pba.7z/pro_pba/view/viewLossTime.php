<?php
	require('../controller/controller.php');
	$data = new cEms();
	$line_filter = $_POST['line_filter'];
	$dateStart = $_POST['dateStart'];
	$dateEnd = $_POST['dateEnd'];
    $finalData = $data->cGetLossTime($line_filter,$dateStart,$dateEnd);
    $resFinal = json_encode($finalData);
?>
<div class="col-md-12">
    <table class="table table-hover table-bordered table-sm dataTable no-footer" id = "finalTable">
        <thead style="background-color: #588cc5; color: white;line-height: 15px;" class="text-center">
            <tr>
                <th >ID</th>
                <th >Line</th>
                <th >Name</th>
                <th >Start</th>
                <th >End</th>
            </tr>
            
        </thead>
        <tbody id="finalList">
            
        </tbody>
    </table>
</div>
<div class="modal fade bd-example-modal-xl" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content" id="modal-content">
        </div>
    </div>
</div>
<script>
  
$(document).ready(function(){
	resFinal = <?php echo $resFinal; ?>;
	arrDid = [];
	function tableFinal(datax){
		let example = $('#finalTable').DataTable({
			"lengthMenu": [[10, -1], [10, "All"]],
			"order": [[ 3, "desc" ]],
			"scrollY":        "200px",
			
	        "scrollCollapse": true,
	        "paging":         false,
			dom: 'Bfrtip',
			buttons: [
			'excel',
			'selectNone',
			{
                text: ' <i class="far fa-eye i-right" style="color:red;"></i>View',
                className: 'btnPractice',
                action: function ( e, dt, node, config ) {
                	if(arrDid.length !=  1){
				        alert("Please! Select only 1 row");
				    }else{
					    $.post('view/viewDetailCause',  
			                {arrDid:arrDid},
			                function(data){
			                $("#modal-content").html(data);
			                $('#exampleModal').modal('show');
			            }); 
					}
           		}
           	},
           	{
                text: ' <i class="fas fa-plus i-right" style="color:red;"></i>Add',
                className: 'btnPractice',
                action: function ( e, dt, node, config ) {
				    $.post('view/addLossTime',  
		                {},
		                function(data){
		                $("#modal-content").html(data);
		                $('#exampleModal').modal('show');
		            }); 

           		}
           	},
           	{
                text: ' <i class="fas fa-edit i-right" style="color:red;"></i>Edit',
                className: 'btnPractice',
                action: function ( e, dt, node, config ) {
                	if(arrDid.length !=  1){
				        alert("Please! Select only 1 row");
				    }else{
					    $.post('view/editLossTime',  
			                {arrDid:arrDid},
			                function(data){
			                $("#modal-content").html(data);
			                $('#exampleModal').modal('show');
			            }); 
					}
           		}
           	},
           	{
                text: ' <i class="fas fa-trash i-right" style="color:red;"></i>Delete',
                className: 'btnPractice',
                action: function ( e, dt, node, config ) {
                	quest('Are you sure "Delete This Cause"? !').then((result) => {
			        	if (result.isConfirmed) {
						    $.post('view/deleteCause',  
				                {},
				                function(data){
				                $("#modal-content").html(data);
				                $('#exampleModal').modal('show');
				            }); 
						}
					}); 
           		}
           	},
			],
			data: datax,
			columns:[
			
			{data:"id"},
			{data:"line"},
			{data:"name"},
			{data:"startTime"},
			{data:"stopTime"}
			],
			select: {
				style: 'multi'
			}
		});
        example
		.on( 'select', function ( e, dt, type, indexes ) {
			var rowData = example.rows( indexes ).data().toArray();
			for (var i = 0; i < rowData.length; i++) {
				var x = arrDid.indexOf(rowData[i]['id']);
				if (x === -1) //neu ko ton tai
					arrDid.unshift(rowData[i]['id']); //thi push 
                // console.log(arrDid)
			}
		} )
		.on( 'deselect', function ( e, dt, type, indexes ) {
			var rowDataUn = example.rows( indexes ).data().toArray();
			for (var i = 0; i < rowDataUn.length; i++) {
				var x = arrDid.indexOf(rowDataUn[i]['id']);
				arrDid.splice(x, 1);
			}
		});
	}
	tableFinal(resFinal);
})
</script>