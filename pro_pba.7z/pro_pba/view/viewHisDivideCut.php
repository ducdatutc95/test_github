<?php
date_default_timezone_set("Asia/Ho_Chi_Minh");
$dateNow = date('Y-m-d h:i:s', time());

require('../controller/controller.php');
$data = new cEms();

$line_filter = isset($_POST['line_filter']) ? $_POST['line_filter'] : '';
$code_filter = isset($_POST['code_filter']) ? $_POST['code_filter'] : '';

$dateStart = $_POST['dateStart'];
$timeStart = $_POST['timeStart'];

$dateEnd = $_POST['dateEnd'];
$timeEnd = $_POST['timeEnd'];

$resHisCutFeeder = $data->cGetHisDivideCutFeeder($line_filter, $code_filter, $dateStart, $timeStart, $dateEnd, $timeEnd);
$resHisCutLine = $data->cGetHisDivideCutLine($line_filter, $code_filter, $dateStart, $timeStart, $dateEnd, $timeEnd);

// print_r($resHisCutFeeder);
// print_r($resHisCutLine);

$arrHisCutFeeder = json_encode($resHisCutFeeder);
$arrHisCutLine = json_encode($resHisCutLine);
?>

<div class="col-md-6 mt-3">
    <table class="table table-hover table-bordered table-sm dataTable no-footer" id="didTable">
        <thead style="background-color: #588cc5; color: white;line-height: 15px;" class="text-center">
            <tr>
                <th>Did</th>
                <th>Code</th>
                <th>Qty</th>
                <th>Line</th>
                <th>Status</th>
                <th>Author</th>
                <th>Time In</th>
            </tr>
        </thead>

        <tbody id="didList">
        </tbody>
    </table>
</div>

<div class="col-md-6 mt-3">
    <table class="table table-hover table-bordered table-sm dataTable no-footer" id="sumTable">
        <thead style="background-color: #588cc5; color: white;line-height: 15px;" class="text-center">
            <tr>
                <th>Code</th>
                <th>Line</th>
                <th>Qty</th>
                <th>Số Cuộn</th>
            </tr>
        </thead>

        <tbody id="sumList">
        </tbody>
    </table>
</div>

<script>
    $(document).ready(function() {
        let arrHisCutFeeder = <?php echo $arrHisCutFeeder; ?>;
        let arrHisCutLine = <?php echo $arrHisCutLine; ?>;
        // console.log(arrHisCutFeeder);
        // console.log(arrHisCutLine);

        // Mega object => did table
        let arrDidCut = [];
        let length_feeder = 0;
        length_feeder = arrHisCutFeeder.length;
        for (let i = 0; i < length_feeder; i++) {
            let objDidCut = {};

            objDidCut.did = arrHisCutFeeder[i].did;
            objDidCut.code = arrHisCutFeeder[i].code;
            objDidCut.qty = arrHisCutFeeder[i].qty;

            objDidCut.line = arrHisCutFeeder[i].line;
            objDidCut.status = arrHisCutFeeder[i].status;
            objDidCut.author = arrHisCutFeeder[i].author;

            objDidCut.sTime = arrHisCutFeeder[i].sTime;

            arrDidCut[i] = objDidCut;
            delete objDidCut;
        }

        let length_line = 0;
        length_line = arrHisCutLine.length;
        for (let i = 0; i < length_line; i++) {
            let objDidCut = {};

            objDidCut.did = arrHisCutLine[i].did;
            objDidCut.code = arrHisCutLine[i].code;
            objDidCut.qty = arrHisCutLine[i].qty;

            objDidCut.line = arrHisCutLine[i].line;
            objDidCut.status = 'Tủ Line';
            objDidCut.author = arrHisCutLine[i].author;

            objDidCut.sTime = arrHisCutLine[i].sTime;
            let index = i + length_feeder;
            arrDidCut[index] = objDidCut;

            delete objDidCut;
        }
        // console.log(arrDidCut);
        tableDid(arrDidCut);

        // Sum code + line
        let arrSumCodeCut = [];
        let indexSum = -1;
        let im = [];

        let length_sum = arrDidCut.length;
        for (let i = 0; i < length_sum; i++) {

            let code = arrDidCut[i].code;
            let line = arrDidCut[i].line;
            let checkExist = im.find(e => e.code == code && e.line == line);
            // console.log(checkExist);

            if (checkExist == null) {
                im.push({
                    "code": code,
                    "line": line
                });

                let findList = arrDidCut.filter(e => e.code == code && e.line == line);
                if (findList.length > 0) {
                    let sum_qty = 0;
                    for (let j = 0; j < findList.length; j++) {
                        sum_qty += parseInt(findList[j].qty);
                    }

                    let objCodeCut = {};
                    objCodeCut.code = code;
                    objCodeCut.line = line;
                    objCodeCut.qty = sum_qty;
                    objCodeCut.number_did = findList.length;

                    indexSum++;
                    arrSumCodeCut[indexSum] = objCodeCut;
                    delete objCodeCut;
                }
            }
        }

        // console.log(arrSumCodeCut);
        tableSum(arrSumCodeCut);
    })

    function tableDid(datax) {
        let example = $('#didTable').DataTable({
            // "lengthMenu": [
            //     [10, -1],
            //     [10, "All"]
            // ],
            // "order": [[ 4, "desc" ]],
            "paging": false,
            "scrollCollapse": true,
            "scrollY": "200px",
            dom: 'Bfrtip',
            buttons: [
                'excel',
                'selectNone',
            ],
            data: datax,
            columns: [{
                    data: "did"
                },
                {
                    data: "code"
                },
                {
                    data: "qty"
                },
                {
                    data: "line"
                },
                {
                    data: "status"
                },
                {
                    data: "author"
                },
                {
                    data: "sTime"
                }

            ],
            select: {
                style: 'multi'
            }
        });
    }

    function tableSum(datax) {
        let example = $('#sumTable').DataTable({
            // "lengthMenu": [
            //     [10, -1],
            //     [10, "All"]
            // ],
            // "order": [[ 4, "desc" ]],
            "scrollY": "100px",

            "scrollCollapse": true,
            "paging": false,
            dom: 'Bfrtip',
            buttons: [
                'excel',
                'selectNone',
            ],
            data: datax,
            columns: [{
                    data: "code"
                },
                {
                    data: "line"
                },
                {
                    data: "qty"
                },

                {
                    data: "number_did"
                },

            ],
            select: {
                style: 'multi'
            }
        });
    }
</script>