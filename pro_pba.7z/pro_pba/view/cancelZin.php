<?php
    require('../controller/controller.php');
    date_default_timezone_set("Asia/Ho_Chi_Minh");
    $data = new cEms();
    $check = $data->cCheckToken();
    $arrId = $_POST['arrDid'];
    if ($check['status'] === false) {
        echo $check['data'];
    } else {
        if($check['data']->roler < 2){
            echo "<h4>Do not have permission to edit this content</h4>";
            exit();
        } else {
        	for ($i=0; $i < count($arrId) ; $i++) { 
    			$id = $arrId[$i];
				$res = $data->cCancelZin($id);
				echo $res;
			}
		}
    }
?>