<?php
	require('../controller/controller.php');
	$data = new cEms();

	$dTime = $_POST['dTime'];
	$date = date($dTime." 08:00:00");
	$dateE = date('Y-m-d H:i:s', strtotime($date . ' +1 day'));
	$direct = $_POST['direct'];
	$listFilterDirect = "^".implode("|^",$_POST['listFilterP']);
    $finalData = $data->cGetUbTracking($listFilterDirect,$date,$dateE);
    $timeLineData = $data->cGetTimeLine($direct,$listFilterDirect,$date,$dateE);
    $arrMc = $data->cGetLineConfig($direct,$listFilterDirect,$date,$dateE);
    $arrModel = $data->cGetModelLcd();
    $arrLine = $_POST['listFilterP'];
    $resFinal = json_encode($finalData);
    $resTimeLine = json_encode($timeLineData);
    $resMc = json_encode($arrMc);
    $resModel = json_encode($arrModel);
    $resLine = json_encode($arrLine);
?>
<table class="table table-hover table-bordered" id = "main2Table" style="margin-top: 1em;font-size: 14px;">
		<thead style="background-color: #01b1c1; color: white;line-height: 15px;" class="text-center">
            <tr>
            	<th rowspan="2" style="vertical-align: middle;" >LINE</th>
                <th rowspan="2" colspan="2" style="vertical-align: middle;">구분</th>
                <th colspan="6" style="vertical-align: middle;">DAY</th>
                <th colspan="6" style="vertical-align: middle;">NIGHT</th>
                <th rowspan="2" style="vertical-align: middle;">TOTAL</th>
            </tr>
            <tr>
            	<th style="vertical-align: middle;">A</th>
                <th style="vertical-align: middle;">B</th>
                <th style="vertical-align: middle;">C</th>
                <th style="vertical-align: middle;">D</th>
                <th style="vertical-align: middle;">E</th>
                <th style="vertical-align: middle;">Shift Total</th>
                <th style="vertical-align: middle;">A</th>
                <th style="vertical-align: middle;">B</th>
                <th style="vertical-align: middle;">C</th>
                <th style="vertical-align: middle;">D</th>
                <th style="vertical-align: middle;">E</th>
                <th style="vertical-align: middle;">Shift Total</th>
            </tr>
        </thead>
        <tbody id="showTable" class="reportBody">
        	
        </tbody>
    </table>

    <script>
		$(document).ready(function(){
			let resFinal = <?php echo $resFinal; ?>;
			// console.log(resFinal)
			let resTimeLine = <?php echo $resTimeLine; ?>;
			let resLine = <?php echo $resLine; ?>;
			let resModel = <?php echo $resModel; ?>;
			let resType = ['INPUT','OUT'];
			let resM = ["A","B","C","D","E"]
			let resShift = ["D","N"]
			let resRow = ['Actual','Rate']
			let html = ""
			let direct = '<?php echo $direct; ?>';
			let dTime = '<?php echo $dTime; ?>';
			
			// let data = []
			for (let i = 0; i < resFinal.length; i++) {
				let time = new Date(resFinal[i].sTime)
				let t = time.getHours();
				let pn = resFinal[i].pn
				let mc = resFinal[i].mc
				let line = resFinal[i].line
				let direct = resFinal[i].direct
				let m = ''
				let shift = ''

				if (t>=8 && t < 10 || t>=20 && t < 22) {
					m = 'A'
					if (t>=8 && t < 10) {
						shift = "D"
					} else {
						shift = "N"
					}
				} else if (t>=10 && t < 13 || t>=22 || t < 1){
					m = 'B'
					if (t>=10 && t < 13) {
						shift = "D"
					} else {
						shift = "N"
					}
				} else if (t>=13 && t < 15 || t>=1 && t < 3){
					m = 'C'
					if (t>=13 && t < 15) {
						shift = "D"
					} else {
						shift = "N"
					}
				} else if (t>=15 && t < 17 || t>=3 && t < 5){
					m = 'D'
					if (t>=15 && t < 17) {
						shift = "D"
					} else {
						shift = "N"
					}
				} else if (t>=17 && t < 20 || t>=5 && t < 8){
					m = 'E'
					if (t>=17 && t < 20) {
						shift = "D"
					} else {
						shift = "N"
					}
				}
				resFinal[i].m = m
				resFinal[i].shift = shift
			}
			for (let i = 0; i < resLine.length; i++) {
				
				let line = resLine[i]
				
				html += "<tr><td style = 'vertical-align: middle;text-align:center;background-color:#535c92;color:white;font-weight:bold' rowspan = '"+(resType.length*3)+"'>LINE "+line+"<div>"
		
				html += "</div></td>"
				for (let j = 0; j < resType.length; j++) {
					let arrActual=[]
					let arrTarget=[]
					let mc = resType[j]
					let tt = 12
					let model = 'S921'
					if (j%2 != 0) {
						html += "<tr>"
					}
					html += "<td colspan='2' style = 'vertical-align: middle;text-align:center;background-color:#535c92;color:white;font-weight:bold'>Target</td>"
					let tagetTotal = 0
					for (let s = 0; s < resShift.length; s++) {
						let sub_total = 0
						let shift = resShift[s]
						for (let n = 0; n < resM.length; n++) {
							let kg = resM[n]
							let target
							let timeLine = resTimeLine.filter(e=>e.direct == direct && e.line == line && e.proc == mc && e.shift == shift && e.kg == kg && e.type == 'CAL')
							let sumCal = timeLine.reduce((accumulator, e) => {
							  return accumulator + parseInt(e.diff);
							}, 0);
							if (n == 1 || n == 3) {
								target = (6600-sumCal/1000)/parseInt(tt)
							}else if (n == 4) {
								if (sumCal>0) {
									target = (10800-sumCal/1000)/parseInt(tt)
								} else {
									target = (7200-sumCal/1000)/parseInt(tt)
								}
								
							} else {
								target = (7200-sumCal/1000)/parseInt(tt)
							}
							if (target <= 0) {
								target = 0
							} 
							sub_total+=parseInt(target)
							let cl = 'sub_total inCal'
							if (timeLine.length>0) {
									cl = 'sub_total inCal calendar'
								}
							html += "<td style = 'vertical-align: middle;text-align:center;background-color:#dfdfdf' class='"+cl+"' direct='"+direct+"' line='"+line+"' mc='"+mc+"' shift='"+shift+"' kg='"+kg+"'>"+target+"</td>"
							// if (target <= 0) {
							// 	arrTarget.push(0)
							// } else {	
								arrTarget.push(target)
							// }
							
						}
						html += "<td style = 'vertical-align: middle;text-align:center;background-color:#dfdfdf' class='sub_total'>"+sub_total+"</td>"
						arrTarget.push(sub_total)
						tagetTotal += sub_total 
					}
					
					html += "<td style = 'vertical-align: middle;text-align:center;background-color:#dfdfdf' class='sub_total'>"+tagetTotal+"</td>"
					html += "</tr>"
					arrTarget.push(tagetTotal)

					html += "<tr>"
					html += "<td rowspan = '2' style = 'vertical-align: middle;text-align:center;' class='sub_total'>"+mc+"<p style='margin-top:1em;color:#a7a7a7;'>"+model+"</p></td>"
					for (let k = 0; k < resRow.length; k++) {
						let row = resRow[k]
						if (k== 0) {

							//actual
							html += "<td style = 'vertical-align: middle;text-align:center;' class='sub_total'>"+row+"</td>"
							let actualTotal = 0
							for (let s = 0; s < resShift.length; s++) {
								let shift = resShift[s]
								let sub_total = 0
								
								for (let l = 0; l < resM.length; l++) {
									let m = resM[l]
									let actual = resFinal.filter(e=>e.line == line && e.status == mc && e.shift == shift && e.m == m)
									let timeLine = resTimeLine.filter(e=>e.direct == direct && e.line == line && e.proc == mc && e.shift == shift && e.kg == m && e.type == 'LOSS')

									let cl = 'inLoss'
									if (timeLine.length>0) {
										cl = 'inLoss remark'
									}
									html += "<td style = 'vertical-align: middle;text-align:center;' class='"+cl+"' direct='"+direct+"' line='"+line+"' mc='"+mc+"' shift='"+shift+"' kg='"+m+"'>"+actual.length+"</td>"
									sub_total+=parseInt(actual.length)
									arrActual.push(parseInt(actual.length))
								}
								html += "<td style = 'vertical-align: middle;text-align:center;' class='sub_total'>"+parseInt(sub_total)+"</td>"
								actualTotal += parseInt(sub_total)
								arrActual.push(sub_total)
							}
							html += "<td style = 'vertical-align: middle;text-align:center;' class='sub_total'>"+parseInt(actualTotal)+"</td>"
							html += "</tr>"
							arrActual.push(actualTotal)
							
						} else {
							//rate
							html += "<tr>"
							
							html += "<td style = 'vertical-align: middle;text-align:center;' class='sub_total'>"+row+"</td>"

							for (let f = 0; f < arrActual.length; f++) {
								let acc = arrActual[f]
								let tar = arrTarget[f]
								let rate = Math.round(parseInt(acc)/parseInt(tar)*1000)/10
								if (!rate || isNaN(rate) || !isFinite(rate)) {
									rate = 0
								}
								html += "<td style = 'vertical-align: middle;text-align:center;' class='sub_total'>"+rate+"%</td>"
							}

							html += "</tr>"
						}
					}
					
				}
				
			}

			$("#showTable").html(html)




			//event
			$('.inCal').click(function(){
				let direct = $(this).attr("direct");
				let line = $(this).attr("line");
				let mc = $(this).attr("mc");
				let shift = $(this).attr("shift");
				let kg = $(this).attr("kg");
				$.post('view/addCalender',  

	                {dTime:dTime,direct:direct,line:line,mc:mc,shift:shift,kg:kg},
	                function(data){
	                $("#modal-content").html(data);
	                $('#exampleModal').modal('show');
	            });
			})

			$('.inLoss').click(function(){
				let direct = $(this).attr("direct");
				let line = $(this).attr("line");
				let mc = $(this).attr("mc");
				let shift = $(this).attr("shift");
				let kg = $(this).attr("kg");
				$.post('view/addLoss',  
	                {dTime:dTime,direct:direct,line:line,mc:mc,shift:shift,kg:kg},
	                function(data){
	                $("#modal-content").html(data);
	                $('#exampleModal').modal('show');
	            });
			})
		})
	</script>
