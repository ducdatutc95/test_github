<?php
    require('../controller/controller.php');
    $data = new cEms();
    if (isset($_COOKIE['token'])) {
        $token = $_COOKIE['token'];
        $userInfo = $data->cGetUser($token);
        if (empty($userInfo)) {
      
          header("Location:../login");
          exit();
        }
    } else {
        header("Location:../login");
        exit();
    }
$listModel = $data->cGetListModel();
$id = $_POST['arrDid'][0];
$dataDetail = $data->cGetPlanDetail($id);
?>
<div class="modal-header">
    <h5 class="modal-title card-title" style="color: #01b1c1;">Edit Plan</h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<div class="modal-body">
    <div class="row" id = "form_pick">  
        <div class="col-md-6 showEditInfo">
            <div class="input-group input-group-sm mb-3">
                <div class = "input-group-prepend">
                    <label class="input-group-text">Line :</label>
                </div>
                <select id="line" class="form-control form-control-sm">
                    <option></option>
                    <?php
                      for ($i=1; $i <= 7; $i++) { 
                         echo '<option value="'.($i < 10 ? 'DMC-0'.$i : "DMC-".$i).'">Line '.($i < 10 ? 'DMC-0'.$i : "DMC-".$i).'</option>';

                        for ($i=1; $i <= 7; $i++) { 
                           echo '<option value="'.($i < 10 ? 'EMS-0'.$i : "EMS-".$i).'">Line '.($i < 10 ? 'EMS-0'.$i : "EMS-".$i).'</option>';
                        }
                    ?>
                    <option value="01" selected>Line 01</option>
                    <?php
                        for ($i=2; $i <= 32; $i++) { 
                           echo '<option value="'.($i < 10 ? '0'.$i : $i).'">Line '.($i < 10 ? '0'.$i : $i).'</option>';
                        }
                    ?>
                </select>
            </div>
            <div class="input-group input-group-sm mb-3">
                <div class = "input-group-prepend">
                    <label class="input-group-text">Model Code :</label>
                </div>
                <input id="model_code" class="form-control form-control-sm" placeholder="Model Code"  list="arrModelCode" value="<?php echo $dataDetail->model_code; ?>">
            </div>
            
        </div>

        <div class="col-md-6 showEditInfo">
            <div class="input-group input-group-sm mb-3">
                <div class = "input-group-prepend">
                    <label class="input-group-text">Plan Date :</label>
                </div>
                <input id="sDate" type="date" class="form-control form-control-sm" placeholder="Start Time"  value="<?php echo $dataDetail->sDate; ?>">
            </div>
             <div class="input-group input-group-sm mb-3">
                <div class = "input-group-prepend">
                    <label class="input-group-text">Qty :</label>
                </div>
                <input id="qty" class="form-control form-control-sm" value="<?php echo $dataDetail->qty; ?>">
            </div>
            
            <button class="btn btn-success form-control" id="confirm">
                <i class="fas fa-save"></i>
                Confirm
            </button>
            <i style="color:red;margin-bottom:1em;">* Please do not close the website or reload the page before receiving the 'Success' message</i>
        </div>
    </div>
</div>
<script>
    $(document).ready(function(){
    let modelData = <?php echo json_encode($listModel); ?>;
        $("#confirm").click(function(){
            let id = '<?php echo $id; ?>';
            let line = $('#line').val().toUpperCase();
            let model_code = $('#model_code').val().toUpperCase();
            let sDate = $('#sDate').val().toUpperCase();
            let qty = $('#qty').val().toUpperCase();
            let checkModel = modelData.find(e=>e.model_code == model_code)
            if(checkModel == null || line == '' || parseInt(qty)<1){
                errAlert("Check Input Data again !")
            } else {
                $("#confirm").remove();
                $.post('view/editingPlan', 
                    {id:id,line:line,model_code:model_code,sDate:sDate,qty:qty}, 
                function(data){
                    $(".close").click();
                    successAlert(data);
                    loadPlan()
                });
            }
                
        });
    });
</script>