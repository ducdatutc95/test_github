<?php
    require('../controller/controller.php');
    date_default_timezone_set("Asia/Ho_Chi_Minh");
    $data = new cEms();
    $author  = $_POST['author'];
    $line  = $_POST['line'];
    if (isset($_POST['dataIn'])) {
        $dataIn = $_POST['dataIn'];
        for ($i=0; $i < count($dataIn); $i++) {
            $zin = $dataIn[$i]['zin'];
            $ltime = $dataIn[$i]['time'];
            $data->cConfirmZin($zin, $line, $ltime, $author);
        }
    }
    echo '<h4>Success</h4>';
?>