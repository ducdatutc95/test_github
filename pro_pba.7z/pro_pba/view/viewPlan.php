<?php
	require('../controller/controller.php');
	date_default_timezone_set("Asia/Ho_Chi_Minh");
	$data = new cEms();
	$line_filter = $_POST['line_filter'];
	$model_filter = $_POST['model_filter'];
	$dateStart = $_POST['dateStart'];
	$dateEnd = $_POST['dateEnd'];
    $finalData = $data->cGetPlanFromMes($line_filter,$model_filter,$dateStart,$dateEnd);

    $resFinal = json_encode($finalData);
    $fujiData = $data->cGetDataFuji($line_filter);
    $shift = 'DAY';
    if (date('H') > 19 || date('H')<8) {
    	$shift = 'NIGHT';
    }
    $s = strtotime("-8 Hour");
    $sDate = date('Y-m-d', $s);
    // $finalTotal = $data->cGetTotalLine($line_filter);

    $detail = $data->cGetDetailPlanFromMes($line_filter, $shift, $sDate);
    $finalRemain = $data->cGetQtyProd($line_filter,$model_filter);
    $resRemain = json_encode($finalRemain);
    // $resTotal = json_encode($finalTotal);
    $resDetail = json_encode($detail);
    $resFuji = json_encode($fujiData);
?>
<div class="col-md-6">
    <table class="table table-hover table-bordered table-sm dataTable no-footer" id = "finalTable">
        <thead style="background-color: #588cc5; color: white;line-height: 15px;" class="text-center">
            <tr>
                <th >ID</th>
                <th >Direct</th>
                <th >Model</th>
                <th >Basic</th>
                <th >Plan</th>
                <th >Đã sản xuất</th>
                <th >Plan Date</th>
                <th >Shift</th>
            </tr>
        </thead>
        <tbody id="finalList">
        </tbody>
    </table>
</div>

<div class="col-md-6">
    <table class="table table-hover table-bordered table-sm dataTable no-footer" id = "totalTable">
        <thead style="background-color: #588cc5; color: white;line-height: 15px;" class="text-center">
            <tr>
                <th >Line</th>
                <th >Module</th>
                <th >Slot</th>
                <th >Model</th>
                <th >Code</th>
                <th >Status</th>
            </tr>
        </thead>
        <tbody id="totalList">
        </tbody>
    </table>
</div>

<div class="n_data_after"></div>


<script>
$(document).ready(function(){
	resFinal = <?php echo $resFinal; ?>;
	resRemain = <?php echo $resRemain; ?>;
	resDetail = <?php echo $resDetail; ?>;
	resFuji = <?php echo $resFuji; ?>;
	sDate = '<?php echo $sDate; ?>';
	shift = '<?php echo $shift; ?>';

	// console.log(resFuji);

	arrDid = [];
	function tableFinal(datax){
		let example = $('#finalTable').DataTable({
			"lengthMenu": [[10, -1], [10, "All"]],
			"order": [[ 6, "desc" ],[ 7, "asc" ]],
			"scrollY":        "200px",
			
	        "scrollCollapse": true,
	        "paging":         false,
			dom: 'Bfrtip',
			buttons: [
				'excel',
				'selectNone',
				{
	                text: ' <i class="fas fa-eye i-right" style="color:red;"></i>View',
	                className: 'btnPractice',

	                action: function ( e, dt, node, config ) {
	                	if(arrDid.length !=  1){
					        errAlert("Please! Select only 1 row");
					    } else {
					    	let id = arrDid[0];
		                	$.post('view/viewDetailPlan',  
					            {id:id},
					            function(data){
					            $("#modal-content").html(data);
					            $('#exampleModal').modal('show');
					        });
		                }
	           		}
	           	},
				{
	                text: ' <i class="fas fa-upload i-right" style="color:red;"></i>UpLoad Plan',
	                className: 'btnPractice',
	                action: function ( e, dt, node, config ) {
					    $.post('view/upPlan',  
			                {},
			                function(data){
			                $("#modal-content").html(data);
			                $('#exampleModal').modal('show');
			            }); 

	           		}
	           	}
	     		,{
	                text: ' <i class="fas fa-exchange-alt i-right" style="color:red;"></i>Change Line',
	                className: 'btnPractice',
	                action: function ( e, dt, node, config ) {
	                	if(arrDid.length !=  1){
					        errAlert("Please! Select only 1 row");
					    } else {
					        let id = arrDid[0];
					        
			    			$.post('view/changeLine',  
				                {id:id},
				                function(data){
				                $("#modal-content").html(data);
		                		$('#exampleModal').modal('show');
				            });
	           			}
	           		},
	           	}
	           	,{
	                text: ' <i class="fas fa-check i-right" style="color:red;"></i>Confirm Prod',
	                className: 'btnPractice',
	                action: function ( e, dt, node, config ) {
	                	if(arrDid.length !=  1){
					        errAlert("Please! Select only 1 row");
					    } else {
					        let id = arrDid[0];
					        let dataDetail = resFinal.find(a=>a.id_plan == id)
					        let direct = dataDetail.line;
					  		console.log(dataDetail)
					  			let qty = prompt('Input Product Qty');
						        let max = parseInt(dataDetail.qty)-parseInt(dataDetail.qty_out)
						    	if (!parseInt(qty) || parseInt(qty) <=0 || parseInt(qty) > parseInt(max)) {
								    errAlert("Check Input Again !")
								  } else {
								  	processing2()
					    			$.post('view/exportMaterialbyPlan',  
						                {dataDetail:dataDetail,qty_code:parseInt(qty)},
						                function(data){
						                successAlert(data);
						            });
								}
	           			}
	           		},
	           	}
			],
			data: datax,

			columns:[
			
			{data:"id_plan"},
			{data:"line"},
			{data:"model"},
			{data:"basic"},
			{data:"qty"},
			{
		        "data": function(row, type, set){
		          let id_plan = row['id_plan'];
		          let qty_pro = resRemain.find(e=>e.id_plan == id_plan)
		          if (qty_pro != undefined) {
		          	return qty_pro.qty_out
		          } else {
		          	return 0
		          }
		          
		        }
		    },
			{data:"sDate"},
			{data:"shift"},
			],
			select: {
				style: 'multi'
			}
		});
		example
		.on( 'select', function ( e, dt, type, indexes ) {
			var rowData = example.rows( indexes ).data().toArray();
			for (var i = 0; i < rowData.length; i++) {
				var x = arrDid.indexOf(rowData[i]['id_plan']);
				if (x === -1) //neu ko ton tai
					arrDid.unshift(rowData[i]['id_plan']); //thi push 
                // console.log(arrDid)
			}
		} )
		.on( 'deselect', function ( e, dt, type, indexes ) {
			var rowDataUn = example.rows( indexes ).data().toArray();
			for (var i = 0; i < rowDataUn.length; i++) {
				var x = arrDid.indexOf(rowDataUn[i]['id_plan']);
				arrDid.splice(x, 1);
			}
		});
	}
	tableFinal(resFinal);
	// console.log(resDetail)

	function tableTotal(datax){
		let example = $('#totalTable').DataTable({
			"lengthMenu": [[10, -1], [10, "All"]],
			"order": [[ 5, "asc" ],[ 0, "asca" ]],
			"scrollY":        "200px",
			
	        "scrollCollapse": true,
	        "paging":         false,
			dom: 'Bfrtip',
			buttons: [
				'excel',
				'selectNone'
			],
			data: datax,
			rowCallback: function( row, data, index ) {
			  let line = data['LINE'];
		          let code = data['CODE'];
		          let m = data['MODEL_NAME'];
		          let model = m[0].replace(" ", '-');

				// let isTrue = resDetail.find(e=>e.line == line && e.code == code && e.shift == shift && e.sDate == sDate && e.basic.replaceAll(" ", '-').includes(model));
				// if (!isTrue ) {
				// 		$(row).addClass('redClass');
				// } 
					


				let isTrue = resDetail.find(e=>e.line == line && e.code == code && e.shift == shift && e.sDate == sDate && e.basic.replaceAll(" ", '-').includes(model));

				if (!isTrue ) {
					
				    $(row).addClass('redClass');


					console.log(line);
					console.log(code);

				} 


			},
			columns:[
			
			{data:"LINE"},
			{data:"MODULE"},
			{data:"SLOT"},
			{
		        "data": function(row, type, set){
		          let model = row['MODEL_NAME'].split("-");
		          return model[0].replaceAll(" ", '-');
		        }
		    },
			{data:"CODE"},
			{
		        "data": function(row, type, set){
		          let line = row['LINE'];
		          let code = row['CODE'];
		          let m = row['MODEL_NAME']
		          let model = m[0].replace(" ", '-');
		          // console.log(code)
		          // console.log(model)
		          // console.log(shift)
		          // console.log(sDate)
		          // console.log(resDetail)
		          let isTrue = resDetail.find(e=>e.line == line && e.code == code && e.shift == shift && e.sDate == sDate && e.basic.replaceAll(" ", '-').includes(model))
		          if (isTrue) {
		          	return "OK"
		          } else {
		          	return "ERROR"
		          }
		          
		        }
		    }
			
			],
			select: {
				style: 'multi'
			}
		});
		
	}

	tableTotal(resFuji);
})
</script>