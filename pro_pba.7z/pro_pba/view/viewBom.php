<?php
	require('../controller/controller.php');
	$data = new cEms();
	$model_filter = $_POST['model_filter'];
	$listFilterProcess = "^".implode("|^",$_POST['listFilterP']);
    $finalData = $data->cGetBom($model_filter,$listFilterProcess);
    $resFinal = json_encode($finalData);
    $lctData = $data->cGetLct();
    $resLct = json_encode($lctData);
?>
<div class="col-md-8">
    <table class="table table-hover table-bordered table-sm dataTable no-footer" id = "finalTable">
        <thead style="background-color: #588cc5; color: white;line-height: 15px;" class="text-center">
            <tr>
                <th >Model Basic</th>
                <th >Model Code</th>
                <th >Process</th>
                <th >Code</th>
            </tr>
            
        </thead>
        <tbody id="finalList">
            
        </tbody>
    </table>
</div>
<div class="col-md-4">
    <table class="table table-hover table-bordered table-sm dataTable no-footer" id = "lctTable">
        <thead style="background-color: #588cc5; color: white;line-height: 15px;" class="text-center">
            <tr>
            	<th >ID</th>
                <th >Location</th>
                <th >Errname</th>
            </tr>
            
        </thead>
        <tbody id="lctList">
            
        </tbody>
    </table>
</div>
<script>
  
$(document).ready(function(){
	resFinal = <?php echo $resFinal; ?>;
	arrDid = [];
	function tableFinal(datax){
		let example = $('#finalTable').DataTable({
			"lengthMenu": [[10, -1], [10, "All"]],
			"order": [[ 3, "desc" ]],
			"scrollY":        "200px",
			
	        "scrollCollapse": true,
	        "paging":         false,
			dom: 'Bfrtip',
			buttons: [
			'excel',
			'selectNone',
				,
           	{
                text: ' <i class="fas fa-upload i-right" style="color:red;"></i>Upload',
                className: 'btnPractice',
                action: function ( e, dt, node, config ) {
				    $.post('view/upBom',  
		                {},
		                function(data){
		                $("#modal-content").html(data);
		                $('#exampleModal').modal('show');
		            }); 

           		}
           	}
           	
			],
			data: datax,
			columns:[
			
			{data:"model_basic"},
			{data:"model_code"},
			{data:"process"},
			{data:"code"}
			],
			select: {
				style: 'multi'
			}
		});
		example
		.on('dblclick', 'tr', function ( e, dt, type, indexes) {
			var dataDb = example.rows( this ).data().toArray();
			let model_code = dataDb[0]['model_code']
			let process = dataDb[0]['process']
			$.post('view/viewDetailBom',  
	            {model_code:model_code,process:process},
	            function(data){
	            $("#modal-content").html(data);
	            $('#exampleModal').modal('show');
	        }); 
		});
	}
	tableFinal(resFinal);



	resLct = <?php echo $resLct; ?>;
	arrLct = [];
	function tableLct(datax){
		let example = $('#lctTable').DataTable({
			"lengthMenu": [[10, -1], [10, "All"]],
			"order": [[ 0, "desc" ]],
			"scrollY":        "200px",
			
	        "scrollCollapse": true,
	        "paging":         false,
			dom: 'Bfrtip',
			buttons: [
			'excel',
			'selectNone',
				,
           	,
           	{
                text: ' <i class="fas fa-plus i-right" style="color:red;"></i>Add',
                className: 'btnPractice',
                action: function ( e, dt, node, config ) {
				    $.post('view/addLct',  
		                {},
		                function(data){
		                $("#modal-content").html(data);
		                $('#exampleModal').modal('show');
		            }); 

           		}
           	},
           	{
                text: ' <i class="fas fa-trash i-right" style="color:red;"></i>Delete',
                className: 'btnPractice',
                action: function ( e, dt, node, config ) {
                	quest('Are you sure "Delete This Lct"? !').then((result) => {
			        	if (result.isConfirmed) {
						    $.post('view/deleteLct',  
				                {arrLct:arrLct},
				                function(data){
				                $("#modal-content").html(data);
				                $('#exampleModal').modal('show');
				            }); 
						}
					}); 
           		}
           	},
           	
			],
			data: datax,
			columns:[
			{data:"id"},
			{data:"lct"},
			{data:"err_name"}
			],
			select: {
				style: 'multi'
			}
		});
		example
		.on( 'select', function ( e, dt, type, indexes ) {
			var rowData = example.rows( indexes ).data().toArray();
			for (var i = 0; i < rowData.length; i++) {
				var x = arrLct.indexOf(rowData[i]['id']);
				if (x === -1) //neu ko ton tai
					arrLct.unshift(rowData[i]['id']); //thi push 
                // console.log(arrDid)
			}
		} )
		.on( 'deselect', function ( e, dt, type, indexes ) {
			var rowDataUn = example.rows( indexes ).data().toArray();
			for (var i = 0; i < rowDataUn.length; i++) {
				var x = arrLct.indexOf(rowDataUn[i]['id']);
				arrLct.splice(x, 1);
			}
		});
	}
	tableLct(resLct);
})
</script>