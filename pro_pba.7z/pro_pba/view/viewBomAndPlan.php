<?php

date_default_timezone_set("Asia/Ho_Chi_Minh");
$dateNow = date('Y-m-d h:i:s', time());

require('../controller/controller.php');
$data = new cEms();

$line = isset($_POST['line_filter']) ? $_POST['line_filter'] : "";
$type = isset($_POST['type_filter']) ? $_POST['type_filter'] : "";

$resLack = $data->cGetLack($line, $type);
$arrLack = json_encode($resLack);

$resBom = $data->cGetBom_DucDat();
$arrBom = json_encode($resBom);

// print_r($resLack);
?>

<div class="col-md-12">
	<table class="table table-hover table-bordered table-sm dataTable no-footer" id="compareTable">
		<thead style="background-color: #588cc5; color: white;line-height: 15px;" class="text-center">
			<tr>
				<th>Model</th>
				<th>Code HM</th>
				<th>Type</th>
				<th>Code</th>
				<th>Point</th>
				<th>Line</th>
				<th>Name Error</th>
				<th>Stime</th>
			</tr>
		</thead>
		<tbody id="finalList">
		</tbody>
	</table>
</div>

<script>
	$(document).ready(function() {

		var arrLack = <?php echo $arrLack; ?>;
		var arrBom = <?php echo $arrBom; ?>;
		// console.log(arrLack);
		// console.log(arrBom);
		
		for (x in arrLack) {
			var code_hm = arrLack[x]['code_hm'];

			// console.log(code_hm);

			var checkModel = arrBom.find(e => {
				return e.code_hm == code_hm;
			});

			if (checkModel != null) {
				arrLack[x]['model_a'] = checkModel['models']
			} else {
				arrLack[x]['model_a'] = "---";
			}
		}

		tableCompare(arrLack);

	});

	function tableCompare(datax) {
		let example = $('#compareTable').DataTable({
			"lengthMenu": [
				[10, -1],
				[10, "All"]
			],
			"order": [
				[4, "desc"]
			],
			"scrollY": "200px",

			"scrollCollapse": true,
			"paging": false,
			dom: 'Bfrtip',
			buttons: [
				'excel',
				'selectNone',
			],
			data: datax,
			rowCallback: function(row, data, index) {
				$(row).addClass('redClass');
			},
			columns: [{
					data: "model_a"
				},

				{
					data: "code_hm"
				},

				{
					data: "type"
				},

				{
					data: "code"
				},

				{
					data: "point"
				},

				{
					data: "line"
				},

				{
					data: "name_err"
				},

				{
					data: "stime"
				}
			],
			select: {
				style: 'multi'
			}
		});
	}
</script>