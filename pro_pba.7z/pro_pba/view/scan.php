<?php
    require('../controller/controller.php');
    $data = new cEms();
    if (isset($_COOKIE['token'])) {

        $token = $_COOKIE['token'];
        $userInfo = $data->cGetUser($token);
        if (empty($userInfo)) {
          echo '<div class="panel-alert"><i class="fas fa-bell i-right"></i>Do not have access to this function. Please contact admin</div>';
          exit();
        }
    } else {
        echo '<div class="panel-alert"><i class="fas fa-bell i-right"></i>Do not have access to this function. Please contact admin</div>';
        exit();
    }
    $line = $_POST['line'];
    $type = $_POST['type'];
    // if ($type == 'IN') {
        $finalData = $data->cGetDataCheck();
        $doubleData = $data->cGetDataLine();
    // }
    //  else {
    //     $finalData = $data->cGetDataLine();
    // }
    
    $dataFinal = json_encode($finalData);
    $dataDouble = json_encode($doubleData);
?>
<h5 class="tit-table modal-title " style="width: 100%;"><i class="fa fa-flag i-right"></i><?php echo "Scan ".$type." Line : ".$line; ?></h5>
<div class="row">
    <div class="col-md-12" id="end" style="text-align: center;">
        
    <input type="text" id="qr_input" class="form-control" style="margin:auto;margin-top:10px;margin-bottom:10px;" placeholder="Scan DID In Here !">
    <button class="btn btn-success form-control" id="save" style="margin:auto;margin-top:10px;margin-bottom:10px;">
        <i class="fas fa-save"></i>
         Confirm
    </button>
    </div>
</div>   
    <table class="table table-hover table-bordered" id="data_in">
        <thead style="background-color:#01b1c1;color:white; font-size: 16px;font-weight: bold; ">
            <tr>
            	<td style="width: 5%;">Stt</td>
                <td>Did</td>
                <td>Code</td>
                <td>Qty</td>
                <td>Time</td>
                <td style="width: 25%;">Status</td>
                <td style="width: 5%;">Del</td>  
            </tr>
        </thead>
        <tbody id="dataEx">	
        </tbody>
    </table>
</div>
<script type="text/javascript">
    $(document).ready(function(){
        let author = '<?php echo $userInfo->manv; ?>';
        let dataFinal = <?php echo $dataFinal; ?>;
        let dataLine = <?php echo $dataDouble; ?>;
        let line = '<?php echo $line; ?>';
        let type = '<?php echo $type; ?>';
        let dataIn = []
        let dataDouble = []
        let checkExist
        let checkDouble
        $("#qr_input").focus();
        let i = 0;
        $("#qr_input").keyup(function(event){
            if(event.keyCode===13){
                let time = formatDate(new Date());
                let stt = '';
                let did = $("#qr_input").val().toUpperCase();
                if (type == 'IN') {
                    checkExist = dataFinal.find(e => e.Did == did)
                    checkDouble = dataLine.find(e => e.Did == did)
                } else {
                    checkExist = dataLine.find(e => e.Did == did && e.line == line)
                    checkDouble = dataFinal.find(e => e.Did == did)
                }
                
                let code = ''
                let qty = ''

                if (/[^0-9a-z\-\_\+$]/i.test(did) || did.length< 5) {
                    Stt = 'DID Wrong !';
                } else if(checkExist == null){
                    Stt = 'DID Not Exist !';
                } else if(checkDouble != null){
                    Stt = 'DID already Exist !';
                } else {
                    Stt = 'OK';
                    if (type=='IN'){
                        dataLine.push({"Did":did})
                    } else{
                        dataFinal.push({"Did":did})   
                    }
                        code = checkExist.SubCode
                        qty = checkExist.Qty
                        
                    
                     
                    dataIn.push({"did":did,"code":code,"qty":qty,"time":time});
                    i++
                }
                $('#dataEx').prepend('<tr><td>'+i+'</td><td>'+did+'</td><td>'+code+'</td><td>'+qty+'</td><td>'+time+'</td><td id = "st">'+Stt+'</td><td class = "text-center "><button class = "btn btn-outline-danger btn-sm">&times;</button></td></tr>');
                if (Stt != 'OK') {$("#st").css("color", "Red");}
                if (Stt == 'OK') {$("#st").css("color", "Green");}
                $("#qr_input").focus();
                $("#qr_input").val('');
            }
        });

        $('#dataEx').on('click', 'tr td button', function() {
            let qr_input = $(this).closest('tr').find('td:eq(1)').text();
            if($(this).closest('tr').find('td:eq(5)').text() == 'OK'){
                let indexOfIn = dataIn.findIndex(indexR => indexR.did == did);
                dataIn.splice(indexOfIn, 1)
                let indexOfDouble = dataDouble.findIndex(indexR => indexR.did == did);
                dataDouble.splice(indexOfDouble, 1)
                i = i-1;
            }
            $(this).closest('tr').remove();
        });

        $("#save").click(function(){
            quest('Are you sure SAVE!').then((result) => {
                if (result.isConfirmed) {
                    let data = document.getElementById('dataEx');
                    if (dataIn.length < 1) {
                        errAlert('Data Input Empty');
                    } else {
                        let result = [];
                        dataIn.reduce(function(res, value) {
                          if (!res[value.code]) {
                            res[value.code] = { code: value.code, qty: 0 };
                            result.push(res[value.code])
                          }
                          res[value.code].qty += value.qty;
                          return res;
                        }, {});
                        processing1()
                        // $("#save").remove()
                        // $("#qr_input").remove()
                        $.post('save.php', 
                            {dataIn:dataIn,type:type,line:line,author:author,result:result},
                            function(data){
                                console.log(result)
                                $("#end").html(data);
                        });
                    }
                }
            })
        });
    })
</script>