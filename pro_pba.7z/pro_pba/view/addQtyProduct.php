<?php
	require('../controller/controller.php');
	$data = new cEms();
	$check = $data->cCheckToken();
    if ($check['status'] === false) {
        echo $check['data'];
    } else {
        $author  = $check['data']->manv;
        $direct = $_POST['direct'];
		$dTime = $_POST['dTime'];
		$mc = $_POST['mc'];
		$shift = $_POST['shift'];
		$model = $_POST['model'];
		$qty = $_POST['qty'];
		$data->cAddQtyProductionbyModel($direct,$dTime,$mc,$shift,$model,$qty,$author);
		echo "Success";
	}
	
?>