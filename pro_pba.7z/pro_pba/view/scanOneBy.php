<?php
    require('../controller/controller.php');
    $data = new cEms();
    if (isset($_COOKIE['token'])) {

        $token = $_COOKIE['token'];
        $userInfo = $data->cGetUser($token);
        if (empty($userInfo)) {
          echo '<div class="panel-alert"><i class="fas fa-bell i-right"></i>Do not have access to this function. Please contact admin</div>';
          exit();
        }
    } else {
        echo '<div class="panel-alert"><i class="fas fa-bell i-right"></i>Do not have access to this function. Please contact admin</div>';
        exit();
    }

    $process_in = $_POST['process_in'];
    $model = $_POST['model'];
    $type = $_POST['type'];
    if (in_array( $process_in ,['REPAIR','QC', 'MM', 'OUT'] )) {
        $lct = $process_in;
        $sub_lct = $process_in;
    } else {
        $lct = 'LINE';
        $sub_lct = $process_in;
    }

    $finalData = $data->cGetDataCheck();
    $dataFinal = json_encode($finalData);
?>
<h5 class="tit-table modal-title " style="width: 100%;"><i class="fa fa-flag i-right"></i><?php echo "Scan to ".$process_in; ?></h5>
<div class="row">
    <div class="col-md-8" style="text-align: center;">
        
               <input type="text" id="qr_input" class="form-control" style="margin:auto;margin-top:10px;margin-bottom:10px;" placeholder="Scan QR In Here !">
    </div>
    <div class="col-md-4">
        <?php 
        if ($lct == 'REPAIR') {
            ?>
               <input type="text" id="err_name" class="form-control" style="margin-top:10px" placeholder="ERROR NAME" list="err_list">
               <datalist id="err_list">
                      <option value="IQC">IQC</option>
                    <option value="LOANG, BAN GATE MOLDING">LOANG, BAN GATE MOLDING</option>
                    <option value="TRAN KEO CIC">TRAN KEO CIC</option>
                    <option value="NHAN CIC">NHAN CIC</option>
                    <option value="FPCB DAM LEAK (TREN)">FPCB DAM LEAK (TREN)</option>
                    <option value="FPCB DAM LEAK (DUOI)">FPCB DAM LEAK (DUOI)</option>
                    <option value="BUI MOLDING">BUI MOLDING</option>
                    <option value="DV MOLDING">DV MOLDING</option>
                    <option value="THIEU GATE">THIEU GATE</option>
                    <option value="NHAN MOLDING">NHAN MOLDING</option>
                    <option value="BONG KHI MOLDING">BONG KHI MOLDING</option>
                    <option value="LVDT">LVDT</option>
                    <option value="TRAN KEO MOLDING (TREN)">TRAN KEO MOLDING (TREN)</option>
                    <option value="TRAN KEO MOLDING (DUOI)">TRAN KEO MOLDING (DUOI)</option>
                    <option value="THIEU KEO MOLDING">THIEU KEO MOLDING</option>
                    <option value="BIEN DANG MOLDING">BIEN DANG MOLDING</option>
                    <option value="LOM BONDING">LOM BONDING</option>
                    <option value="NHAN TAPE FPCB">NHAN TAPE FPCB</option>
                    <option value="GATE DAM LEAK">GATE DAM LEAK</option>
                    <option value="DAM BONDING">DAM BONDING</option>
                    <option value="GATE BURR">GATE BURR</option>
                    <option value="RISK OCTA">RISK OCTA</option>
                    <option value="GREEN BLOCK DOT">GREEN BLOCK DOT</option>
                    <option value="BIT UB">BIT UB</option>
                    <option value="MUNG UB">UNG UB</option>
                    <option value="KHONG LEN NGUON">KHONG LEN NGUON</option>
                    <option value="NG FINGER">NG FINGER</option>
                    <option value="FODORMALS CAB">FODORMALS CAB</option>
                    <option value="CHAM ĐEN OCTA">CHAM ĐEN OCTA</option>
                    <option value="LOANG OCTA">OANG OCTA</option>
                    <option value="NG BARCODE">NG BARCODE</option>
                    <option value="ME OCTA">ME OCTA</option>
                    <option value="VO OCTA">VO OCTA</option>
                    <option value="XUOC OCTA">XUOC OCTA</option>
                    <option value="CRACK FPCB">CRACK FPCB</option>
                    <option value="HAN CUSHEET">HAN CUSHEET</option>
                    <option value="CRACK CIC">CRACK CIC</option>
                    <option value="DAM CUSHEET">DAM CUSHEET</option>
                    <option value="TSP">TSP</option>
                    <option value="DAM OVER">DAM OVER</option>

              </datalist>
            <?php
        }
     ?>
     </div>
 </div>
<div class="col-md-12" style="text-align: center;">
    
    <div id="end"></div>
</div>
<script type="text/javascript">
    $(document).ready(function(){
        let author = '<?php echo $userInfo->manv; ?>';
        let lct = '<?php echo $lct; ?>';
        let sub_lct = '<?php echo $sub_lct; ?>';
        let model = '<?php echo $model; ?>';
        let type = '<?php echo $type; ?>';
        let err_name=''

        
        $("#qr_input").focus();
        $("#qr_input").keyup(function(event){
            if(event.keyCode===13){
                let qr_input = $("#qr_input").val().toUpperCase();
                if(lct == 'REPAIR'){
                    err_name = $("#err_name").val().toUpperCase();
                    console.log("222"+err_name)
                }
                $.post('saveOneBy.php', 
                    {qr_input:qr_input,type:type,lct:lct,sub_lct:sub_lct,model:model,author:author,err_name:err_name},
                    function(data){
                        $("#end").html(data);
                        $("#qr_input").val('');
                        $("#qr_input").focus();

                });
            }
        });
    })
</script>