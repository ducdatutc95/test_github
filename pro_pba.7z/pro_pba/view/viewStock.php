<?php
require('../controller/controller.php');
date_default_timezone_set("Asia/Ho_Chi_Minh");
$dateNow = date('Y-m-d h:i:s', time());
$data = new cEms();
$qr = $_POST['qr'];
$line_filter = $_POST['line_filter'];
$model_filter = $_POST['model_filter'];
$diffTime = $_POST['diffTime'];
$limit = $_POST['limit'];
$finalData = $data->cGetStock($qr, $line_filter, $model_filter, $diffTime, $limit);
// $inventData = $data->cGetInvent($line_filter,$limit);
$resFinal = json_encode($finalData);
// $resInvent = json_encode($inventData);
?>
<div class="col-md-12">
	<table class="table table-hover table-bordered table-sm dataTable no-footer" id="finalTable">
		<thead style="background-color: #588cc5; color: white;line-height: 15px;" class="text-center">
			<tr>
				<th>Did</th>
				<th>Code</th>
				<th>Qty</th>
				<th>Line</th>
				<th>Time In</th>
				<th>Author</th>
			</tr>

		</thead>
		<tbody id="finalList">

		</tbody>
	</table>
</div>
<!-- <div class="col-md-6">
    <table class="table table-hover table-bordered table-sm dataTable no-footer" id = "inventTable">
        <thead style="background-color: #588cc5; color: white;line-height: 15px;" class="text-center">
            <tr>
                <th >ID</th>
                <th >Line</th>
                <th >Time</th>
                <th >Author</th>
                <th >Status</th>
            </tr>
            
        </thead>
        <tbody id="inventList">
            
        </tbody>
    </table>
</div> -->
<script>
	$(document).ready(function() {
		arrDid = []
		resFinal = <?php echo $resFinal; ?>;

		function tableFinal(datax) {
			let example = $('#finalTable').DataTable({
				"lengthMenu": [
					[10, -1],
					[10, "All"]
				],
				"order": [
					[4, "desc"]
				],
				"scrollY": "200px",

				"scrollCollapse": true,
				"paging": false,
				dom: 'Bfrtip',
				buttons: [
					'excel',
					'selectNone',
					{
						text: ' <i class="fas fa-exchange-alt i-right" style="color:red;"></i>Scan QR',
						className: 'btnPractice',
						action: function(e, dt, node, config) {
							window.open("view/pickPro.php", "_blank", "scrollbars=yes,resizable=yes,top=0");

						}
					},

					{
						text: ' <i class="fas fa-divide i-right" style="color:blue;"></i>Chia Cắt Liệu',
						className: 'btnPractice',
						action: function(e, dt, node, config) {
							window.open("view/divideCutLine.php", "_blank", "scrollbars=yes,resizable=yes,top=0");

						}
					},

					//    	{
					//         text: ' <i class="fas fa-check i-right" style="color:red;"></i>Confirm IN',
					//         className: 'btnPractice',
					//         action: function ( e, dt, node, config ) {
					// window.open("view/pickConfirm.php", "_blank", "scrollbars=yes,resizable=yes,top=0");

					//    		}
					//    	},
					//    	{
					//         text: ' <i class="fas fa-list i-right" style="color:red;"></i>Check QR',
					//         className: 'btnPractice',
					//         action: function ( e, dt, node, config ) {
					// window.open("view/checkQr.php", "_blank", "scrollbars=yes,resizable=yes,top=0");

					//    		}
					//    	},
					//    	{
					//         text: ' <i class="fas fa-edit i-right" style="color:red;"></i>Change Octa QR',
					//         className: 'btnPractice',
					//         action: function ( e, dt, node, config ) {
					// window.open("view/changeqr.php", "_blank", "scrollbars=yes,resizable=yes,top=0");

					//    		}
					//    	}
				],
				data: datax,
				rowCallback: function(row, data, index) {
					let sDate = new Date(data["lTime"]);
					let dateNow = new Date();
					let numberTime = dateNow.getTime() - sDate.getTime();
					let 里 = numberTime - 1000 * 3600 * 48
					if (里 > 0) {
						$(row).addClass('heClass');
						// $(row).hide();
					}
				},
				columns: [

					{
						data: "did"
					},
					{
						"data": function(row, type, set) {
							let qr = row['code'];
							return qr.slice(0, 12);
						}
					},
					{
						data: "qty"
					},
					{
						data: "line"
					},
					{
						data: "sTime"
					},
					{
						data: "author"
					}
				],
				select: {
					style: 'multi'
				}
			});
		}
		tableFinal(resFinal);

		function tableInvent(datax) {
			let example = $('#inventTable').DataTable({
				"lengthMenu": [
					[10, -1],
					[10, "All"]
				],
				"order": [
					[2, "desc"]
				],
				"scrollY": "200px",

				"scrollCollapse": true,
				"paging": false,
				dom: 'Bfrtip',
				buttons: [
					'excel',
					'selectNone',
					{
						text: ' <i class="fa fa-cubes i-right" style="color:red;"></i>Inventory',
						className: 'btnPractice',
						action: function(e, dt, node, config) {
							window.open("view/materialCheck.php", "_blank", "scrollbars=yes,resizable=yes,top=0");

						}
					}, {
						text: ' <i class="fas fa-check i-right" style="color:#0089ff;"></i>Approval',
						className: 'btnPractice',
						action: function(e, dt, node, config) {
							if (arrDid.length != 1) {
								errAlert("Please! Select only 1 row");
							} else {
								quest('Are you sure "Approval data"? !').then((result) => {
									if (result.isConfirmed) {
										$.post('view/approval.php', {
												id: arrDid[0]
											},
											function(data) {
												successAlert(data);
												loadStock()
											});
									}
								})
							}
						}
					}, {
						text: ' <i class="fas fa-eye i-right" style="color:red;"></i>View',
						className: 'btnPractice',
						action: function(e, dt, node, config) {
							if (arrDid.length != 1) {
								alert("Please! Select only 1 row");
							} else {
								$.post('view/viewCheckMaterialDetail.php', {
										id: arrDid[0]
									},
									function(data) {
										$("#modal-content").html(data);
										$('#exampleModal').modal('show');
									});
							}
						}
					},
				],
				data: datax,
				columns: [{
						data: "id"
					},
					{
						data: "line"
					},
					{
						data: "sTime"
					},
					{
						data: "author"
					},
					{
						"data": function(row, type, set) {
							let st = row['status'];
							if (st == 1) {
								return "Đã Duyệt";
							} else {
								return "Chưa Duyệt";
							}
						}
					}
				],
				select: {
					style: 'multi'
				}

			});
			example
				.on('select', function(e, dt, type, indexes) {
					var rowData = example.rows(indexes).data().toArray();
					for (var i = 0; i < rowData.length; i++) {
						var x = arrDid.indexOf(rowData[i]['id']);
						if (x === -1) //neu ko ton tai
							arrDid.unshift(rowData[i]['id']); //thi push 
						// console.log(arrDid)
					}
				})
				.on('deselect', function(e, dt, type, indexes) {
					var rowDataUn = example.rows(indexes).data().toArray();
					for (var i = 0; i < rowDataUn.length; i++) {
						var x = arrDid.indexOf(rowDataUn[i]['id']);
						arrDid.splice(x, 1);
					}
				});
		}
		// tableInvent(resInvent);
	})
</script>