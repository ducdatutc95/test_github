<?php
require('../controller/controller.php');
$data = new cEms();
if (isset($_COOKIE['token'])) {

    $token = $_COOKIE['token'];
    $userInfo = $data->cGetUser($token);
    if (empty($userInfo)) {
        echo '<div class="panel-alert"><i class="fas fa-bell i-right"></i>Do not have access to this function. Please contact admin</div>';
        exit();
    }
} else {
    echo '<div class="panel-alert"><i class="fas fa-bell i-right"></i>Do not have access to this function. Please contact admin</div>';
    exit();
}

$did = $_POST['did'];

$resDidCut = $data->cGetDidDivideCut($did);
$root_id = $resDidCut[0]->id;
$root_did = $resDidCut[0]->did;
$root_code = $resDidCut[0]->code;
$root_qty = $resDidCut[0]->qty;
$root_line = $resDidCut[0]->line;
$root_status = $resDidCut[0]->status;

$arrRoot = json_encode($resDidCut);

// print_r($resDidCut);

$resStock = $data->cGetDataCheck();
// print_r($resStockMM);
$arrStock = array();
foreach ($resStock as $key) {
    $arrStock[] = $key->Did;
}

$resLine = $data->cGetDataLine();
// print_r($resLine);
$arrInLine = array();
foreach ($resLine as $key) {
    $arrInLine[] = $key->Did;
}
?>

<div class="row">
    <div class="col-md-4">
        <input type="text" class="form-control" style="margin:auto;margin-bottom:4px;" placeholder="Thông Tin Did" value="Did : <?php echo $root_did; ?>" readonly>
    </div>

    <div class="col-md-4">
        <input type="text" class="form-control" style="margin:auto;margin-bottom:4px;" placeholder="Thông Tin Code" value="Code : <?php echo $root_code; ?>" readonly>
    </div>

    <div class="col-md-4">
        <input type="text" class="form-control" style="margin:auto;margin-bottom:4px;" placeholder="Thông Tin Qty" value="Qty : <?php echo $root_qty; ?>" readonly>
    </div>

    <div class="col-md-4">
        <input type="text" class="form-control" style="margin:auto;margin-bottom:4px;" placeholder="Thông Tin Line" value="Line : <?php echo $root_line; ?>" readonly>
    </div>

    <div class="col-md-4">
        <input type="text" class="form-control" style="margin:auto;margin-bottom:4px;" placeholder="Thông Tin Status" value="Status : <?php echo $root_status; ?>" readonly>
    </div>
</div>


<h5 class="tit-table modal-title " style="width: 100%;"><i class="fa fa-flag i-right"></i><?php echo "Scan " . "Chia Cắt Liệu : Cuộn mới" ?></h5>
<div class="row">
    <div class="col-md-12" id="end" style="text-align: center;">

        <input type="text" id="code" class="form-control" style="margin:auto;margin-top:10px;margin-bottom:10px;" placeholder="Scan Code In Here !">

        <input type="text" id="did" class="form-control" style="margin:auto;margin-top:10px;margin-bottom:10px;" placeholder="Scan Did Mới In Here !">

        <button class="btn btn-success form-control" id="save" style="margin:auto;margin-top:10px;margin-bottom:10px;">
            <i class="fas fa-save"></i>
            Confirm
        </button>
    </div>
</div>

<table class="table table-hover table-bordered" id="data_in">
    <thead style="background-color:#01b1c1;color:white; font-size: 16px;font-weight: bold; ">
        <tr>
            <td style="width: 5%;">Stt</td>
            <td>Did</td>
            <td>Code</td>
            <td>Qty</td>
            <td style="width: 25%;">Status</td>
            <td style="width: 5%;">Del</td>
        </tr>
    </thead>
    <tbody id="dataEx">
    </tbody>
</table>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        var im = [];
        var objIm = [];
        let i = 0;

        let arrStock = [<?php echo '"' . implode('","', $arrStock) . '"'; ?>];
        let arrInLine = [<?php echo '"' . implode('","', $arrInLine) . '"'; ?>];

        let arrRoot = <?php echo $arrRoot; ?>;

        let author = '<?php echo $userInfo->manv; ?>';

        let root_id = '<?php echo $root_id ?>';
        let root_did = '<?php echo $root_did ?>';
        let root_code = '<?php echo $root_code ?>';

        let root_qty = '<?php echo $root_qty ?>';
        let root_line = '<?php echo $root_line ?>';
        let root_status = '<?php echo $root_status ?>';

        im.push(root_did);
        // console.log(im);

        let checkExistLine;
        let checkExistStock;

        $("#code").focus();
        $("#code").keyup(function(event) {
            if (event.keyCode === 13) {
                let qty = prompt("Hãy nhập qty", "");
                let sum_cut = calc_sum_qty(objIm);

                console.log(sum_cut + '---' + qty + '---' + root_qty);

                if ((parseInt(qty) + parseInt(sum_cut)) >= parseInt(root_qty)) {
                    alert('Tổng qty mới >= qty cũ. Không thể thực hiện !');
                } else if (parseInt(qty) > 0) {
                    let tempCode = $("#code").val().toUpperCase().trim();
                    $('#code').val(tempCode + 'xxxxxx00000' + qty);
                    $('#did').focus();
                } else {
                    alert('Lỗi số lượng !');
                }
            }
        });

        $("#did").keyup(function(event) {
            if (event.keyCode === 13) {
                var did = $("#did").val().toUpperCase().trim();

                var code = $("#code").val().toUpperCase().trim();
                var subCode = code.substr(0, 12);
                var qty = code.substr(-6, 6);
                qty = parseInt(qty);
                var checkStock = arrStock.indexOf(did);
                var checkInLine = arrInLine.indexOf(did);
                var a = im.indexOf(did);

                var Stt = '';
                if (/[^0-9a-z\-\_\+$]/i.test(did) || /[^0-9a-z\-\_\+$]/i.test(code)) {
                    Stt = 'Sai Ký tự';
                } else if (code.length < 15) {
                    Stt = 'Lỗi Code ( Chiều dài nhỏ hơn 15 ) !';
                } else if (did.length < 7 || did.length > 25) {
                    Stt = 'Lỗi Did !';
                } else if (checkStock != -1) {
                    Stt = 'Đã Tồn Tại Trong Stock !';
                } else if (checkInLine != -1) {
                    Stt = 'Đã Tồn Tại Ở Line !';
                } else if (a != -1) {
                    Stt = 'Lỗi Trùng !';
                } else if (subCode != root_code) {
                    Stt = 'Lỗi Code ( Khác Nhau Bản Chất) !';
                } else {
                    objIm.push({
                        "did": did,
                        "code": code,
                        "subCode": subCode,
                        "qty": qty
                    });
                    im.push(did);
                    Stt = 'OK';
                    i = i + 1;

                    // console.log(im);
                }

                $('#dataEx').prepend('<tr><td>' + i + '</td><td>' + did + '</td><td>' + code + '</td><td>' + qty + '</td><td id = "st">' + Stt + '</td><td><button style="border:1px solid red; background-color: white; min-width: 30px;">x</button></td></tr>');

                if (Stt != 'OK') {
                    $("#st").css("color", "Red");
                }

                $("#code").focus();
                $("#code").val('');
                $("#did").val('');
            }
        });

        $('#dataEx').on('click', 'tr td button', function() {
            let did_del = $(this).closest('tr').find('td:eq(1)').text();

            if ($(this).closest('tr').find('td:eq(4)').text() == 'OK') {

                let indexOfObjIm = objIm.findIndex(indexR => indexR.did == did_del);
                if (indexOfObjIm > -1) {
                    objIm.splice(indexOfObjIm, 1);
                }

                let indexOfIm = im.findIndex((e) => e == did_del);
                if (indexOfIm > -1) {
                    im.splice(indexOfIm, 1);
                }

                i = i - 1;
            }

            $(this).closest('tr').remove();
        });

        $("#save").click(function() {

            let sum_qty_cut = calc_sum_qty(objIm);

            quest('Are you sure SAVE!').then((result) => {
                if (result.isConfirmed) {
                    if (objIm.length < 1) {
                        errAlert('Data Input Empty');
                    } else {
                        processing1()

                        $("#save").remove()

                        $.post('divideCutLineDetailing.php', {
                                objIm: objIm,
                                objRoot: arrRoot,
                                sum_qty_cut: sum_qty_cut,
                                author: author
                            },
                            function(data) {
                                console.log(data);
                                $("#end").html(data);
                            });
                    }
                }
            })
        });

        function calc_sum_qty(obj) {
            let sum = 0;
            for (let i = 0; i < obj.length; i++) {
                sum += parseInt(obj[i].qty);
            }

            return sum;
        }
    })
</script>