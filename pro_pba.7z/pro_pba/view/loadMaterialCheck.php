<?php
	require('../controller/controller.php');
	date_default_timezone_set("Asia/Ho_Chi_Minh");
	$data = new cEms();
	$line = $_POST['line'];
	$note = $_POST['note'];
	$author = $_POST['author'];
	$totalData = $data->cGetTotalLine($line);
	$resTotal = json_encode($totalData);
?>
	<h5 style="color:red;"><?php echo "Inventory: Line ". $line;?> </h5>
    <table class="table table-hover table-bordered table-sm dataTable no-footer" id = "stockTable">
        <thead style="background-color: #588cc5; color: white;line-height: 15px;" class="text-center">
            <tr>
            	<th >No </th>
            	<th >Code </th>
                <th >Tồn</th>
                <th >Thực Tế</th>
            </tr>
            
        </thead>
        <tbody id="stockList">
            
        </tbody>
    </table>
<script>
	$(document).ready(function(){
		resTotal = <?php echo $resTotal; ?>;
		let html =''
		for (let i = 0; i < resTotal.length; i++) {
			let code = resTotal[i].code
			let qty = resTotal[i].qty
			let k = i+1
			html += '<tr>'
			html += '<td>'+k+'</td><td>'+code+'</td><td>'+qty+'</td><td><input class="inputs" type="text" style="border: none; width: 100%; color: red; text-align: center;" tabindex="'+i+'" value = "'+qty+'"></td>'
			html += '</tr>'
		}
		$('#stockList').html(html)
		$('.inputs').keydown(function(e){
	        if (e.which === 13) {
	            var index = $('.inputs').index(this) + 1;
	            $('.inputs').eq(index).focus();
	            $('.inputs').eq(index).select();
	        }
		});

		$('#submit').click(function(){
	        let qty_in = $("#stockList input[type=text");

	        let line = '<?php echo $line; ?>';
	        let note = '<?php echo $note; ?>';
	        let author = '<?php echo $author; ?>';
	        let check = 0;
	        let tit = ' Dòng : ';
	        let errContent = '';

	        for (let i = 0; i < resTotal.length; i++) {
	            let qty_in_val = parseFloat($(qty_in[i]).val());
                if(/[^0-9\.\-]/i.test($(qty_in[i]).val()) || qty_in_val < 0){
                    check ++;
                    tit += ','+(i+1);
                    errContent = "Sai ký tự vui lòng kiểm tra lại "
                } else {
                	if ($(qty_in[i]).val() == '') {
                		resTotal[i].real_qty = 0
					} else {
						 resTotal[i].real_qty = qty_in_val
					}
                }
	        }
	        if (check >0) {
	            errAlert(errContent+tit);
	        } else{
	            quest('Are you sure "Save data"? !').then((result) => {
	                if (result.isConfirmed) {
	                    processing2()
	                    $("#submit").remove();
	                    $.post('materialChecking.php', {
	                        resTotal:resTotal, line:line,note:note,author:author
	                    },function(data){
	                        successAlert(data);
	                    });
	                }
	            })
	        }
	    })
	})
</script>