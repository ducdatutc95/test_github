<?php
require('../controller/controller.php');
$data = new cEms();
     if (isset($_COOKIE['token'])) {

        $token = $_COOKIE['token'];
        $userInfo = $data->cGetUser($token);
        if (empty($userInfo)) {
          echo '<div class="panel-alert"><i class="fas fa-bell i-right"></i>Do not have access to this function. Please contact admin</div>';
          exit();
        }
    } else {
        echo '<div class="panel-alert"><i class="fas fa-bell i-right"></i>Do not have access to this function. Please contact admin</div>';
        exit();
    }
    $id_plan = $_POST['id_plan'];
    $dataDetail = $data->cGetMaterialByPlan($id_plan);
    $countImByPlan = $data->cGetCountImByPlan($id_plan);
    $direct = $dataDetail[0]->direct;
    $model_code = $dataDetail[0]->model_code;
    $i = 1;
?>
<div class="modal-header">
	<h5 class="modal-title card-title" style="color: #01b1c1;">View Material By Plan</h5>
	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</button>
</div>
<div class="modal-body">
    <div class="row" id = "form_pick">	
        <div class="col-md-12 showEditInfo">
            <table class="table table-hover table-bordered table-sm dataTable no-footer" id = "export">
            	<thead style="background-color: #588cc5; color: white;line-height: 15px;" class="text-center">
                <tr> 
                    <td>No.</td>
                    <td>Model</td>
                    <td>Code</td>
                    <td>Qty Plan</td>
                    <td>Qty Recived(<?php echo $countImByPlan."Lần"; ?>)</td>
                    <td>Pending</td>
                </tr>
            </thead>
            <tbody>
                <?php

                    foreach ($dataDetail as $key) {
                       ?>
                       <tr>
                            <td><?php echo $i++;?></td>    
                            <td><?php echo $key->model_code;?></td>
                            <td id="code"><?php echo $key->code;?></td>
                            <td id="qty_code"><?php echo $key->qty_code;?></td>  
                            <td id="qty_recive"><?php if($key->qty_in>0){echo $key->qty_in;} else {echo 0;}?></td>  
                            <td><?php if ($key->qty_in-$key->qty_code==0) {
                            	echo "<b style='color:green'>OK</b>";
                            } else {
                                echo "<span style='color:red'>".($key->qty_in-$key->qty_code)."</span>";
                            } ?></td> 
                       </tr>
                       <?php
                    }
                ?>
            </tbody>
        </table>
        </div>
	</div>
</div>
<script type="text/javascript">
    $(document).ready(function(){
        let example = $('#export').DataTable({
                "lengthMenu": [[10, -1], [10, "All"]],
                "order": [[ 1, "desc" ]],
                "scrollY":        "200px",
                
                "scrollCollapse": true,
                "paging":         false,
                dom: 'Bfrtip',
                buttons: [
                'excel',
                'selectNone',
                ]
            })
    })
</script>

