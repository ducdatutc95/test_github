<?php

date_default_timezone_set("Asia/Ho_Chi_Minh");
$stime = date("Y-m-d H:i:s");

require('../controller/controller.php');
$data = new cEms();

$idOld = $_POST['idOld'];
$idNew = $_POST['idNew'];
$lineCurrent = $_POST['lineCurrent'];

$resOld = $data->cGetPlanDetailFromMes($idOld);
$resNew = $data->cGetPlanDetailFromMes($idNew);
$fujiData = $data->cGetDataFuji($lineCurrent);

// print_r($resOld);
// print_r($resNew);

$arrOld = json_encode($resOld);
$arrNew = json_encode($resNew);
$arrFuji = json_encode($fujiData);
?>

<div class="col-md-12 mb-3 mt-3 dd_line_time">
    <h3 style="color: blue;">Change Model: (Line <?php echo $lineCurrent; ?>)</h3>
    <h5 style="color: green;"><?php echo $stime; ?></h5>
</div>

<div class="col-md-12 mb-3" id="dd_box_same">
    <table class="table table-hover table-bordered table-sm" style="width: 100%;">
        <thead class="text-center">
            <tr>
                <th>PLAN MES</th>
                <th><?php echo $resOld[0]->model; ?></th>
                <th><?php echo $resNew[0]->model; ?></th>
            </tr>
        </thead>

        <tbody>
            <tr>
                <td class="theah">Model </td>
                <td><?php echo $resOld[0]->basic; ?></td>
                <td><?php echo $resNew[0]->basic; ?></td>
            </tr>
            <tr>
                <td class="theah">Line </td>
                <td><?php echo $resOld[0]->line; ?></td>
                <td><?php echo $resNew[0]->line; ?></td>
            </tr>
            <tr>
                <td class="theah">Date </td>
                <td><?php echo $resOld[0]->sDate; ?></td>
                <td><?php echo $resNew[0]->sDate; ?></td>
            </tr>
            <tr>
                <td class="theah">Shift </td>
                <td><?php echo $resOld[0]->shift; ?></td>
                <td><?php echo $resNew[0]->shift; ?></td>
            </tr>
        </tbody>
    </table>
</div>


<div class="col-md-12 mb-3" id="dd_option_printer">
    <div class="dd_option_printer_content">

        <label for="print_same" id="print_same_label">Print Giống Nhau</label>

        <label for="print_just_old" id="print_just_old_label">Print <?php echo $resOld[0]->basic; ?></label>

        <label for="print_just_new" id="print_just_new_label">Print <?php echo $resNew[0]->basic; ?></label>

        <button class="btn btn-primary" onclick="window.print()">
            <i class="fas fa-save"></i> Print
        </button>

    </div>
</div>


<input type="checkbox" id="print_same">
<div class="col-sm-4 col-md-4 col-lg-4 mb-3" id="box_same">
    <table class="table table-hover table-bordered table-sm " id="sameTable" style="width: 100%;">
        <thead class="text-center sameTable">
            <tr>
                <th colspan="3"><i class="fas fa-info-circle i-right"></i> Code giống nhau <i id="rateSame"></i></th>
            </tr>
            <tr>
                <th>Location</th>
                <th>Code</th>
                <th>Point</th>
            </tr>
        </thead>
        <tbody id="sameList">

        </tbody>
    </table>

</div>

<input type="checkbox" id="print_just_old">
<div class="col-sm-4 col-md-4 col-lg-4 mb-3" id="box_old">
    <table class="table table-hover table-bordered table-sm " id="oldTable" style="width: 100%;">
        <thead class="text-center aTable">
            <tr>
                <th colspan="3"><i class="fas fa-info-circle i-right"></i> <?php echo "Code chỉ có ở " . $resOld[0]->basic; ?><i id="rateOnlyA"></i></th>

            </tr>
            <tr>
                <th>Location</th>
                <th>Code</th>
                <th>Point</th>

            </tr>
        </thead>
        <tbody id="aList">

        </tbody>
    </table>
</div>

<input type="checkbox" id="print_just_new">
<div class="col-sm-4 col-md-4 col-lg-4 mb-3" id="box_new">
    <table class="table table-hover table-bordered table-sm " id="newTable" style="width: 100%;">
        <thead class="text-center bTable">
            <tr>
                <th colspan="3"><i class="fas fa-info-circle i-right"></i> <?php echo "Code chỉ có ở " . $resNew[0]->basic; ?><i id="rateOnlyB"></i></th>

            </tr>
            <tr>
                <th>Location</th>
                <th>Code</th>
                <th>Point</th>

            </tr>
        </thead>
        <tbody id="bList">

        </tbody>
    </table>
</div>

<script>
    $(document).ready(function() {
        var arrOld = <?php echo $arrOld; ?>;
        var arrNew = <?php echo $arrNew; ?>;
        var arrFuji = <?php echo $arrFuji; ?>;
        
        // console.log(arrFuji);
        // console.log(arrOld);
        // console.log(arrNew);

        var arrSame = [];

        var isSame = (a, b) => a.code === b.code;
        var onlyInLeft = (left, right, compareFunction) =>
            left.filter(leftValue =>
                !right.some(rightValue =>
                    compareFunction(leftValue, rightValue)
                )
            );

        var onlyInOld = onlyInLeft(arrOld, arrNew, isSame);
        var onlyInNew = onlyInLeft(arrNew, arrOld, isSame);

        // console.log(onlyInOld);
        // console.log(onlyInNew);

        var arrLengBigger = [];
        var arrLengSmaller = [];

        if (arrNew.length > arrOld.length) {
            arrLengBigger = arrNew;
            arrLengSmaller = arrOld;
        } else {
            arrLengBigger = arrOld;
            arrLengSmaller = arrNew;
        }

        for (var i = 0; i < arrLengBigger.length; i++) {
            var code = arrLengBigger[i].code;

            var checkExist = arrLengSmaller.find(e => {
                return e.code == code;
            })

            var checkDouble = arrSame.find(e => {
                return e.code == code;
            })

            if (checkExist != null && checkDouble == null) {
                arrSame.push(checkExist);
            }
        }

        // Full column table
        for (var i = 0; i < arrSame.length; i++) {
            var code = arrSame[i].code;

            var checkExist = arrFuji.find(e => {
                return e.CODE == code;
            })

            // console.log(checkExist);

            if (checkExist != null) {
                arrSame[i]['lct'] = checkExist['MODULE'] + ' - ' + checkExist['SLOT'];
            } else {
                arrSame[i]['lct'] = '';
            }
        }

        for (var i = 0; i < onlyInOld.length; i++) {
            var code = onlyInOld[i].code;

            var checkExist = arrFuji.find(e => {
                return e.CODE == code;
            })

            // console.log(checkExist);

            if (checkExist != null) {
                onlyInOld[i]['lct'] = checkExist['MODULE'] + ' - ' + checkExist['SLOT'];
            } else {
                onlyInOld[i]['lct'] = '';
            }
        }

        for (var i = 0; i < onlyInNew.length; i++) {
            var code = onlyInNew[i].code;

            var checkExist = arrFuji.find(e => {
                return e.CODE == code;
            })

            // console.log(checkExist);

            if (checkExist != null) {
                onlyInNew[i]['lct'] = checkExist['MODULE'] + ' - ' + checkExist['SLOT'];
            } else {
                onlyInNew[i]['lct'] = '';
            }
        }

        sameTable(arrSame);
        onlyTableOld(onlyInOld);
        onlyTableNew(onlyInNew);
    });

    function sameTable(data) {
        let example = $('#sameTable').DataTable({
            // "lengthMenu": [
            //     [10, -1],
            //     [10, "All"]
            // ],
            // "order": [
            //     [0, "desc"]
            // ],
            // "scrollY": "100%",
            // // "scrollX":false,
            // "scrollCollapse": true,
            // "paging": false,
            "pageLength": -1, // This will display all rows
            dom: 'Bfrtip',
            buttons: [
                'selectAll',
                'selectNone',
                'copy'
            ],
            data: data,
            columns: [{
                    data: "lct"
                },

                {
                    data: "code"
                },

                {
                    data: "point"
                }
            ],
            select: {
                style: 'multi'
            }
        });
    }

    function onlyTableOld(data) {
        let example = $('#oldTable').DataTable({
            // "lengthMenu": [
            //     [10, -1],
            //     [10, "All"]
            // ],
            // "order": [
            //     [0, "desc"]
            // ],
            // "scrollY": "100%",
            // // "scrollX":false,
            // "scrollCollapse": true,
            // "paging": false,
            "pageLength": -1, // This will display all rows
            dom: 'Bfrtip',
            buttons: [
                'selectAll',
                'selectNone',
                'copy'
            ],
            data: data,
            columns: [{
                    data: "lct"
                },

                {
                    data: "code"
                },

                {
                    data: "point"
                }
            ],
            select: {
                style: 'multi'
            }
        });
    }

    function onlyTableNew(data) {
        let example = $('#newTable').DataTable({
            // "lengthMenu": [
            //     [10, -1],
            //     [10, "All"]
            // ],
            // "order": [
            //     [0, "desc"]
            // ],
            // "scrollY": "100%",
            // // "scrollX":false,
            // "scrollCollapse": true,
            // "paging": false,
            "pageLength": -1, // This will display all rows
            dom: 'Bfrtip',
            buttons: [
                'selectAll',
                'selectNone',
                'copy'
            ],
            data: data,
            columns: [{
                    data: "lct"
                },

                {
                    data: "code"
                },

                {
                    data: "point"
                }
            ],
            select: {
                style: 'multi'
            }
        });
    }
</script>