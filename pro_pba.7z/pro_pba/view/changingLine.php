<?php
    require('../controller/controller.php');
    date_default_timezone_set("Asia/Ho_Chi_Minh");
    $data = new cEms();
    $id = $_POST['id'];
    $line = $_POST['line']; 
    $res = $data->cChangeLine($id, $line);
    echo $res;
   
    
?>