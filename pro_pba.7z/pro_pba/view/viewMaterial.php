<?php
	require('../controller/controller.php');
	$data = new cEms();
	$line_filter = $_POST['line_filter'];
	$model_filter = $_POST['model_filter'];
	$dTime = $_POST['dTime'];
	$date = date($dTime." 08:00:00");
	$dateE = date('Y-m-d H:i:s', strtotime($date . ' +1 day'));
	$direct = $_POST['line_filter'];
	$token = $_COOKIE['token'];
	$exp = $_POST['exp'];
	
    $userInfo = $data->cGetUser($token);
    $direct_2f = $userInfo->direct_2f;
	$listFilterProcess = "^".implode("|^",$_POST['listFilterP']);
    $finalData = $data->cGetPlanbyDay1($line_filter,$model_filter,$dTime,$listFilterProcess);

    $end =  date('Y-m-d H:i:s');
	$infoLastCheck = $data->cGetInfoLastCheck($direct);
	// print_r($infoLastCheck);
	$dataCheck = [];
	$start ='2023-11-25 08:00:00';
	if (!empty($infoLastCheck)) {
		$start = date($infoLastCheck->end);
		$dataCheck = $data->cGetMaterialCheck($infoLastCheck->id,$exp);
	}
	$inOutData = $data->cGetInOutMaterialByDirect($direct, $start, $end, $exp);
	// print_r($dataCheck);
	$resCheck = json_encode($dataCheck);
	$resInOut = json_encode($inOutData);


    // $stockData = $data->cGetMaterialByDirect($direct, $date, $dateE, $exp);
    $resFinal = json_encode($finalData);
    // $resStock = json_encode($stockData);
?>
<div class="col-md-6">
    <table class="table table-hover table-bordered table-sm dataTable no-footer" id = "finalTable">
        <thead style="background-color: #588cc5; color: white;line-height: 15px;" class="text-center">
            <tr>
                <th >ID</th>
                <th >Direct</th>
                <th >Model</th>
                <th >Process</th>
                <th >Qty</th>
                <th >Result</th>
                <th >Plan Date</th>
            </tr>
            
        </thead>
        <tbody id="finalList">
            
        </tbody>
    </table>
</div>
<div class="col-md-6">
    <table class="table table-hover table-bordered table-sm dataTable no-footer" id = "stockTable">
        <thead style="background-color: #588cc5; color: white;line-height: 15px;" class="text-center">
            <tr>
            	<th >Code </th>
            	<th >Direct </th>
                <th style="background-color: #db5100">Lost</th>
                <th  style="background-color: #db5100">Tồn Đầu</th>
                <th >In</th>
                <th >Out</th>
                <th >Tồn</th>
            </tr>
            
        </thead>
        <tbody id="stockList">
            
        </tbody>
    </table>
</div>
<script>
  
$(document).ready(function(){
	resFinal = <?php echo $resFinal; ?>;
	let direct_2f = '<?php echo $direct_2f; ?>';
	arrDid = [];
	function tableFinal(datax){
		let example = $('#finalTable').DataTable({
			"lengthMenu": [[10, -1], [10, "All"]],
			"order": [[ 3, "desc" ]],
			"scrollY":        "200px",
			
	        "scrollCollapse": true,
	        "paging":         false,
			dom: 'Bfrtip',
			buttons: [
			
			'excel',
			'selectNone',
	           	{
	                text: ' <i class="far fa-eye i-right" style="color:black;"></i>View',
	                className: 'btnPractice',
	                action: function ( e, dt, node, config ) {
	                	if(arrDid.length !=  1){
					        errAlert("Please! Select only 1 row");
					    }else{
						    $.post('view/viewMaterialByPlan',  
				                {id_plan:arrDid[0]},
				                function(data){
				                $("#modal-content").html(data);
				                $('#exampleModal').modal('show');
				            }); 
						}
	           		}
	           	},
	           	{
	                text: ' <i class="fas fa-download i-right" style="color:red;"></i>Import by Plan',
	                className: 'btnPractice',
	                action: function ( e, dt, node, config ) {

	                	if(arrDid.length !=  1){
					        errAlert("Please! Select only 1 row");
					    } else {
					        let id = arrDid[0];
					    window.open("view/importMaterialbyPlan.php?id_plan="+id, "_blank", "scrollbars=yes,resizable=yes,top=0");
	           			}
	           		},
	           	},
	           	{
	                text: ' <i class="fas fa-check i-right" style="color:red;"></i>Confirm Prod',
	                className: 'btnPractice',
	                action: function ( e, dt, node, config ) {
	                	if(arrDid.length !=  1){
					        errAlert("Please! Select only 1 row");
					    } else {
					        let id = arrDid[0];
					        let dataDetail = resFinal.find(a=>a.id == id)
					        let direct = dataDetail.line;
					  		if (direct_2f != 'ADMIN' && direct_2f != direct) {
					  			errAlert("Do not have access to this direct")
					  		} else {
					  			let qty = prompt('Input Product Qty');
						        let max = parseInt(dataDetail.qty)-parseInt(dataDetail.qty_out)
						    	if (!parseInt(qty) || parseInt(qty) <=0 || parseInt(qty) > parseInt(max)) {
								    errAlert("Check Input Again !")
								  } else {
								  	processing2()
					    			$.post('view/exportMaterialbyPlan',  
						                {dataDetail:dataDetail,qty_code:parseInt(qty)},
						                function(data){
						                successAlert(data);
						            });
								}
					  		}
	           			}
	           		},
	           	},

			],
			data: datax,
			columns:[
			
			{data:"id"},
			{data:"line"},
			{data:"model_code"},
			{data:"process"},
			{data:"qty"},
			{data:"qty_out"},
			{data:"sDate"}
			],
			select: {
				style: 'multi'
			}
		});
		example
		.on( 'select', function ( e, dt, type, indexes ) {
			var rowData = example.rows( indexes ).data().toArray();
			for (var i = 0; i < rowData.length; i++) {
				var x = arrDid.indexOf(rowData[i]['id']);
				if (x === -1) //neu ko ton tai
					arrDid.unshift(rowData[i]['id']); //thi push 
                // console.log(arrDid)
			}
		} )
		.on( 'deselect', function ( e, dt, type, indexes ) {
			var rowDataUn = example.rows( indexes ).data().toArray();
			for (var i = 0; i < rowDataUn.length; i++) {
				var x = arrDid.indexOf(rowDataUn[i]['id']);
				arrDid.splice(x, 1);
			}
		});
	}
	tableFinal(resFinal);

	resInOut = <?php echo $resInOut; ?>;
		resCheck = <?php echo $resCheck; ?>;
		let html =''
		for (let i = 0; i < resInOut.length; i++) {
			let code = resInOut[i].code
			let im_qty = (resInOut[i].im_qty != null) ? resInOut[i].im_qty :  0;
			let ex_qty = (resInOut[i].ex_qty != null) ? resInOut[i].ex_qty :  0;
			let dataCheck = resCheck.find(e=> e.code == code)
			let qtyLastQty = 0
			let qtyLastLost = 0

			if (dataCheck != null) {
				qtyLastQty = dataCheck.qty
				qtyLastLost = dataCheck.lost
			}
			resInOut[i].lastLost = qtyLastLost
			resInOut[i].lastQty = qtyLastQty
			
		}
	console.log(resInOut)
	function tableMaterial(datax){
		let example = $('#stockTable').DataTable({
			"lengthMenu": [[10, -1], [10, "All"]],
			"order": [[ 1, "desc" ]],
			"scrollY":        "200px",
			
	        "scrollCollapse": true,
	        "paging":         false,
			dom: 'Bfrtip',
			buttons: [
			'excel',
			'selectNone',
			{
				text: '<i class="fa fa-cubes i-right" style="color:black;"></i>Material Check',
	                className: 'btnPractice',
	                action: function ( e, dt, node, config ) {
					    window.open("view/checkMaterialbyBom.php", "_blank", "scrollbars=yes,resizable=yes,top=0");
	           	}
           	},
           	{
                text: ' <i class="fas fa-download i-right" style="color:green;"></i>Import by Bom',
                className: 'btnPractice',
                action: function ( e, dt, node, config ) {
				    window.open("view/importMaterialbyBom.php", "_blank", "scrollbars=yes,resizable=yes,top=0");
           		},
           	},
           	{
                text: ' <i class="fas fa-download i-right" style="color:blue;"></i>Other Import',
                className: 'btnPractice',
                action: function ( e, dt, node, config ) {
				    window.open("view/importOtherMaterial.php", "_blank", "scrollbars=yes,resizable=yes,top=0");
           		},
           	},
           	{
                text: ' <i class="fas fa-upload i-right" style="color:green;"></i>Export by Bom',
                className: 'btnPractice',
                action: function ( e, dt, node, config ) {
				    window.open("view/exportMaterialbyBom.php", "_blank", "scrollbars=yes,resizable=yes,top=0");
           		},
           	},
           	{
                text: ' <i class="fas fa-upload i-right" style="color:blue;"></i>Other Export',
                className: 'btnPractice',
                action: function ( e, dt, node, config ) {
				    window.open("view/exportOtherMaterial.php", "_blank", "scrollbars=yes,resizable=yes,top=0");
           		},
           	}
			],
			data: datax,
			columns:[
			
			{data:"code"},
			{data:"direct"},
			{"data": function(row, type, set){
				let qty = row['lastLost'] != null ? parseInt(row['lastLost']) : 0 
				return qty
			}},
			{"data": function(row, type, set){
				let qty = row['lastQty'] != null ? parseInt(row['lastQty']) : 0 
				return qty
			}},
			{"data": function(row, type, set){
				let qty = row['im_qty'] != null ? parseInt(row['im_qty']) : 0 
				return qty
			}},
			{"data": function(row, type, set){
				let qty = row['ex_qty'] != null ? parseInt(row['ex_qty']) : 0 
				return qty
			}},
			{"data": function(row, type, set){
				let im_qty = row['im_qty'] != null ? parseInt(row['im_qty']) : 0 
				let ex_qty = row['ex_qty'] != null ? parseInt(row['ex_qty']) : 0 
				let qty = row['lastQty'] != null ? parseInt(row['lastQty']) : 0 
				return parseInt(qty)+parseInt(im_qty)-parseInt(ex_qty)
			}}
			
			],
			select: {
				style: 'multi'
			}
		})
	}
	tableMaterial(resInOut);
})
</script>