<?php
    require('../controller/controller.php');
    date_default_timezone_set("Asia/Ho_Chi_Minh");
    $data = new cEms();
    $check = $data->cCheckToken();
    if ($check['status'] === false) {
        echo $check['data'];
    } else {
        if (isset($_POST['lct'])) {
            $lct = $_POST['lct']; 
            $err_name = $_POST['err_name'];
            $data->cAddLct($lct, $err_name);
            echo "Success";
        } else {
            echo "Failed";
        }
    }
    
?>