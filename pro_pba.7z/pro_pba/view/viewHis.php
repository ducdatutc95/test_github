<?php
	require('../controller/controller.php');
	$data = new cEms();
	$qr = $_POST['qr'];
	$line_filter = $_POST['line_filter'];
	$model_filter = $_POST['model_filter'];
	$dateStart = $_POST['dateStart'];
	$dateEnd = $_POST['dateEnd'];
	$listFilterProcess = "^".implode("|^",$_POST['listFilterStock']);
    $finalData = $data->cGetHisStock($qr,$line_filter,$model_filter,$dateStart,$dateEnd,$listFilterProcess);
    $resFinal = json_encode($finalData);
?>
<div class="col-md-12">
    <table class="table table-hover table-bordered table-sm dataTable no-footer" id = "finalTable">
        <thead style="background-color: #588cc5; color: white;line-height: 15px;" class="text-center">
            <tr>
                <th >QR</th>
                <th >Zin</th>
                <th >Model</th>
                <th >From</th>
                <th >To</th>
                <th >Status</th>
                <th >Time In</th>
                <th >Author</th>
            </tr>
            
        </thead>
        <tbody id="finalList">
            
        </tbody>
    </table>
</div>

<script>
  
$(document).ready(function(){
	resFinal = <?php echo $resFinal; ?>;
	function tableFinal(datax){
		let example = $('#finalTable').DataTable({
			"lengthMenu": [[10, -1], [10, "All"]],
			"order": [[ 3, "desc" ]],
			"scrollY":        "200px",
			
	        "scrollCollapse": true,
	        "paging":         false,
			dom: 'Bfrtip',
			buttons: [
			'excel',
			'selectNone',
			{
	                text: ' <i class="fas fa-exchange-alt i-right" style="color:red;"></i>Scan QR',
	                className: 'btnPractice',
	                action: function ( e, dt, node, config ) {
					    window.open("view/pickPro.php", "_blank", "scrollbars=yes,resizable=yes,top=0");

	           		}
	           	},
	           	{
	                text: ' <i class="fas fa-edit i-right" style="color:red;"></i>Change Octa QR',
	                className: 'btnPractice',
	                action: function ( e, dt, node, config ) {
					    window.open("view/changeqr.php", "_blank", "scrollbars=yes,resizable=yes,top=0");

	           		}
	           	}
			],
			data: datax,
			columns:[
			
			{data:"qr"},
			{data:"zin"},
			{data:"model"},
			{data:"direct"},
			{data:"sub_lct"},
			{
		        "data": function(row, type, set){
		          let status = row['status'];
		          if (status == 1) {
		            return 'Recived';
		          }else if (status == 2) {
		            return 'Pending';
		          } else {
		          	return 'Cancel';
		          }
		        }
		      },
			{data:"sTime"},
			{data:"author"}
			],
			select: {
				style: 'multi'
			}
		});
        
	}
	tableFinal(resFinal);
})
</script>