<?php
	require('../controller/controller.php');
	$data = new cEms();
	if (isset($_COOKIE['token'])) {
		$token = $_COOKIE['token'];
		$userInfo = $data->cGetUser($token);
		if (empty($userInfo)) {
      
          header("Location:../login");
          exit();
        }
	} else {
		header("Location:../login");
		exit();
	}
    $model_code = $_POST['model_code'];
    $process = $_POST['process'];
    $dataDetail = $data->cGetBomDetail($model_code,$process);
    $resFinal = json_encode($dataDetail);
?>
<div class="modal-header">
	<h5 class="modal-title card-title" style="color: #01b1c1;">View Bom Detail</h5>
	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</button>
</div>
<div class="modal-body">
    <div class="row" id = "form_pick">	
        <div class="col-md-12">
            <table class="table table-hover table-bordered table-sm dataTable no-footer" id = "bomTable">
                <thead style="background-color: #588cc5; color: white;line-height: 15px;" class="text-center">
                    <tr>
                        <th >Model Basic</th>
                        <th >Model Code</th>
                        <th >Process</th>
                        <th >Code</th>
                        <th >Desc</th>
                        <th >Qty</th>
                    </tr>
                    
                </thead>
                <tbody id="BomList">
                    
                </tbody>
            </table>
        </div>
	</div>
</div>


<script>
  
$(document).ready(function(){
    resFinal = <?php echo $resFinal; ?>;
    arrDid = [];
    function tableFinal(datax){
        let example = $('#bomTable').DataTable({
            "lengthMenu": [[10, -1], [10, "All"]],
            "order": [[ 3, "desc" ]],
            "scrollY":        "200px",
            "scrollCollapse": true,
            "paging":         false,
            dom: 'Bfrtip',
            buttons: [
            'excel',
            'selectNone',
            ],
            data: datax,
            columns:[
            
            {data:"model_basic"},
            {data:"model_code"},
            {data:"process"},
            {data:"code"},
            {data:"detail"},
            {data:"qty"}
            ],
            select: {
                style: 'multi'
            }
        });
        
    }
    tableFinal(resFinal);
})
</script>