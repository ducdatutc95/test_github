<?php
    require('../controller/controller.php');
    date_default_timezone_set("Asia/Ho_Chi_Minh");
    $sTime =  date('Y-m-d H:i:s');
    $data = new cEms();
    $check = $data->cCheckToken();
    if ($check['status'] === false) {
        echo $check['data'];
    } else {
        $author  = $check['data']->manv;
        $model_code = $_POST['model'];
        $direct = $_POST['direct'];
        $proc = $_POST['proc'];
        $qty_code = $_POST['qty_code'];
        
        $dataDetail = $data->cCheckMaterialbyBom($model_code,$proc,$direct);
        ?>
    <table class="table table-hover table-bordered table-sm dataTable no-footer" id = "showListMaterial">
        <thead style="background-color: #588cc5; color: white;line-height: 15px;" class="text-center">
            <tr> 
                <td>No.</td>
                <td>Code</td>
                <td>BOM Rate</td>
                <td>Remain Qty</td>
                <td id="max">Product Qty</td>
                <td>Shortage</td>
            </tr>
        </thead>
        <tbody>
        	<?php
    			$i=1;
    			$max = 9999999999999;
                foreach ($dataDetail as $key) {
                   ?>
                   <tr <?php if ($key->type != '') {
                          echo "style='background-color:#914242;color:white;'" ;
                      } ?>>
                        <td><?php echo $i++;?></td>    
                        <td><?php echo $key->code;?></td>
                        <td><?php echo $key->qty;?></td>
                        <td><?php echo $key->remain_qty;?></td> 
                        <td><?php echo round($key->remain_qty/$key->qty);?></td>
                        <td><?php echo  $key->remain_qty - ($qty_code*$key->qty);?></td>
                   </tr>

                   <?php
                   if (round($key->remain_qty/$key->qty)<$max) {
                   	$max = round($key->remain_qty/$key->qty);
                   }
                }
            ?>
            </tbody>
        </table>
        </tbody>
        <script type="text/javascript">
        	$(document).ready(function(){
	        	let max = '<?php echo $max; ?>';
	        	$('#max').html("MAX="+max)
	        	let example = $('#showListMaterial').DataTable({
	                "lengthMenu": [[10, -1], [10, "All"]],
	                "order": [[ 1, "desc" ]],
	                "scrollY":        "200px",
	                
	                "scrollCollapse": true,
	                "paging":         false,
	                dom: 'Bfrtip',
	                buttons: [
	                'excel',
	                'selectNone',
	                ]
	            })
			})

        </script>
        <?php
    }
    
?>