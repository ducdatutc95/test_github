<?php
	require('../controller/controller.php');
	$data = new cEms();

	$dTime = $_POST['dTime'];
	$folderName = "//192.168.63.12/2F_Data/".str_replace("-","",$dTime);
	$date = date($dTime." 08:00:00");
	$arrFile = scandir($folderName);
	$finalDataString = "";
	// print_r($arrFile);
	// foreach ($arrFile as $key) {
	for ($i=2; $i < count($arrFile); $i++) { 
		$fileName = $folderName."/".$arrFile[$i];
		$myfile= fopen($fileName,"r");
		$dataFile= fread($myfile,filesize($fileName));  
		$finalDataString .=  $dataFile;
	}
	substr($finalDataString,0,1);
	
	// readfile("test.txt")
	$dateE = date('Y-m-d H:i:s', strtotime($date . ' +1 day'));
	$direct = $_POST['direct'];
    // $finalData = $data->cGetTracking($direct,$listFilterDirect,$date,$dateE);
    if ($direct == '2F-AUTO') {
    	$listFilterDirect = '^01|^02|^03|^04';
    }
    $timeLineData = $data->cGetTimeLine($direct,$listFilterDirect,$date,$dateE);
    $arrMc = $data->cGetLineConfig($direct,'',$date,$dateE);
    $arrModel = $data->cGetModelLcd();
    $arrLine = $data->cGetLineByDirect($direct);
    $qtyPlan = $data->cGetPlanbyDay($dTime,$direct);
    $qtyProcByModel = $data->cGetQtyProcByModel($dTime,$direct);

    $resQtyByModel = json_encode($qtyProcByModel);
    $resTimeLine = json_encode($timeLineData);
    $resMc = json_encode($arrMc);
    $resModel = json_encode($arrModel);
    $resLine = json_encode($arrLine);
    $resPlan = json_encode($qtyPlan);

?>

<div id="showNow" class="row mg0">
	
</div>

<script>
	$(document).ready(function(){
		let resFinal = [<?php echo $finalDataString; ?>];
		resFinal=resFinal.filter(e=>e.res=="PASS")
		let resTimeLine = <?php echo $resTimeLine; ?>;
		let resQtyByModel = <?php echo $resQtyByModel; ?>;
		let resLine = <?php echo $resLine; ?>;
		let resModel = <?php echo $resModel; ?>;
		let resMachine = <?php echo $resMc; ?>;
		let resPlan = <?php echo $resPlan; ?>;
		let resM = ["A","B","C","D","E"]
		let resShift = ["D","N"]
		let html = ""
		let direct = '<?php echo $direct; ?>';
		let dTime = '<?php echo $dTime; ?>';
		let data = []
		let dataTarget = []
		for (let i = 0; i < resLine.length; i++) {
			let line = resLine[i].line
			let resMc = resMachine.filter(e=>e.line == line)
			for (let j = 0; j < resMc.length; j++) {
				let arrActual=[]
				let arrTarget=[]
				let mc = resMc[j].proc
				let tt = resMc[j].tt
				let amodel = resMc[j].model.split('-')
				let model = amodel.at(-1).slice(0, 4)
				if (model == 'A146') {
					model = 'A145'
				}
				let tagetTotal = 0
				for (let s = 0; s < resShift.length; s++) {
					let sub_total = 0
					let shift = resShift[s]
					for (let n = 0; n < resM.length; n++) {
						let kg = resM[n]
						let target
						let timeLine = resTimeLine.filter(e=>e.direct == direct && e.line == line && e.proc == mc && e.shift == shift && e.kg == kg && e.type == 'CAL')
						let sumCal = timeLine.reduce((accumulator, e) => {
						  return accumulator + parseInt(e.diff);
						}, 0);
						if (n == 1 || n == 3) {
							target = (6600-sumCal/1000)/parseInt(tt)
						}else if (n == 4) {
							if (sumCal>0) {
								target = (10800-sumCal/1000)/parseInt(tt)
							} else {
								target = (7200-sumCal/1000)/parseInt(tt)
							}
						} else {
							target = (7200-sumCal/1000)/parseInt(tt)
						}
						if (target <= 0) {
							target = 0
						} 
						sub_total+=parseInt(target)
					}
					tagetTotal += sub_total 
					dataTarget.push({"line":line,"mc":mc,"model":model,"shift":shift,"qty":sub_total})
				}
			}
		}
		for (let i = 0; i < resFinal.length; i++) {
			let time = new Date(resFinal[i].tTime)
			let t = time.getHours();
			let pn = resFinal[i].pn
			let mc = resFinal[i].mc
			let line = resFinal[i].line
			let direct = resFinal[i].direct
			let amodel = resFinal[i].model.split('-')
			let model = amodel.at(-1).slice(0, 4)
			let m = ''
			let shift = ''
			if (model == 'A146') {
				resFinal[i].model_real = 'A145'
			} else {
				resFinal[i].model_real = model
			}
			if (t>=8 && t < 20) {
				shift = "D"
			} else {
				shift = "N"
			}
			resFinal[i].shift = shift
		}

		let modelArr = resFinal
	        .map((item) => item.model_real)
	        .filter(
	            (value, index, current_value) => current_value.indexOf(value) === index
        );
	        // console.log(dataTarget)
		for (let i = 0; i < modelArr.length; i++) {
			let model = modelArr[i]
			let pplan = resPlan.find(e=>e.basic==model)
			let qtyPlan = 0
			if (pplan!=undefined) {qtyPlan = parseInt(pplan.qty)}
			
			let targetByModelBonding = dataTarget.filter(e=>e.model == model && e.mc == 'BONDING VISION')
			let qtyTargetBonding = targetByModelBonding.reduce((n, {qty}) => n + qty, 0)
			let targetByModelLcd = dataTarget.filter(e=>e.model == model && e.mc == 'LCD TEST')
			let qtyTargetLcd = targetByModelLcd.reduce((n, {qty}) => n + qty, 0)
			let targetByModelRf = dataTarget.filter(e=>e.model == model && e.mc == 'RF CALL')
			let qtyTargetRf = targetByModelRf.reduce((n, {qty}) => n + qty, 0)
			html+='<div class="col-md-6">'
				html+='<h3>Báo cáo hiện trạng sản xuất '+model+'</h3>'
				html+='<table class="table table-hover table-bordered" style="font-size: 14px;">'
					html+='<thead style="background-color: #01b1c1; color: white;line-height: 15px;" class="text-center">'
						html+='<tr>'
							html+='<th colspan="2"  style="vertical-align: middle;" >Date </th>'
							html+='<th colspan="4" style="vertical-align: middle;" >Plan</th>'
							// html+='<th colspan="4" style="vertical-align: middle;" >Target</th>'
						html+='</tr>'
						html+='<tr>'
							html+='<th colspan="2"  style="vertical-align: middle;" >'+dTime+'</th>'
							html+='<th colspan="4" style="vertical-align: middle;">'+qtyPlan.toLocaleString('en')+'</th>'
							// html+='<th colspan="2" style="vertical-align: middle;">'+qtyTargetBonding.toLocaleString('en')+'</th>'
						html+='</tr>'
					html+='</thead>'
					html+='<tbody id="showTable" class="reportBodyByModel">'
						// bonding
						
						let bondingD = resFinal.filter(e=>e.model_real==model && e.mc == 'BONDING VISION' && e.shift =='D')
						let bondingN = resFinal.filter(e=>e.model_real==model && e.mc == 'BONDING VISION' && e.shift =='N')
						let bondingTotal = bondingN.length+bondingD.length
						html+='<tr style="background-color: #f9f6f6;"><td rowspan="2" style="vertical-align: middle;font-weight:bold;">Bonding</td>'
						html+='<td>Target</td><td>Actual</td><td>Rate</td><td>Day Shift</td><td>Night Shift</td>'
						html+='</tr>'
						html+='<tr>'
						html+='<td>'+qtyTargetBonding.toLocaleString('en')+'</td><td>'+bondingTotal.toLocaleString('en')+'</td><td>'+Math.round((bondingTotal/qtyTargetBonding)*10000)/100+'%</td><td>'+bondingD.length.toLocaleString('en')+'</td><td>'+bondingN.length.toLocaleString('en')+'</td>'
						html+='</tr>'

						// pba
						// html+='<tr><td rowspan="2" style="vertical-align: middle;font-weight:bold">PBA & BTM</td>'
						// html+='<td>Actual</td><td>'+0+'</td><td>Day Shift</td><td>'+0+'</td>'
						// html+='</tr>'
						// html+='<tr>'
						// html+='<td>Rate</td><td>'+0+'%</td><td>Night Shift</td><td>'+0+'</td>'
						// html+='</tr>'

						// lcd
						
						let lcdD = resFinal.filter(e=>e.model_real==model && e.mc == 'LCD TEST' && e.shift =='D')
						let lcdN = resFinal.filter(e=>e.model_real==model && e.mc == 'LCD TEST' && e.shift =='N')

						let lcdTotal = lcdN.length+lcdD.length
						html+='<tr style="background-color: #f9f6f6;"><td rowspan="2" style="vertical-align: middle;font-weight:bold">Test LCD</td>'
						html+='<td>Target</td><td>Actual</td><td>Rate</td><td>Day Shift</td><td>Night Shift</td>'
						html+='</tr>'
						html+='<tr>'
						html+='<td>'+qtyTargetLcd.toLocaleString('en')+'</td><td>'+lcdTotal.toLocaleString('en')+'</td><td>'+Math.round((lcdTotal/qtyTargetLcd)*10000)/100+'%</td><td>'+lcdD.length.toLocaleString('en')+'</td><td>'+lcdN.length.toLocaleString('en')+'</td>'
						html+='</tr>'

						// rf call
						
						let rfD = resFinal.filter(e=>e.model_real==model && e.mc == 'RF CALL' && e.shift =='D')
						let rfN = resFinal.filter(e=>e.model_real==model && e.mc == 'RF CALL' && e.shift =='N')

						let rfTotal = rfN.length+rfD.length
						html+='<tr style="background-color: #f9f6f6;"><td rowspan="2" style="vertical-align: middle;font-weight:bold">RF CALL</td>'
						html+='<td>Target</td><td>Actual</td><td>Rate</td><td>Day Shift</td><td>Night Shift</td>'
						html+='</tr>'
						html+='<tr>'
						html+='<td>'+qtyTargetRf.toLocaleString('en')+'</td><td>'+rfTotal.toLocaleString('en')+'</td><td>'+Math.round((rfTotal/qtyTargetRf)*10000)/100+'%</td><td>'+rfD.length.toLocaleString('en')+'</td><td>'+rfN.length.toLocaleString('en')+'</td>'
						html+='</tr>'

						// Wait confirm

						let qqtyWcfD = resQtyByModel.find(e=>e.mc=="Wait Confirm" && e.model == model && e.shift=='D')
						let qqtyWcfN = resQtyByModel.find(e=>e.mc=="Wait Confirm" && e.model == model && e.shift=='N')

						let qtyWcfD = 0
						if (qqtyWcfD!=undefined) {qtyWcfD = parseInt(qqtyWcfD.qty)}
						
						let qtyWcfN = 0
						if (qqtyWcfN!=undefined) {qtyWcfN = parseInt(qqtyWcfN.qty)}

						let totalWcf = qtyWcfD+qtyWcfN
						let rateWcf = Math.round((totalWcf/qtyPlan)*10000)/100
						html+='<tr style="background-color: #f9f6f6;"><td rowspan="2" style="vertical-align: middle;font-weight:bold">Wait Confirm</td>'
						html+='<td>Target</td><td>Actual</td><td>Rate</td><td  class="inputQty" mc="Wait Confirm" direct="'+direct+'" shift="D" model="'+model+'">Day Shift</td><td  class="inputQty" mc="Wait Confirm" direct="'+direct+'" shift="N" model="'+model+'">Night Shift</td>'
						html+='</tr>'
						html+='<tr>'
						html+='<td>'+qtyPlan.toLocaleString('en')+'</td><td>'+totalWcf.toLocaleString('en')+'</td><td>'+rateWcf+'%</td><td  class="inputQty" mc="Wait Confirm" direct="'+direct+'" shift="D" model="'+model+'">'+qtyWcfD.toLocaleString('en')+'</td><td  class="inputQty" mc="Wait Confirm" direct="'+direct+'" shift="N" model="'+model+'">'+qtyWcfN.toLocaleString('en')+'</td>'
						html+='</tr>'

						// gmes

						let qqtyMesD = resQtyByModel.find(e=>e.mc=="G-MES" && e.model == model && e.shift=='D')
						let qqtyMesN = resQtyByModel.find(e=>e.mc=="G-MES" && e.model == model && e.shift=='N')

						let qtyMesD = 0
						if (qqtyMesD!=undefined) {qtyMesD = parseInt(qqtyMesD.qty)}
						
						let qtyMesN = 0
						if (qqtyMesN!=undefined) {qtyMesN = parseInt(qqtyMesN.qty)}

						let totalMes = qtyMesD+qtyMesN
						let rateMes = Math.round((totalMes/qtyPlan)*10000)/100
						html+='<tr style="background-color: #f9f6f6;"><td rowspan="2" style="vertical-align: middle;font-weight:bold">G-MES</td>'
						html+='<td>Target</td><td>Actual</td><td>Rate</td><td  class="inputQty" mc="G-MES" direct="'+direct+'" shift="D" model="'+model+'">Day Shift</td><td  class="inputQty" mc="G-MES" direct="'+direct+'" shift="N" model="'+model+'">Night Shift</td>'
						html+='</tr>'
						html+='<tr>'
						html+='<td>'+qtyPlan.toLocaleString('en')+'</td><td>'+totalMes.toLocaleString('en')+'</td><td>'+rateMes+'%</td><td  class="inputQty" mc="G-MES" direct="'+direct+'" shift="D" model="'+model+'">'+qtyMesD.toLocaleString('en')+'</td><td  class="inputQty" mc="G-MES" direct="'+direct+'" shift="N" model="'+model+'">'+qtyMesN.toLocaleString('en')+'</td>'
						html+='</tr>'

					html+='</tbody>'
				html+='</table>'
			html+='</div>'
		}
		$("#showNow").html(html)

		$('.inputQty').click(function(){
			let direct = $(this).attr("direct");
			let mc = $(this).attr("mc");
			let shift = $(this).attr("shift");
			let model = $(this).attr("model");
			let qty = 0;
			inputS("Input Production Qty",direct+" / Shift: "+shift+" / Model: "+model+" / "+mc,"Input number").then(e=>{
				if (parseInt(e) !== 0 && !isNaN(parseInt(e))) {
					qty = parseInt(e)
					$.post('view/addQtyProduct',  
		                {dTime:dTime,direct:direct,mc:mc,shift:shift,model:model,qty:qty},
		                function(data){
		                	if (data.trim()=="Success") {
		                		successAlert(data)
		                	} else {
		                		// successAlert(data)
		                		errAlert(data)
		                	}
		            });
				} else{
					errAlert("Check input again !")
				}
			})


		})
	})
</script>