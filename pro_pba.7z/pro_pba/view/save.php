<?php
    require('../controller/controller.php');
    date_default_timezone_set("Asia/Ho_Chi_Minh");
    $data = new cEms();
    $author  = $_POST['author'];
    $type  = $_POST['type'];
    $line = $_POST['line'];
    $result = $_POST['result'];
    if (isset($_POST['dataIn'])) {
        $dataIn = $_POST['dataIn'];
        if ($type == 'IN') {
            for ($i=0; $i < count($dataIn); $i++) {
                $did = $dataIn[$i]['did'];
                $code = $dataIn[$i]['code'];
                $sTime = $dataIn[$i]['time'];
                $qty = $dataIn[$i]['qty'];
                $data->cInputMaterial($did, $code, $sTime, $qty, $line, $author);
            }
            for ($i=0; $i < count($result); $i++) {
                $code = $result[$i]['code'];
                $qty = $result[$i]['qty'];
                $data->cUpQtyLine($line,$code,$qty);
            }
        }
        else {
            for ($i=0; $i < count($dataIn); $i++) {
                $did = $dataIn[$i]['did'];
                $code = $dataIn[$i]['code'];
                $sTime = $dataIn[$i]['time'];
                $qty = $dataIn[$i]['qty'];
                $data->cOutputMaterial($did, $code, $sTime, $qty, $line, $author);
            }

            for ($i=0; $i < count($result); $i++) {
                $code = $result[$i]['code'];
                $qty = $result[$i]['qty'];
                $data->cDownQtyLine($line,$code,$qty);
            }
        }
        
    }
    echo '<h4>Success</h4>';
    
?>