<?php
require('../vendor/Classes/PHPExcel.php');
require('../controller/controller.php');
date_default_timezone_set("Asia/Ho_Chi_Minh");
$data = new cEms();
$author  = $_POST['author'];
$sDate  = $_POST['sDate'];
$shift  = $_POST['shift'];
ini_set('memory_limit', '4095M');
ini_set('max_execution_time', 6000);
$file = $_FILES['img']['tmp_name'];
$objreader = PHPExcel_IOFactory::createReaderForFile($file); // tạo đối tượng reader
$objreader->setLoadSheetsOnly('Sheet1'); //
$objExcel = $objreader->load($file);
$sheetData = $objExcel->getActiveSheet()->toArray('null', true, true, true);

// lấy dòng cao nhất trong file
$highestRow = $objExcel->setActiveSheetIndex()->getHighestRow();
// $arrData = [];
// $data->cDelBom();
$arr = [];
$data->cDelProMes($sDate, $shift);
$str = '';
for ($row = 2; $row <= $highestRow; $row++) {
  $plan = $sheetData[$row]['A'];
  $model = $sheetData[$row]['C'];
  $type = $sheetData[$row]['D'];
  $code = $sheetData[$row]['F'];
  $qty = $sheetData[$row]['H'];
  $point = $sheetData[$row]['J'];
  $line = substr($sheetData[$row]['P'], -2);
  $basic = $sheetData[$row]['R'];

  if ($basic == 'SM-T730 POGo') {
    $basic = 'SM-DT730 POGo';
  }

  if ($row == $highestRow) {
    $str .= "('" . $plan . "','" . $line . "','" . $model . "','" . $code . "','" . $qty * $point . "','" . $point . "','" . $basic . "','" . $sDate . "','" . $shift . "')";
  } else {
    $str .= "('" . $plan . "','" . $line . "','" . $model . "','" . $code . "','" . $qty * $point . "','" . $point . "','" . $basic . "','" . $sDate . "','" . $shift . "'),";
  }

  if (strpos(strval($code), 'RM01') === false && strpos(strval($code), '0701-00000') === false) {
    $arr[] = (object) ['code_hm' =>  $model, 'type' => $type, 'code' => $code, 'point' => $point, 'line' => $line, 'basic' => $basic];
  }

  // $key = $data->cFind($arr, $line,$code);
  // if ($key>=0) {
  //   $arr[$key]->qty += $qty;
  // } else {
  //   $arr[] = (object) ['line' => $line,'code'=>$code,'qty'=>$qty];
  // }
  // cho cái lệnh sum vào db
}

$data->cUpProMes($str);


// print_r($str);
// for ($i=0; $i < count($arr); $i++) { 
//   $code = $arr[$i]->code;
//   $line = $arr[$i]->line;
//   $qty = $arr[$i]->qty;
//   $data->cUpQtyPlan($line,$code,$qty);
// }
// print_r($arr);
$objExcel->disconnectWorksheets();
unset($objExcel);
echo "Success";

// print_r($arr);
?>

<div class="n_chidl_after"></div>

<script>
  $(document).ready(function() {

    var arrData = <?php echo json_encode($arr); ?>;
    // console.log(arrData);

    if (arrData.length > 0) {
      $.post('view/checkPlanBom.php', {
        arrData: arrData
      }, function(data) {
        $(".n_chidl_after").html(data)
      });
    } else {
      console.log("Data empty");
    }

  })
</script>