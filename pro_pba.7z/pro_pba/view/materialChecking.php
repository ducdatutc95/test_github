<?php
    require('../controller/controller.php');
    date_default_timezone_set("Asia/Ho_Chi_Minh");
    $data = new cEms();
    $line = $_POST['line'];
    $note = $_POST['note'];
    $author = $_POST['author'];
    $id = "CHECK_".$author."_".time();
    $sTime =  date('Y-m-d H:i:s');
    if (isset($_POST['resTotal'])) {
        foreach ($_POST['resTotal'] as $key) {
            // print_r($key);
           $code = $key['code'];
           $qty = ($key['qty']!='') ? $key['qty'] : 0;
           $realQty = ($key['real_qty']!='') ? $key['real_qty'] : 0;
           $data->cAddMaterialCheckDetail($id,$code,$qty,$realQty,$line,$note,$author,$sTime);
        }
    echo "Success";
    } else {
        echo "Failed";
    }
    
?>