<?php
    require('../controller/controller.php');
    $data = new cEms();
    if (isset($_COOKIE['token'])) {
        $token = $_COOKIE['token'];
        $userInfo = $data->cGetUser($token);
        if (empty($userInfo)) {
      
          header("Location:../login");
          exit();
        }
    } else {
        header("Location:../login");
        exit();
    }
$id = $_POST['id'];
$listModel = $data->cGetListCode();
?>
<div class="modal-header">
    <h5 class="modal-title card-title" style="color: #01b1c1;">Change Code</h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<div class="modal-body">
    <div class="row" id = "form_pick">  
        <div class="col-md-6 showEditInfo">
            <div class="input-group input-group-sm mb-3">
                <div class = "input-group-prepend">
                    <label class="input-group-text">Code :</label>
                </div>
                <input type="text" id="code_change" class="form-control form-control-sm" list="arrCode">
               <datalist id="arrCode">
                <?php
                foreach ($listModel as $key) {
                  ?>
                      <option value="<?php echo $key->code; ?>"><?php echo $key->code; ?></option>
                  <?php
                  }
                ?>
              </datalist>
            </div>
        </div>

        <div class="col-md-6 showEditInfo">
            
            <button class="btn btn-success form-control" id="confirm">
                <i class="fas fa-save"></i>
                Confirm
            </button>
            <i style="color:red;margin-bottom:1em;">* Please do not close the website or reload the page before receiving the 'Success' message</i>
        </div>
    </div>
</div>
<script>
    $(document).ready(function(){
        $("#confirm").click(function(){
            let id = '<?php echo $id; ?>';
            let code_change = $('#code_change').val().toUpperCase().trim();
            
            $("#confirm").remove();
            $.post('view/changingCode', 
                {id:id,code_change:code_change}, 
            function(data){
                $(".close").click();
                successAlert(data);
                loadPlan()
            });
        });
    });
</script>