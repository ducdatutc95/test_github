<?php
date_default_timezone_set("Asia/Ho_Chi_Minh");
$stime_cut = date('Y-m-d H:i:s');
$time_unique = date('YmdHis');

require('../controller/controller.php');
$data = new cEms();

if (isset($_POST['objIm']) && isset($_POST['objRoot']) && isset($_POST['sum_qty_cut'])) {
    $objIm = $_POST['objIm'];
    $objRoot = $_POST['objRoot'];
    $sum_qty_cut = $_POST['sum_qty_cut'];
    $author_cut = isset($_POST['author']) ? $_POST['author'] : 'ERROR_AUTHOR';

    // print_r($objIm);
    // print_r($objRoot);
    // print_r($sum_qty_cut);
    // print_r($author_cut);

    // Did old
    $root_id = $objRoot[0]['id'];
    $root_did = $objRoot[0]['did'];
    $root_code = $objRoot[0]['code'];
    $root_qty = $objRoot[0]['qty'];
    $qty_remain = intval($root_qty) - intval($sum_qty_cut);
    $root_line = $objRoot[0]['line'];
    $root_status = $objRoot[0]['status'];
    $root_number_of_cut = $objRoot[0]['number_of_cut'];
    $root_author = $objRoot[0]['author'];
    $root_sTime = $objRoot[0]['sTime'];

    $did_unique = $root_did . '_' . (intval($root_number_of_cut) + 1) . '_' . $time_unique;
    $data->cHandleCutDidRoot($root_id, $root_did, $root_code, $root_qty,$qty_remain, $root_line, $root_status, $root_number_of_cut, $root_author, $root_sTime, $author_cut, $stime_cut, $did_unique);

    // Did new
    for ($i = 0; $i < count($objIm); $i++) {
        $did = $objIm[$i]['did'];
        $code = $objIm[$i]['code'];
        $subcode = substr($code, 0, 12);
        $qty = substr($code, -6, 6);
        $direct = 'DIVIDE_CUT';
        $status = 'Input';

        $data->cHandleCutDidChild($did, $code, $subcode, $qty, $direct, $status, $author_cut, $stime_cut, $did_unique);
    }

    echo '<h4>Success</h4>';
} else {
    echo '<h4>Fail</h4>';
}

?>
<h1></h1>