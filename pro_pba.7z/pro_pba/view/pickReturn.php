<?php
    require('../controller/controller.php');
    $data = new cEms();
    if (isset($_COOKIE['token'])) {

        $token = $_COOKIE['token'];
        $userInfo = $data->cGetUser($token);
        if (empty($userInfo)) {
          echo '<div class="panel-alert"><i class="fas fa-bell i-right"></i>Do not have access to this function. Please contact admin</div>';
          exit();
        }
    } else {
        echo '<div class="panel-alert"><i class="fas fa-bell i-right"></i>Do not have access to this function. Please contact admin</div>';
        exit();
    }
    $finalData = $data->cGetZinRecived();
    $dataFinal = json_encode($finalData);
?>

   
   <div class="row" id = "form_pick">  
      <div class="col-md-12">
        <h5 class="tit-table modal-title " style="width: 100%;"><i class="fa fa-flag i-right"></i>Return MM </h5>
        <div class="col-md-12" id="end" style="text-align: center;">
          <input type="text" id="qr_input" class="form-control" style="width:60%; margin:auto;margin-top:10px;margin-bottom:10px;" placeholder="Scan Zin Barcode !">    
            <button class="btn btn-success form-control" id="save" style="margin-bottom:10px;width:40%;text-align: center;">
                <i class="fas fa-save"></i>
                 Confirm
            </button>
            <table class="table table-hover table-bordered" id="data_in">
                <thead style="background-color:#01b1c1;color:white; font-size: 16px;font-weight: bold; ">
                    <tr>
                      <td style="width: 5%;">Stt</td>
                        <td>QR Code.</td>
                        <td>Time</td>
                        <td style="width: 25%;">Status</td>
                        <td style="width: 25%;">Qty</td>
                        <td style="width: 5%;">Delete</td>  
                    </tr>
                </thead>
                <tbody id="dataEx"> 
                </tbody>
            </table>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function(){
        let author = '<?php echo $userInfo->manv; ?>';
        let dataFinal = <?php echo $dataFinal; ?>;
        let dataIn = []
        $("#qr_input").focus();
        let i = 0;
        $("#qr_input").keyup(function(event){
            if(event.keyCode===13){
                let time = formatDate(new Date());
                let stt = '';
                let qty = 0;
                let qr_input = $("#qr_input").val().toUpperCase();
                let checkExist = dataFinal.find(e => e.zin == qr_input)
                let checkDouble = dataIn.find(e => e.zin == qr_input)
                let direct = 'INPUT';
                if (/[^0-9a-z\-\_\+$]/i.test(qr_input) || qr_input.length< 5) {
                    Stt = 'Bar Code Wrong !';
                } else if(checkExist == null){
                    
                    Stt = 'Bar Code Not Exist !';
                } else if(checkDouble){
                    Stt = 'Bar Code already Exist !';
                } else {
                    Stt = 'OK';
                    qty = checkExist.qty
                    dataIn.push({"zin":qr_input,time:time});
                    i++
                }
                $('#dataEx').prepend('<tr><td>'+i+'</td><td>'+qr_input+'</td><td>'+time+'</td><td id = "st">'+Stt+'</td><td>'+qty+'</td><td class = "text-center "><button class = "btn btn-outline-danger btn-sm">&times;</button></td></tr>');
                if (Stt != 'OK') {$("#st").css("color", "Red");}
                if (Stt == 'OK') {$("#st").css("color", "Green");}
                $("#qr_input").focus();
                $("#qr_input").val('');
            }
        });

        $('#dataEx').on('click', 'tr td button', function() {
            let qr_input = $(this).closest('tr').find('td:eq(1)').text();
            if($(this).closest('tr').find('td:eq(3)').text() == 'OK'){
                let indexOfIn = dataIn.findIndex(indexR => indexR.zin == qr_input);
                dataIn.splice(indexOfIn, 1)
                i = i-1;
            }
            $(this).closest('tr').remove();
        });

        $("#save").click(function(){
            quest('Are you sure SAVE!').then((result) => {
                if (result.isConfirmed) {
                    let data = document.getElementById('dataEx');
                    if (dataIn.length < 1) {
                        errAlert('Data Input Empty');
                    } else {
                        processing1()
                        $("#save").remove()
                        $("#qr_input").remove()
                        $.post('pReturn.php', 
                            {dataIn:dataIn,author:author},
                            function(data){
                                $("#end").html(data);
                        });
                    }
                }
            })
        });
    })
</script>