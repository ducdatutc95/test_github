<?php
    require('../controller/controller.php');
    $data = new cEms();
    if (isset($_COOKIE['token'])) {

        $token = $_COOKIE['token'];
        $userInfo = $data->cGetUser($token);
        if (empty($userInfo)) {
          echo '<div class="panel-alert"><i class="fas fa-bell i-right"></i>Do not have access to this function. Please contact admin</div>';
          exit();
        }
    } else {
        echo '<div class="panel-alert"><i class="fas fa-bell i-right"></i>Do not have access to this function. Please contact admin</div>';
        exit();
    }
    $finalData = $data->cGetDataCheck();
    $dataFinal = json_encode($finalData);
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>[SET] Octa QR Code - Stock Management</title>

  <!-- liên kết css -->
  <link href="../vendor/css/style.css" rel="stylesheet" type="text/css" >
  <link rel="shortcut icon" type="image/png" href="../vendor/img/icon.jpg"/>
  <!-- liên kết bootstrap css -->
  <link href="../vendor/bootstrap/bootstrap.min.css" rel="stylesheet" type="text/css" >
  <link href="../vendor/bootstrap/bootstrap.css" rel="stylesheet" type="text/css" >
  <link href="../vendor/bootstrap/bootstrap-datetimepicker.css" rel="stylesheet" type="text/css" >
  <!-- liên kết datatable css -->
  <link href="../vendor/datatable/dataTables.min.css" rel="stylesheet" type="text/css" />
  <!-- liên kết font css -->
  <link rel="stylesheet" href="../vendor/fontawesome/css/all.min.css">
  <link href="../vendor/datatable/buttons.dataTables.min.css" rel="stylesheet" type="text/css" />
  <link href="../vendor/datatable/select.dataTables.css" rel="stylesheet" type="text/css" />
  <link href="../vendor/chart/chartist.min.css" rel="stylesheet" type="text/css" />
    <style>
       
    </style>
</head>
<div class="fixed-top">
   <nav class="navbar fixed-top navbar-expand-lg bg-light white scrolling-navbar"  style="border-bottom: 1px solid #d5d5d5;font-size:14px; ">
      <div class="container-fluid">
        <a class="navbar-brand waves-effect padding-0" href="./index" style = "text-align:center;">
          <span class = "logo-adz"><i class="fas fa-chart-bar"></i>DREAMTECH-EMS</span> </br>
        </a>
        
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="fas fa-bars" style="font-size: 1em;color: black;"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
          </ul>
          <ul class="navbar-nav mr-auto navbar-right" style="margin-right: 0 !important;display: flex;">
              <li class="nav-item menu-admin">
                <a class="nav-link waves-effect user"><i class="fa fa-user"></i><?php echo($userInfo->name); ?> </a>             
              </li>
              <li class="">
                
          </ul>
        </div>
          
      </div>
  </nav>
</div>
<div class="container" id="scan_screen">
   
   <div class="row" id = "form_pick">  
      <div class="col-md-12">
        <h5 class="tit-table modal-title " style="width: 100%;"><i class="fa fa-flag i-right"></i>QR Check</h5>
        <div class="col-md-12" id="end" style="text-align: center;">
        	<input type="text" id="qr_input" class="form-control" style="width:60%; margin:auto;margin-top:10px;margin-bottom:10px;" placeholder="Scan QR In Here !">		
            <button class="btn btn-success form-control" id="save" style="margin-bottom:10px;width:40%;text-align: center;">
                <i class="fas fa-save"></i>
                 Confirm
            </button>
            <table class="table table-hover table-bordered" id="data_in">
                <thead style="background-color:#01b1c1;color:white; font-size: 16px;font-weight: bold; ">
                    <tr>
                    	<td style="width: 5%;">Stt</td>
                        <td>QR Code.</td>
                        <td>Time</td>
                        <td style="width: 25%;">Status</td>
                        <td style="width: 5%;">Delete</td>  
                    </tr>
                </thead>
                <tbody id="dataEx">	
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
<section class="copyright" style="margin-top: 0.2em;">
  <div class="container">
    <div class="row">
      <div class="col-md-12 ">
        <div class="text-center text-black">
          &copy; System 2022 Created by 44247-TranHa.
          All Rights Reserved by DreamTech Company
        </div>
      </div>
    </div>
  </div>
</section>
<script src='../vendor/js/socket.io.js'></script>
<script src="../vendor/js/jquery.js"></script>
<script src="../vendor/js/myQuery.js"></script>
<script src="../vendor/js/tree_menu.js"></script>
<script src="../vendor/chart/chartist.min.js"></script>
<script src="../vendor/chart/utils.js"></script>
<script src="../vendor/chart/chart.bundle.min.js"></script>
<script src="../vendor/js/tree.min.js"></script>
<script src="../vendor/js/sweetalert2.all.min.js"></script>
<script src="../vendor/bootstrap/bootstrap.min.js"></script>
<script src="../vendor/datatable/dataTables.min.js"></script>
<script src="../vendor/datatable/dataTables.select.js"></script>
<script src="../vendor/datatable/dataTables.buttons.min.js"></script>
<script src="../vendor/datatable/dataTables.buttonHtml5.min.js"></script>
<script src="../vendor/datatable/buttons.flash.min.js"></script>
<script src="../vendor/datatable/jszip.min.js"></script>
<script src="../vendor/bootstrap/moment.min.js"></script>
<script src="../vendor/bootstrap/bootstrap-datetimepicker.js"></script>  
<script src="../vendor/datatable/dataTables.bootstrap4.min.js"></script> 
<script type="text/javascript">
    $(document).ready(function(){
        let author = '<?php echo $userInfo->manv; ?>';
        let dataFinal = <?php echo $dataFinal; ?>;
        let dataIn = []
        $("#qr_input").focus();
        let i = 0;
        $("#qr_input").keyup(function(event){
            if(event.keyCode===13){
                let time = formatDate(new Date());
                let stt = '';
                let qr_input = $("#qr_input").val().toUpperCase();
                let checkExist = dataFinal.find(e => e.qr == qr_input)
                let checkDouble = dataIn.find(e => e.qr == qr_input)
                let direct = 'INPUT';
                if (/[^0-9a-z\-\_\+$]/i.test(qr_input) || qr_input.length< 5) {
                    Stt = 'QR Code Wrong !';
                } else if(checkExist == null){
                    
                    Stt = 'QR Code Not Exist !';
                } else if(checkDouble){
                    Stt = 'QR Code already Exist !';
                } else {
                    Stt = 'OK';
                    dataIn.push({"qr":qr_input,time:time});
                    i++
                }
                $('#dataEx').prepend('<tr><td>'+i+'</td><td>'+qr_input+'</td><td>'+time+'</td><td id = "st">'+Stt+'</td><td class = "text-center "><button class = "btn btn-outline-danger btn-sm">&times;</button></td></tr>');
                if (Stt != 'OK') {$("#st").css("color", "Red");}
                if (Stt == 'OK') {$("#st").css("color", "Green");}
                $("#qr_input").focus();
                $("#qr_input").val('');
            }
        });

        $('#dataEx').on('click', 'tr td button', function() {
            let qr_input = $(this).closest('tr').find('td:eq(1)').text();
            if($(this).closest('tr').find('td:eq(3)').text() == 'OK'){
                let indexOfIn = dataIn.findIndex(indexR => indexR.qr == qr_input);
                dataIn.splice(indexOfIn, 1)
                i = i-1;
            }
            $(this).closest('tr').remove();
        });

        $("#save").click(function(){
            quest('Are you sure SAVE!').then((result) => {
                if (result.isConfirmed) {
                    let data = document.getElementById('dataEx');
                    if (dataIn.length < 1) {
                        errAlert('Data Input Empty');
                    } else {
                        processing1()
                        $("#save").remove()
                        $("#qr_input").remove()
                        $.post('checking.php', 
                            {dataIn:dataIn,author:author},
                            function(data){
                                $("#end").html(data);
                        });
                    }
                }
            })
        });
    })
</script>