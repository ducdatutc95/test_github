<?php
    require('../controller/controller.php');
    date_default_timezone_set("Asia/Ho_Chi_Minh");
    $sTime =  date('Y-m-d H:i:s');
    $data = new cEms();
    $check = $data->cCheckToken();
    if ($check['status'] === false) {
        echo $check['data'];
    } else {
        $dataDetail = $_POST['dataDetail'];
        $qty_code = $_POST['qty_code'];
        $id_plan = $dataDetail['id_plan'];
        $model_code = $dataDetail['model'];
        $line = $dataDetail['line'];
        $data->cUpdateOutPLan($id_plan,$line,$model_code,$qty_code);
        $bomDetail = $data->cGetBomDetail($id_plan);
        // print_r($model_code);
        foreach ($bomDetail as $key) {
            $code = $key->code;
            $qty= $qty_code*$key->qty;
            $data->cDownCfProd($line,$code,$qty);
        }
        echo "Success";
    }
    
?>