<?php
    require('../controller/controller.php');
    date_default_timezone_set("Asia/Ho_Chi_Minh");
    $data = new cEms();
    $author  = $_POST['author'];
    $type  = $_POST['type'];
    $lct = $_POST['lct'];
    $sub_lct = $_POST['sub_lct'];
    $model = $_POST['model'];
    $qr = $_POST['qr_input'];
    $dataQr = $data->cGetQr($qr);
    $err_name = '';

    if ($type == 'IN') {
    	if (empty($dataQr)) {
    		$direct = 'INPUT';
    		$data->cInQr('',$qr, $model, $lct, $sub_lct, $author,$direct,1);
    		echo "<h3 style='color:green'>".$qr." : Success</h3>";
    	} else {
    		echo "<h3 style='color:red'>".$qr." : Already Exist !</h3>";
    	}
    	
    } else if($type == 'OUT') {
    	if (empty($dataQr)) {
    		echo "<h3 style='color:red'>".$qr." : NOT Exist !</h3>";
    	} else {
    		if ($dataQr->lct == 'LINE') {
	    		$direct = $dataQr->sub_lct;
	    		$stime =  date('Y-m-d H:i:s'); 
	    		$model = $dataQr->model;
	    		$data->cOUT($qr,$model, $lct, $sub_lct, $author, $stime,$direct);
	    		echo "<h3 style='color:green'>".$qr." : Success</h3>";
	    	} else {
	    		echo "<h3 style='color:red'>".$qr." : NOT Exist !</h3>";
	    	}
    	}
    } else {
    	if ($lct == 'MM') {
    		if (empty($dataQr)) {
	    		echo "<h3 style='color:red'>".$qr." : NOT Exist !</h3>";
	    	} else {
	    		if ($dataQr->lct == 'LINE') {
		    		$direct = $dataQr->sub_lct;
		    		$stime =  date('Y-m-d H:i:s'); 
		    		$model = $dataQr->model;
		    		$data->cOUT($qr,$model, $lct, $sub_lct, $author, $stime,$direct);
		    		echo "<h3 style='color:green'>".$qr." : Success</h3>";
		    	} else {
		    		echo "<h3 style='color:red'>".$qr." : NOT Exist !</h3>";
		    	}
	    	}
    	} else if($lct == 'MM-REPAIR'){
    		$err_name = $_POST['err_name'];
    		if (empty($dataQr) || $dataQr->lct != 'REPAIR' || $err_name == '') {
	    		echo "<h3 style='color:red'>".$qr." : NOT Exist !</h3>";
	    	} else {
	    		if ($dataQr->lct == $lct) {
	    			echo "<h3 style='color:red'>".$qr." : Already Exist !</h3>";
	    		} else  {
	    			$direct = $dataQr->sub_lct;
		    		$stime =  date('Y-m-d H:i:s'); 
	    			$model = $dataQr->model;
	    			$data->cExchange($qr,$model, $lct, $sub_lct, $author, $stime,$direct,$err_name);
	    			echo "<h3 style='color:green'>".$qr." : Success</h3>";
	    		}
	    	}
    	} else if($lct == 'REPAIR'){
    		$err_name = $_POST['err_name'];
    		if (empty($dataQr) || $err_name == '') {
	    		echo "<h3 style='color:red'>".$qr.$err_name." : NOT Exist !</h3>";
	    	} else {
	    		if ($dataQr->lct == $lct) {
	    			echo "<h3 style='color:red'>".$qr." : Already Exist !</h3>";
	    		} else  {
	    			$direct = $dataQr->sub_lct;
		    		$stime =  date('Y-m-d H:i:s'); 
	    			$model = $dataQr->model;
	    			$data->cExchange($qr,$model, $lct, $sub_lct, $author, $stime,$direct,$err_name);
	    			echo "<h3 style='color:green'>".$qr." : Success</h3>";
	    		}
	    	}
    	} else {
    		if (empty($dataQr) || $dataQr->dif < 300) {
	    		echo "<h3 style='color:red'>".$qr." : NOT Exist !</h3>";
	    	} else {
	    		if ($dataQr->lct == $lct) {
	    			echo "<h3 style='color:red'>".$qr." : Already Exist !</h3>";
	    		} else {

	    			$direct = $dataQr->sub_lct;
		    		$stime =  date('Y-m-d H:i:s'); 
	    			$model = $dataQr->model;
	    			$data->cExchange($qr,$model, $lct, $sub_lct, $author, $stime,$direct,$err_name);
	    			echo "<h3 style='color:green'>".$qr." : Success</h3>";
	    		}
	    	}
    	}
    }

?>