<?php
  require('../controller/controller.php');
  date_default_timezone_set("Asia/Ho_Chi_Minh");
  $data = new cEms();
  $id = $_POST['id'];
  $inventData = $data->cGetInventById($id);
  $resInvent = json_encode($inventData);
?>
<div class="modal-header">
  <h5 class="modal-title card-title" style="color: #01b1c1;"><?php echo "Inventory: Line ". $inventData[0]->line;?></h5>
  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<div class="modal-body">
    <div class="row" id = "form_pick">  
        <div class="col-md-12">

          <table class="table table-hover table-bordered table-sm dataTable no-footer" id = "viewTable">
                <thead style="background-color: #588cc5; color: white;line-height: 15px;" class="text-center">
                    <tr>
                        <th >Code</th>
                        <th >Stock</th>
                        <th >Actual</th>
                        <th >Gap</th>
                    </tr>
                </thead>
                <tbody id="viewList">
                    
                </tbody>
            </table>
          </div>
        </div>
      </div>

<script>
  $(document).ready(function(){
    resInvent = <?php echo $resInvent; ?>;
   
      
    function tableInvent(datax){
    let example = $('#viewTable').DataTable({
      "lengthMenu": [[10, -1], [10, "All"]],
      "order": [[ 0, "desc" ]],
      "scrollY":        "200px",
      
          "scrollCollapse": true,
          "paging":         false,
      dom: 'Bfrtip',
      buttons: [
      'excel',
      'selectNone'
   
      ],
      data: datax,
      columns:[
      
      {data:"code"},

      {data:"qty"},
      {data:"qty_real"},
      {
            "data": function(row, type, set){
              let qty = parseInt(row['qty']);
              let qty_real = parseInt(row['qty_real']);
              return qty_real-qty;
            }
        }
      ],
      select: {
        style: 'multi'
      }
    });
  }
  tableInvent(resInvent);
  })
</script>