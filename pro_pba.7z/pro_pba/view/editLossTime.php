<?php
	require('../controller/controller.php');
	$data = new cEms();
	if (isset($_COOKIE['token'])) {
		$token = $_COOKIE['token'];
		$userInfo = $data->cGetUser($token);
		if (empty($userInfo)) {
      
          header("Location:../login");
          exit();
        }
	} else {
		header("Location:../login");
		exit();
	}
    $id = $_POST['arrDid'][0];
    $dataDetail = $data->cGetCauseDetail($id);
?>
<div class="modal-header">
	<h5 class="modal-title card-title" style="color: #01b1c1;">Edit Causes</h5>
	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</button>
</div>
<div class="modal-body">
    <div class="row" id = "form_pick">	
        <div class="col-md-6 showEditInfo">
            <div class="input-group input-group-sm mb-3">
                <div class = "input-group-prepend">
                    <label class="input-group-text">Line :</label>
                </div>
                <input id="line" class="form-control form-control-sm" placeholder="Line" list="arrLine"  value="<?php echo $dataDetail->line; ?>">
                
            </div>
            <div class="input-group input-group-sm mb-3">
                <div class = "input-group-prepend">
                    <label class="input-group-text">Name :</label>
                </div>
                <input id="name" class="form-control form-control-sm" placeholder="Name"  value="<?php echo $dataDetail->name; ?>">
                
            </div>
            
            <div class="input-group input-group-sm mb-3">
                <div class = "input-group-prepend">
                    <label class="input-group-text">Detail :</label>
                </div>
                <textarea id="detail" class="form-control form-control-sm" ><?php echo $dataDetail->detail; ?></textarea>
            </div>
        </div>

        <div class="col-md-6 showEditInfo">
            <div class="input-group input-group-sm mb-3">
                <div class = "input-group-prepend">
                    <label class="input-group-text">Start Time :</label>
                </div>
                <input id="start_time" type="datetime-local" class="form-control form-control-sm" placeholder="Start Time"  value="<?php echo $dataDetail->startTime; ?>">
            </div>
             <div class="input-group input-group-sm mb-3">
                <div class = "input-group-prepend">
                    <label class="input-group-text">Stop Time :</label>
                </div>
                <input id="stop_time" type="datetime-local" class="form-control form-control-sm" placeholder="Stop Time "  value="<?php echo $dataDetail->stopTime; ?>">
            </div>
            
            <div class="input-group input-group-sm mb-3">
                <div class = "input-group-prepend">
                    <label class="input-group-text">Image :</label>
                </div>
                <input id="img" type = "file" class="form-control form-control-sm" >
                <img width="5%" src="vendor/img/causes/<?php echo $dataDetail->img; ?>">
            </div>

            <button class="btn btn-success form-control" id="confirm" style = "">
                <i class="fas fa-save"></i>
                Confirm
            </button>
            <i style="color:red;margin-bottom:1em;">* Please do not close the website or reload the page before receiving the 'Success' message</i>
        </div>
	</div>
</div>
<script>
$("#confirm").click(function(){
        let dataG = new FormData();
		let i = $('#img').val();
        let id = '<?php echo $id; ?>';
        let line = $('#line').val().toUpperCase().trim();
        let name = $('#name').val().toUpperCase().trim();
        let detail = ($('#detail').val()|| '').toUpperCase().trim() ;
		let start_time = $('#start_time').val();
        let stop_time = $('#stop_time').val();
        
		if (!line || !name) {
			alert("Please check input again !")
		} else {
            dataG.append('id', id);
			dataG.append('line', line);
			dataG.append('name', name);
			dataG.append('detail', detail);
			dataG.append('start_time', start_time);
            dataG.append('stop_time', stop_time);

			if (i != '') {
				var img = $('#img').prop('files')[0];
				var typeImg = img.type;
				match = ['image/gif','image/png','image/jpg','image/jpeg'];
				if (typeImg == match[0] || typeImg == match[1] || typeImg == match[2] || typeImg == match[3]) {
					dataG.append('img', img);
				}
			}
			$.ajax({
				url : 'view/editingLossTime.php',
				dataType : 'html',
				data : dataG,
				type : 'post',
				cache : false,
				processData : false,
				contentType : false,
				success : function(res){
                    $(".close").click();
					alert(res);
					loadLossTime()
				}
			});		
		}	
	});
</script>