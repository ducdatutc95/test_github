<?php
require('../controller/controller.php');
$data = new cEms();
     if (isset($_COOKIE['token'])) {

        $token = $_COOKIE['token'];
        $userInfo = $data->cGetUser($token);
        if (empty($userInfo)) {
          echo '<div class="panel-alert"><i class="fas fa-bell i-right"></i>Do not have access to this function. Please contact admin</div>';
          exit();
        }
    } else {
        echo '<div class="panel-alert"><i class="fas fa-bell i-right"></i>Do not have access to this function. Please contact admin</div>';
        exit();
    }
    $id_plan = $_GET['id_plan'];
    $dataDetail = $data->cGetMaterialByPlan($id_plan);
    $direct = $dataDetail[0]->direct;
    $direct_2f = $userInfo->direct_2f;
    if ($direct_2f != 'ADMIN' && $direct_2f != $direct) {
      echo '<div class="panel-alert"><i class="fas fa-bell i-right"></i>Do not have access to this direct. Please contact admin</div>';
      exit();
    }
    $model_code = $dataDetail[0]->model_code;
    $i = 1;
    $countImByPlan = $data->cGetCountImByPlan($id_plan);
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>[SET] PRODUCT - Import Material</title>

  <!-- liên kết css -->
  <link href="../vendor/css/style.css" rel="stylesheet" type="text/css" >
  <link rel="shortcut icon" type="image/png" href="../vendor/img/icon.jpg"/>
  <!-- liên kết bootstrap css -->
  <link href="../vendor/bootstrap/bootstrap.min.css" rel="stylesheet" type="text/css" >
  <link href="../vendor/bootstrap/bootstrap.css" rel="stylesheet" type="text/css" >
  <link href="../vendor/bootstrap/bootstrap-datetimepicker.css" rel="stylesheet" type="text/css" >
  <!-- liên kết datatable css -->
  <link href="../vendor/datatable/dataTables.min.css" rel="stylesheet" type="text/css" />
  <!-- liên kết font css -->
  <link rel="stylesheet" href="../vendor/fontawesome/css/all.min.css">
  <link href="../vendor/datatable/buttons.dataTables.min.css" rel="stylesheet" type="text/css" />
  <link href="../vendor/datatable/select.dataTables.css" rel="stylesheet" type="text/css" />
  <link href="../vendor/chart/chartist.min.css" rel="stylesheet" type="text/css" />
    <style>
            table{
                border-collapse: collapse;
            }
            table, th{
                border:1px solid white;
            }
            table, td{
              border:1px solid black;
            }
        </style>
</head>
<div class="fixed-top">
   <nav class="navbar fixed-top navbar-expand-lg bg-light white scrolling-navbar"  style="border-bottom: 1px solid #d5d5d5;font-size:14px; ">
      <div class="container-fluid">
        <a class="navbar-brand waves-effect padding-0" href="./index" style = "text-align:center;">
          <span class = "logo-adz"><i class="fas fa-chart-bar"></i>DREAMTECH-EMS</span> </br>
        </a>
        
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="fas fa-bars" style="font-size: 1em;color: black;"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
          </ul>
          <ul class="navbar-nav mr-auto navbar-right" style="margin-right: 0 !important;display: flex;">
              <li class="nav-item menu-admin">
                <a class="nav-link waves-effect user"><i class="fa fa-user"></i><?php echo($userInfo->name); ?> </a>             
              </li>
              <li class="">
                
          </ul>
        </div>
          
      </div>
  </nav>
</div>
<div class="container" id="scan_screen">
   <div class="row" id = "form_pick">  
      <div class="col-md-12">
        <h5 class="tit-table modal-title card-title" style="width: 100%;"><i class="fa fa-flag i-right"></i>Import Material for Plan : <?php echo $dataDetail[0]->basic." / ".$dataDetail[0]->model_code." < ".$dataDetail[0]->qty_plan."ea >"; ?></h5>
        <button class="btn btn-danger" style="margin-bottom: 10px;margin-top: 10px;width:300px;float: right;" id="submit">Xác Nhận Save Data</button>
       <table id="subWare" class="table-hover" style="text-align: center;font-weight: 500;font-size: 18px;font-family:Times New Roman;width: 100%"> 
                    <thead style="font-size: 18px;" > 
                <tr> 
                    <td>No.</td>
                    <td>Model</td>
                    <td>Code</td>
                    <td>Qty Plan</td>
                    <td>Qty Recived(<?php echo $countImByPlan."Lần"; ?>)</td>
                    <td>Qty Input</td>
                </tr>
            </thead>
            <tbody>
                <?php

                    foreach ($dataDetail as $key) {
                      
                       ?>

                       <tr <?php if ($key->type != '') {
                          echo "style='background-color:#914242;color:white;'" ;
                      } ?>>
                            <td><?php echo $i++;?></td>    
                            <td><?php echo $key->model_code;?></td>
                            <td id="code" sub = "<?php echo $key->code;?>"><?php echo $key->code;?></td>
                            <td id="qty_code" sub_qty = "<?php echo $key->qty_code;?>"><?php echo $key->qty_code;?></td>  
                            <td id="qty_recive" sub_qty = "<?php if($key->qty_in>0){echo $key->qty_in;} else {echo 0;}?>"><?php if($key->qty_in>0){echo $key->qty_in;} else {echo 0;}?></td>  
                            <td><input class="inputs" type="text" style="border: none; width: 100%; color: red; text-align: center;" tabindex="<?php echo $i; ?>"></td> 
                       </tr>
                       <?php
                    }
                ?>
            </tbody>
        </table>
      </div>
    </div>
</div>
<section class="copyright" style="margin-top: 0.2em;">
  <div class="container">
    <div class="row">
      <div class="col-md-12 ">
        <div class="text-center text-black">
          &copy; System 2022 Created by 44247-TranHa.
          All Rights Reserved by DreamTech Company
        </div>
      </div>
    </div>
  </div>
</section>
<script src='../vendor/js/socket.io.js'></script>
<script src="../vendor/js/jquery.js"></script>
<script src="../vendor/js/myQuery.js"></script>
<script src="../vendor/js/tree_menu.js"></script>
<script src="../vendor/chart/chartist.min.js"></script>
<script src="../vendor/chart/utils.js"></script>
<script src="../vendor/chart/chart.bundle.min.js"></script>
<script src="../vendor/js/tree.min.js"></script>
<script src="../vendor/js/sweetalert2.all.min.js"></script>
<script src="../vendor/bootstrap/bootstrap.min.js"></script>
<script src="../vendor/datatable/dataTables.min.js"></script>
<script src="../vendor/datatable/dataTables.select.js"></script>
<script src="../vendor/datatable/dataTables.buttons.min.js"></script>
<script src="../vendor/datatable/dataTables.buttonHtml5.min.js"></script>
<script src="../vendor/datatable/buttons.flash.min.js"></script>
<script src="../vendor/datatable/jszip.min.js"></script>
<script src="../vendor/bootstrap/moment.min.js"></script>
<script src="../vendor/bootstrap/bootstrap-datetimepicker.js"></script>  
<script src="../vendor/datatable/dataTables.bootstrap4.min.js"></script> 
<script type="text/javascript">
  $(document).ready(function(){
    $('#submit').click(function(){
        let code = $("#subWare td[id=code]");
        let qty_code = $("#subWare td[id=qty_code]");
        let qty_recive = $("#subWare td[id=qty_recive]");
        let qty_in = $("#subWare input[type=text");

        let id_plan = '<?php echo $id_plan; ?>';
        let model_code = '<?php echo $model_code; ?>';
        let direct = '<?php echo $direct; ?>';
        let obj = [];
        let check = 0;
        let tit = ' Dòng : ';
        let errContent = '';

        for (let i = 0; i < code.length; i++) {
            let code_val = $(code[i]).attr('sub');
            let qty_code_val = parseFloat($(qty_code[i]).attr('sub_qty'));
            let qty_recive_val = parseFloat($(qty_recive[i]).attr('sub_qty'));
            let qty_in_val = parseFloat($(qty_in[i]).val());

            if($(qty_in[i]).val() != ''){
                if(/[^0-9\.\-]/i.test($(qty_in[i]).val())){
                    check ++;
                    tit += ','+(i+1);
                    errContent = "Sai ký tự vui lòng kiểm tra lại "
                } else if(qty_code_val - qty_recive_val < qty_in_val){
                    check ++;
                    tit += '-'+(i+1);
                    errContent = "Số lượng nhập vào tối đa là: "+(qty_code_val - qty_recive_val)
                } else {
                    obj.push({'code': code_val,'qty_in' : qty_in_val});   
                }
            }
        }
        if (check >0) {
            errAlert(errContent+tit);
        } else{
            quest('Are you sure "Save data"? !').then((result) => {
                if (result.isConfirmed) {
                    processing2()
                    $("#submit").remove();
                    $.post('importingMaterial.php', {
                        obj:obj, id_plan:id_plan,model_code:model_code,direct:direct, note:"Im by Plan", status:"OK"
                    },function(data){
                        successAlert(data);
                    });
                }
            })
        }
    })
    $('.inputs').keydown(function(e){
        if (e.which === 13) {
            var index = $('.inputs').index(this) + 1;
            $('.inputs').eq(index).focus();
            $('.inputs').eq(index).select();
        }
    });
  })
</script>
</body>
</html>