
<?php
    require('../controller/controller.php');
    date_default_timezone_set("Asia/Ho_Chi_Minh");
    $data = new cEms();
    $check = $data->cCheckToken();
    if ($check['status'] === false) {
        echo $check['data'];
    } else {
       
        $author  = $check['data']->manv;
        if (isset($_POST['detail'])) {
            $dTime = $_POST['dTime'];
			$direct = $_POST['direct'];
			$line = $_POST['line'];
			$mc = $_POST['mc'];
			$shift = $_POST['shift'];
			$kg = $_POST['kg'];
			$detail = $_POST['detail'];
			$start_time = $_POST['start_time'];
			$stop_time = $_POST['stop_time'];
			$diffTime = $_POST['diffTime'];
			$type = $_POST['type'];

            $res = $data->cAddLineTime($dTime, $direct, $line, $mc, $shift, $kg, $detail, $start_time, $stop_time, $diffTime, $type, $author);
            echo $res;
        } else {
            echo "Failed";
        }
    }
    
?>