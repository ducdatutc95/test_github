<?php
	require('../controller/controller.php');
	$data = new cEms();
	if (isset($_COOKIE['token'])) {
		$token = $_COOKIE['token'];
		$userInfo = $data->cGetUser($token);
		if (empty($userInfo)) {
      
          header("Location:../login");
          exit();
        }
	} else {
		header("Location:../login");
		exit();
	}
$arrErr = ["LOANG, BAN GATE MOLDING","TRAN KEO CIC","NHAN CIC","FPCB DAM LEAK (TREN)","FPCB DAM LEAK (DUOI)","BUI MOLDING","DI VAT MOLDING","THIEU GATE","NHAN MOLDING","BENG KHI MOLDING","LVDT","TRAN KEO MOLDING (TREN)","TRAN KEO MOLDING (DUOI)","THIEU KEO MOLDING","BIEN DANG MOLDING","LEM BONDING","NHAN TAPE FPCB","GATE DAM LEAK","DAM BONDING","GATE BURR","RISK OCTA","GREEN BLOCK DOT","BIT UB","MUNG UB","KHENG LAN NGUON","NG FINGER","FODORMALS CAB","CHAM DEN OCTA","LOANG OCTA","NG BARCODE","ME OCTA","VO OCTA","XUOC OCTA","CRACK FPCB","HAN CUSHEET","CRACK CIC","DÂM CUSHEET","TSP","DAM OVER","BAN LCD","MUN MOLDING","BONG MOLDING","BIEN DANG LINH KIEN","NHAY, NHIEU LCD","BONG SON LCD","LEM MOLDING","LEM CUSHEET","DI VAT CIC"];
$resErr = json_encode($arrErr);

?>
<div class="modal-header">
	<h5 class="modal-title card-title" style="color: #01b1c1;">Additional Location</h5>
	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</button>
</div>
<div class="modal-body">
    <div class="row" id = "form_pick">	
        <div class="col-md-6 showEditInfo">
            <div class="input-group input-group-sm mb-3">
                <div class = "input-group-prepend">
                    <label class="input-group-text">Location :</label>
                </div>
                <input id="lct" class="form-control form-control-sm" placeholder="Location"">

            </div>
            <div class="input-group input-group-sm mb-3">
                <div class = "input-group-prepend">
                    <label class="input-group-text">Error Name :</label>
                </div>
                <input id="err_name" class="form-control form-control-sm" placeholder="Err Name" list="arrErr">
                <datalist id="arrErr">
                <?php 
                    foreach ($arrErr as $key) {
                        echo "<option value='".$key."'>".$key."</option>";
                    }
                    
                 ?>
                    
              </datalist>
            </div>
            
            
        </div>

        <div class="col-md-6 showEditInfo">
            <button class="btn btn-success form-control" id="confirm">
                <i class="fas fa-save"></i>
                Confirm
            </button>
            <i style="color:red;margin-bottom:1em;">* Please do not close the website or reload the page before receiving the 'Success' message</i>
        </div>
	</div>
</div>
<script>
$("#confirm").click(function(){
        errList = <?php echo $resErr; ?>;
        let lct = $('#lct').val().toUpperCase().trim();
        let err_name = $('#err_name').val().toUpperCase().trim();
        let check = errList.find(e=>e==err_name)
		if (!lct || !err_name) {
			alert("Please check input again !")
		} else {
			$.post('view/pAddLct.php',{
                lct:lct,err_name:err_name
              }, function(data) {
                successAlert(data)
              });
		}	
	});
</script>