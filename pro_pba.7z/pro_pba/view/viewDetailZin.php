<?php
    require('../controller/controller.php');
    date_default_timezone_set("Asia/Ho_Chi_Minh");
    $data = new cEms();
    $check = $data->cCheckToken();
    $arrId = $_POST['arrDid'];
    if ($check['status'] === false) {
        echo $check['data'];
    } else {
        $ar = "('".implode("','",$arrId)."')";
        $result = $data->cGetDetailZin($ar);
    }
    $resFinal = json_encode($result);
?>

<div class="modal-header">
    <h5 class="modal-title card-title" style="color: #01b1c1;">View Zin Detail</h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<div class="modal-body">
    <div class="row" id = "form_pick">  
        <div class="col-md-12">
            <table class="table table-hover table-bordered table-sm dataTable no-footer" id = "bomTable">
                <thead style="background-color: #588cc5; color: white;line-height: 15px;" class="text-center">
                    <tr>

                    <th >Zin</th>
                    <th >QR</th>
                    <th >Model</th>
                    <th >Time</th>
                    </tr>
                </thead>
                <tbody id="BomList">
                    
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
  
$(document).ready(function(){
    resFinal = <?php echo $resFinal; ?>;
    arrDid = [];
    function tableFinal(datax){
        let example = $('#bomTable').DataTable({
            "lengthMenu": [[10, -1], [10, "All"]],
            "order": [[ 3, "desc" ]],
            "scrollY":        "200px",
            
            "scrollCollapse": true,
            "paging":         false,
            dom: 'Bfrtip',
            buttons: [
            'excel',
            'copy'
            ],
            data: datax,
            columns:[
            
            {data:"zin"},
            {data:"qr"},
            {data:"model"},
            {data:"sTime"}
            ],
            select: {
                style: 'multi'
            }
        });
        
    }
    tableFinal(resFinal);
})
</script>