<?php
require('../controller/controller.php');
date_default_timezone_set("Asia/Ho_Chi_Minh");
$data = new cEms();
$line_filter = $_POST['line_filter'];
$model_filter = $_POST['model_filter'];
$dateStart = $_POST['dateStart'];
$dateEnd = $_POST['dateEnd'];

$finalData = $data->cGetPlanFromMes($line_filter, $model_filter, $dateStart, $dateEnd);
$resFinal = json_encode($finalData);

$finalRemain = $data->cGetQtyProd($line_filter, $model_filter);
$resRemain = json_encode($finalRemain);

$resModel = $data->cGetModelUnique($line_filter, $dateStart, $dateEnd);
$arrModel = json_encode($resModel);

// $fujiData = $data->cGetDataFuji($line_filter);
// $shift = 'DAY';
// if (date('H') > 19 || date('H') < 8) {
//     $shift = 'NIGHT';
// }
// $s = strtotime("-8 Hour");
// $sDate = date('Y-m-d', $s);
// // $finalTotal = $data->cGetTotalLine($line_filter);

// $detail = $data->cGetDetailPlanFromMes($line_filter, $shift, $sDate);

// // $resTotal = json_encode($finalTotal);
// $resDetail = json_encode($detail);
// $resFuji = json_encode($fujiData);



$arrLine = array();
for ($i = 1; $i <= 32; $i++) {

    $line = ($i < 10 ? '0' . $i : $i);
    $arrLine[] = (object)['line' => $line];
}

for ($i = 1; $i <= 7; $i++) {

    $line = ($i < 10 ? 'EMS-0' . $i : "EMS-" . $i);
    $arrLine[] = (object)['line' => $line];
}

for ($i = 1; $i <= 7; $i++) {

    $line = ($i < 10 ? 'DMC-0' . $i : "DMC-" . $i);
    $arrLine[] = (object)['line' => $line];
}
// print_r($arrLine);
?>

<style>
    .dd__change_Model_title {
        font-size: 24px;
        display: flex;
        align-items: center;
        transition: margin-left linear 0.3s;
    }

    .dd__change_Model_title:hover {
        margin-left: 6px;
    }

    .dd__change_Model_title label {
        user-select: none;
        cursor: pointer;
        color: #333;
    }

    .dd__change_Model_title input {
        margin-left: 10px;
        cursor: pointer;
        transform: scale(1.4);
    }
</style>

<div class="col-md-12">
    <table class="table table-hover table-bordered table-sm dataTable no-footer" id="finalTable">
        <thead style="background-color: #588cc5; color: white;line-height: 15px;" class="text-center">
            <tr>
                <th>ID</th>
                <th>Direct</th>
                <th>Model</th>
                <th>Basic</th>
                <th>Plan</th>
                <th>Đã sản xuất</th>
                <th>Plan Date</th>
                <th>Shift</th>
            </tr>
        </thead>
        <tbody id="finalList">
        </tbody>
    </table>
</div>


<script>
    $(document).ready(function() {
        var resFinal = <?php echo $resFinal; ?>;
        var resRemain = <?php echo $resRemain; ?>;

        var arrDid = [];

        function tableFinal(datax) {
            let example = $('#finalTable').DataTable({
                "lengthMenu": [
                    [10, -1],
                    [10, "All"]
                ],
                "order": [
                    [6, "desc"],
                    [7, "asc"]
                ],

                "scrollCollapse": true,

                "scrollY": "100px",

                "paging": false,

                dom: 'Bfrtip',
                buttons: [
                    'excel',
                    'selectNone',
                    {
                        text: ' <i class="fas fa-check i-right" style="color:red;"></i>Check',
                        className: 'btnPractice',
                        action: function(e, dt, node, config) {
                            if (arrDid.length != 2) {
                                errAlert("Please! Select only 2 row");
                            } else {
                                var idPlanBefore = arrDid[0];
                                var idPlanAfter = arrDid[1];

                                var checkExist = resFinal.find(e => {
                                    return e.id_plan == idPlanBefore;
                                })

                                var line = '';
                                if(checkExist != null ) {
                                    line = checkExist['line'];
                                }

                                var dataSend = "IdOld=" + idPlanBefore + "&IdNew=" + idPlanAfter + "&line="+line;

                                window.open("view/compareModel.php?" + dataSend, "_blank");
                            }
                        },
                    }
                ],
                data: datax,

                columns: [

                    {
                        data: "id_plan"
                    },
                    {
                        data: "line"
                    },
                    {
                        data: "model"
                    },
                    {
                        data: "basic"
                    },
                    {
                        data: "qty"
                    },
                    {
                        "data": function(row, type, set) {
                            let id_plan = row['id_plan'];
                            let qty_pro = resRemain.find(e => e.id_plan == id_plan)
                            if (qty_pro != undefined) {
                                return qty_pro.qty_out
                            } else {
                                return 0
                            }

                        }
                    },
                    {
                        data: "sDate"
                    },
                    {
                        data: "shift"
                    },
                ],
                select: {
                    style: 'multi'
                }
            });
            example
                .on('select', function(e, dt, type, indexes) {
                    var rowData = example.rows(indexes).data().toArray();
                    for (var i = 0; i < rowData.length; i++) {
                        var x = arrDid.indexOf(rowData[i]['id_plan']);
                        if (x === -1) //neu ko ton tai
                            arrDid.unshift(rowData[i]['id_plan']); //thi push 
                        // console.log(arrDid)
                    }
                })
                .on('deselect', function(e, dt, type, indexes) {
                    var rowDataUn = example.rows(indexes).data().toArray();
                    for (var i = 0; i < rowDataUn.length; i++) {
                        var x = arrDid.indexOf(rowDataUn[i]['id_plan']);
                        arrDid.splice(x, 1);
                    }
                });
        }

        tableFinal(resFinal);
    })
</script>