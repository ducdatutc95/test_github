<?php
	require('../controller/controller.php');
	$data = new cEms();

	$dTime = $_POST['dTime'];
	$date = date($dTime." 08:00:00");
	$dateE = date('Y-m-d H:i:s', strtotime($date . ' +1 day'));
	$direct = $_POST['direct'];
	$listFilterDirect = "^".implode("|^",$_POST['listFilterP']);
    $finalData = $data->cGetUbTracking($listFilterDirect,$date,$dateE);

    $timeLineData = $data->cGetTimeLine($direct,$listFilterDirect,$date,$dateE);
    $arrMc = $data->cGetLineConfig($direct,$listFilterDirect,$date,$dateE);
    $arrModel = $data->cGetModelLcd();
    $arrLine = $_POST['listFilterP'];
    $resFinal = json_encode($finalData);
    $resTimeLine = json_encode($timeLineData);
    $resMc = json_encode($arrMc);
    $resModel = json_encode($arrModel);
    $resLine = json_encode($arrLine);
?>
	<div class="row mg0">
		<?php 
			for ($i=1; $i <= count($_POST['listFilterP']); $i++) { 
				?>
				<div class="col-md-6">
					<canvas id="<?php echo 'Line '.$_POST['listFilterP'][$i-1]; ?>" style="margin-top: 1em; width: 100%;"></canvas> 
					<h3><?php echo "LINE: ".$_POST['listFilterP'][$i-1]." Production Rate (%)"; ?></h3>
				</div>
				<?php
			}
		 ?>
		<button class="btn btn-light btn-sm appy-filter form-control" id="next"><i class="fa fa-play i-right"></i>Next</button>
		
	</div>
    <script>
		$(document).ready(function(){
			$('#next').click(function(){
				window.clearTimeout(timer);
				loadS921Mc2(listFilterP);
			});
			timer = window.setTimeout(function(){
				if (pause_play == 1) {
		          loadS921Mc2(listFilterP);
		      	}
		     }, 50000)
			let resFinal = <?php echo $resFinal; ?>;
			let resTimeLine = <?php echo $resTimeLine; ?>;
			let resLine = <?php echo $resLine; ?>;
			let resModel = <?php echo $resModel; ?>;
			let resMachine = <?php echo $resMc; ?>;
			let resType = ['INPUT','OUT'];
			let resM = ["A","B","C","D","E"]
			let resShift = ["D","N"]
			let resRow = ['Actual','Rate']
			let html = ""
			let direct = '<?php echo $direct; ?>';
			let dTime = '<?php echo $dTime; ?>';
			
			// let data = []
			for (let i = 0; i < resFinal.length; i++) {
				let time = new Date(resFinal[i].sTime)
				let t = time.getHours();
				let pn = resFinal[i].pn
				let mc = resFinal[i].mc
				let line = resFinal[i].line
				let direct = resFinal[i].direct
				let m = ''
				let shift = ''

				if (t>=8 && t < 10 || t>=20 && t < 22) {
					m = 'A'
					if (t>=8 && t < 10) {
						shift = "D"
					} else {
						shift = "N"
					}
				} else if (t>=10 && t < 13 || t>=22 || t < 1){
					m = 'B'
					if (t>=10 && t < 13) {
						shift = "D"
					} else {
						shift = "N"
					}
				} else if (t>=13 && t < 15 || t>=1 && t < 3){
					m = 'C'
					if (t>=13 && t < 15) {
						shift = "D"
					} else {
						shift = "N"
					}
				} else if (t>=15 && t < 17 || t>=3 && t < 5){
					m = 'D'
					if (t>=15 && t < 17) {
						shift = "D"
					} else {
						shift = "N"
					}
				} else if (t>=17 && t < 20 || t>=5 && t < 8){
					m = 'E'
					if (t>=17 && t < 20) {
						shift = "D"
					} else {
						shift = "N"
					}
				}
				resFinal[i].m = m
				resFinal[i].shift = shift
			}
			let dataChart=[]
			for (let i = 0; i < resLine.length; i++) {
				let line = resLine[i]
				dataChart[i] = {"line":"Line "+line,"data":[]}
				for (let j = 0; j < resType.length; j++) {
					let arrActual=[]
					let arrTarget=[]
					
					let mc = resType[j]
					let tt = 12
					let model = 'S921'

					let tagetTotal = 0
					dataChart[i].data[j] = {"mc": mc,"rate":[],"actual":[]}
					for (let s = 0; s < resShift.length; s++) {
						let sub_total = 0
						let shift = resShift[s]
						for (let n = 0; n < resM.length; n++) {
							let kg = resM[n]
							let target
							let timeLine = resTimeLine.filter(e=>e.direct == direct && e.line == line && e.proc == mc && e.shift == shift && e.kg == kg && e.type == 'CAL')
							let sumCal = timeLine.reduce((accumulator, e) => {
							  return accumulator + parseInt(e.diff);
							}, 0);
							if (n == 1 || n == 3) {
								target = (6600-sumCal/1000)/parseInt(tt)
							}else if (n == 4) {
								if (sumCal>0) {
									target = (10800-sumCal/1000)/parseInt(tt)
								} else {
									target = (7200-sumCal/1000)/parseInt(tt)
								}
								
							} else {
								target = (7200-sumCal/1000)/parseInt(tt)
							}
							if (target <= 0) {
								target = 0
							} 

							arrTarget.push(target)
						}
					}
					
					for (let k = 0; k < resRow.length; k++) {
						let row = resRow[k]
						if (k%2 == 0) {
							let actualTotal = 0
							for (let s = 0; s < resShift.length; s++) {
								let shift = resShift[s]
								let sub_total = 0
								
								for (let l = 0; l < resM.length; l++) {
									let m = resM[l]
									let actual = resFinal.filter(e=>e.line == line && e.status == mc && e.shift == shift && e.m == m)
									arrActual.push(parseInt(actual.length))
								}
							}

						} else {
							for (let f = 0; f < arrActual.length; f++) {
								let acc = arrActual[f]
								let tar = arrTarget[f]
								let rate = Math.round(parseInt(acc)/parseInt(tar)*1000)/10
								if (!rate || isNaN(rate) || !isFinite(rate)) {
									rate = 0
								}
								dataChart[i].data[j].rate[f] = rate
								dataChart[i].data[j].actual[f] = acc
							}
						}
					}
				}
				
			}
			console.log(dataChart)
			for (let i = 0; i < dataChart.length; i++) {
				let onl = dataChart[i]
				Chart.register(ChartDataLabels);
			    const ctx = document.getElementById(onl.line).getContext('2d');
			    
			    const myChart = new Chart(ctx, {
			        type: 'bar',
			        data: {
			            labels: ["DAY-A","DAY-B","DAY-C","DAY-D","DAY-E","NIGHT-A","NIGHT-B","NIGHT-C","NIGHT-D","NIGHT-E"],
			            datasets: [
				            {
				                label: onl.data[0].mc,
				                // yAxisID: 'A',
				                data: onl.data[0].actual,
							      borderColor: 'rgb(101 165 171 / 44%)',
						      		backgroundColor: 'rgb(101 165 171 / 44%)',
							      // fill: true,
							      borderWidth: 1,
							      // pointStyle: 'rectRot',
							      // pointRadius: 5,
							      pointBorderColor: 'rgb(255, 0, 0)'
				            },
				            {
				                label: onl.data[1].mc,
				                // yAxisID: 'A',
				                data: onl.data[1].actual,
							      borderColor: 'rgb(225 155 49 / 44%)',
						      		backgroundColor: 'rgb(225 155 49 / 44%)',
							      // fill: true,
							      borderWidth: 1,
							      // pointStyle: 'rectRot',
							      // pointRadius: 5,
							      pointBorderColor: 'rgb(255, 0, 0)'
				            },
				            {
				                label: onl.data[0].mc,
				                // yAxisID: 'B',
				                data: onl.data[0].rate,
							      borderColor: 'rgb(101 165 171)',
							      backgroundColor: 'rgb(101 165 171)',
							      // fill: true,
							      type :'line',
							      borderWidth: 3,
							      // pointStyle: 'rectRot',
							      // pointRadius: 5,
							      // pointBorderColor: 'rgb(255, 0, 0)'
				            },
				            {
				                label: onl.data[1].mc,
				                // yAxisID: 'B',
				                data: onl.data[1].rate,
							      borderColor: 'rgb(225 155 49)',
							      backgroundColor: 'rgb(225 155 49)',
							      type :'line',
							      borderWidth: 3,
							      display: false
				            }
			            ]
			        },
			        options: {
			        	scales: {
			        	// 	yAxes: [{
						      //   id: 'A',
						      //   type: 'linear',
						      //   position: 'left',
						      //   min:0,
						      //   max:1000
						      // }, {
						      //   id: 'B',
						      //   type: 'linear',
						      //   position: 'right',

						      // }],
						    y: {
						      beginAtZero: true          
						    }
						  },
			        	maintainAspectRatio: true,
				        responsive: true,
				        plugins: {
				            datalabels: { // This code is used to display data values
				                anchor: 'end',
				                align: 'top',
				                // formatter: Math.round,
				                font: {
				                    // weight: 'bold',
				                    size: 12,
				                }
				            }
				        }
				        
			        }
			    });
			}
		})
	</script>
