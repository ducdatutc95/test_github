<?php
  require('../vendor/Classes/PHPExcel.php');
  require('../controller/controller.php');
    date_default_timezone_set("Asia/Ho_Chi_Minh");
    $data = new cEms();
    $author  = $_POST['author'];
    ini_set('memory_limit','4095M');
    ini_set('max_execution_time', 6000);
  $file = $_FILES['img']['tmp_name'];
  $objreader = PHPExcel_IOFactory::createReaderForFile($file); // tạo đối tượng reader
  $objreader->setLoadSheetsOnly('Sheet1');//
  $objExcel = $objreader->load($file);
  $sheetData = $objExcel->getActiveSheet()->toArray('null',true,true,true);

  // lấy dòng cao nhất trong file
  $highestRow = $objExcel->setActiveSheetIndex()->getHighestRow();
  $arrData = [];
  $data->cDelBom();
  for($row = 2; $row<=$highestRow; $row++){
     $basic = $sheetData[$row]['A'];
      $model_code = $sheetData[$row]['B'];
      $process = $sheetData[$row]['C'];
      $code = $sheetData[$row]['D'];
      $desc = $sheetData[$row]['E'];    
      $qty = $sheetData[$row]['F'];
      $type = $sheetData[$row]['G'];    
      // $data->cUpBom($basic, $model_code, $process, $code, $desc,$qty,$author,$type);
  }
  $objExcel->disconnectWorksheets();
  unset($objExcel);
  echo "Success";
?>