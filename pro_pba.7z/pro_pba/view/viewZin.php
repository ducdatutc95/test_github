<?php
	require('../controller/controller.php');
	$data = new cEms();
	$line_filter = $_POST['line_filter'];
	$model_filter = $_POST['model_filter'];
	$dateStart = $_POST['dateStart'];
	$dateEnd = $_POST['dateEnd'];
	$listFilterProcess = "^".implode("|^",$_POST['listFilterP']);
    $finalData = $data->cGetZin($dateStart,$dateEnd);
    $resFinal = json_encode($finalData);
?>
<div class="col-md-12">
    <table class="table table-hover table-bordered table-sm dataTable no-footer" id = "finalTable">
        <thead style="background-color: #588cc5; color: white;line-height: 15px;" class="text-center">
            <tr>
                <th >Code</th>
                <th >Qty</th>
                <th >Model</th>
                <th >Author</th>
                <th >Status</th>
                <th >Time</th>
            </tr>
        </thead>
        <tbody id="finalList">
        </tbody>
    </table>
</div>
<script>
$(document).ready(function(){
	resFinal = <?php echo $resFinal; ?>;

	arrDid = [];
	let socket
	socket = io.connect('http://107.127.36.6:9001',{ transports : ['websocket'] });
	function tableFinal(datax){
		let example = $('#finalTable').DataTable({
			"lengthMenu": [[10, -1], [10, "All"]],
			"order": [[ 5, "desc" ]],
			"scrollY":        "200px",
			
	        "scrollCollapse": true,
	        "paging":         false,
			dom: 'Bfrtip',
			buttons: [
				'excel',
				'selectNone',
	           	{
	                text: ' <i class="fas fa-list i-right" style="color:red;"></i>Scan Input',
	                className: 'btnPractice',
	                action: function ( e, dt, node, config ) {
					    window.open("view/pickPro.php", "_blank", "scrollbars=yes,resizable=yes,top=0");

	           		}
	           	},
	           	{
	                text: ' <i class="fas fa-eye i-right" style="color:red;"></i>View',
	                className: 'btnPractice',
	                action: function ( e, dt, node, config ) {
	                	$.post('view/viewDetailZin',  
				            {arrDid:arrDid},
				            function(data){
				            $("#modal-content").html(data);
				            $('#exampleModal').modal('show');
				        });
	           		}
	           	},
	           	{
	                text: ' <i class="fas fa-print i-right" style="color:red;"></i>Print',
	                className: 'btnPractice',
	                action: function ( e, dt, node, config ) {
	                	if(arrDid.length !=  1){
					        alert("Please! Select only 1 row");
					    }else{
		                	quest('Are you sure "Cancel Zin"? !').then((result) => {
					        	if (result.isConfirmed) {
					        		let input = ["print_zin","print_zin_vp"]

								    let d = datax.find(e=>e.zin == arrDid[0])
								    d.type = 'IN'

								    socket.emit("print_box",{"zin":d.zin,"qty_box": d.qty, "sub_lct": d.sub_lct,"lct":"LINE","model":d.model,"author":d.author,"type":"IN","printer_name":"print_zin"});
								    successAlert("Printing!")
								}
							})
		                }

	           		}
	           	},
	           	{
	                text: ' <i class="fas fa-trash i-right" style="color:red;"></i>Cancel',
	                className: 'btnPractice',
	                action: function ( e, dt, node, config ) {
	                	quest('Are you sure "Cancel Zin"? !').then((result) => {
				        	if (result.isConfirmed) {
							    $.post('view/cancelZin',  
					                {arrDid:arrDid},
					                function(data){
					                successAlert(data)
					                loadZin(listFilterP)
					            }); 
							}
						})

	           		}
	           	},
			],
			data: datax,
			columns:[
			
			{data:"zin"},
			{data:"qty"},
			{data:"model"},
			{data:"author"},
			{
		        "data": function(row, type, set){
		          let status = row['status'];
		          if (status == 1) {
		            return 'Pending';
		          }else if (status == 2) {
		            return 'Recived';
		          } else {
		          	return 'Cancel';
		          }
		        }
		      },
			{data:"sTime"}
			],
			select: {
				style: 'multi'
			}
		});
		example
		.on( 'select', function ( e, dt, type, indexes ) {
			var rowData = example.rows( indexes ).data().toArray();
			for (var i = 0; i < rowData.length; i++) {
				var x = arrDid.indexOf(rowData[i]['zin']);
				if (x === -1) //neu ko ton tai
					arrDid.unshift(rowData[i]['zin']); //thi push 
                // console.log(arrDid)
			}
		} )
		.on( 'deselect', function ( e, dt, type, indexes ) {
			var rowDataUn = example.rows( indexes ).data().toArray();
			for (var i = 0; i < rowDataUn.length; i++) {
				var x = arrDid.indexOf(rowDataUn[i]['zin']);
				arrDid.splice(x, 1);
			}
		});
	}
	tableFinal(resFinal);
})
</script>