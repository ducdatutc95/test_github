<?php
	require('../controller/controller.php');
	$data = new cEms();
	if (isset($_COOKIE['token'])) {
		$token = $_COOKIE['token'];
		$userInfo = $data->cGetUser($token);
		if (empty($userInfo)) {
      
          header("Location:../login");
          exit();
        }
	} else {
		header("Location:../login");
		exit();
	}

	$direct = $_POST['direct'];
	$line = $_POST['line'];
	$mc = $_POST['mc'];
	$shift = $_POST['shift'];
	$kg = $_POST['kg'];
	$dTime = $_POST['dTime'];
	$type = 'LOSS';
	$date = date($dTime." 08:00:00");
    $dateE = date('Y-m-d H:i:s', strtotime($date . ' +1 day'));
	$timeCal = $data->cGetCal($direct,$line,$mc,$shift,$kg,$type,$date,$dateE);
	$resFinal = json_encode($timeCal);
?>
<div class="modal-header">
	<h5 class="modal-title card-title" style="color: #01b1c1;">Machine Calender : <?php echo $direct." Line: ".$line." Machine: ".$mc." Shift:".$shift." Time: ".$kg; ?></h5>
	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</button>
</div>
<div class="modal-body">
    <div class="row" id = "form_pick">	
        <div class="col-md-8 showEditInfo">
            <table class="table table-hover table-bordered" id="calenz"  style="font-size: 14px;width: 100%;">
                <thead style="background-color: #01b1c1; color: white;line-height: 15px;" class="text-center">
                <tr>
                    <th>ID</th>
                    <th>Start</th>
                    <th>End</th>
                    <th>Diff</th>
                    <th>Detail</th>
                    <th>Author</th>
                </tr>
            </thead>
            <tbody>
                
            </tbody>
        </table>
        </div>

        <div class="col-md-4 showEditInfo">
            <div class="input-group input-group-sm mb-3">
                <div class = "input-group-prepend">
                    <label class="input-group-text">Start Time :</label>
                </div>
                <input id="start_time" type="datetime-local" class="form-control form-control-sm" placeholder="Start Time" >
            </div>
             <div class="input-group input-group-sm mb-3">
                <div class = "input-group-prepend">
                    <label class="input-group-text">Stop Time :</label>
                </div>
                <input id="stop_time" type="datetime-local" class="form-control form-control-sm" placeholder="Stop Time " >
            </div>
            
            <div class="input-group input-group-sm mb-3">
                <div class = "input-group-prepend">
                    <label class="input-group-text" >Remark :</label>
                </div>
                <textarea id="detail" class="form-control form-control-sm" rows="6"></textarea>
            </div>

            <button class="btn btn-success form-control" id="confirm" style = "">
                <i class="fas fa-save"></i>
                Save
            </button>
            <i style="color:red;margin-bottom:1em;">* Please do not close the website or reload the page before receiving the 'Success' message</i>
        </div>
	</div>
</div>
<script>
    $(document).ready(function(){
        let direct = '<?php echo $direct;?>';
        let line = '<?php echo $line;?>';
        let mc = '<?php echo $mc;?>';
        let shift = '<?php echo $shift;?>';
        let kg = '<?php echo $kg;?>';
        let dTime = '<?php echo $dTime;?>';
        let dTimeLast = new Date('<?php echo $dTime;?>');
        dTimeLast.setDate(dTimeLast.getDate() + 1)
        let dTime1 = formatDateYmd(dTimeLast)
        let time1 = ''
        let time2 = ''
        if (shift=='D') {
            if (kg == 'A') {
                time1 = dTime+' 08:00:00'
                time2 = dTime+' 10:00:00'
            } else if(kg == 'B'){
                time1 = dTime+' 10:10:00'
                time2 = dTime+' 13:00:00'
            } else if(kg == 'C'){
                time1 = dTime+' 13:00:00'
                time2 = dTime+' 15:00:00'
            } else if(kg == 'D'){
                time1 = dTime+' 15:10:00'
                time2 = dTime+' 17:00:00'
            } else if(kg == 'E'){
                time1 = dTime+' 17:00:00'
                time2 = dTime+' 20:00:00'
            }
        } else {
            if (kg == 'A') {
                time1 = dTime+' 20:00:00'
                time2 = dTime+' 22:00:00'
            } else if(kg == 'B'){
                time1 = dTime+' 22:10:00'

                time2 = dTime1+' 01:00:00'
            } else if(kg == 'C'){
                time1 = dTime1+' 01:00:00'
                time2 = dTime1+' 03:00:00'
            } else if(kg == 'D'){
                time1 = dTime1+' 03:10:00'
                time2 = dTime1+' 05:00:00'
            } else if(kg == 'E'){
                time1 = dTime1+' 05:00:00'
                time2 = dTime1+' 08:00:00'
            }
        }
        $('#start_time').val(time1)
        $('#stop_time').val(time2)
        console.log(time1)
        $("#confirm").click(function(){
            let detail = ($('#detail').val()|| '').toUpperCase().trim() ;
    		let start_time = $('#start_time').val();
            let stop_time = $('#stop_time').val();
            let diffTime = Math.abs(new Date(stop_time) - new Date(start_time));
            
            if (detail == '') {
                errAlert("Check Remark Input again !")
            } else if(diffTime <= 0 || new Date(time1)>new Date(start_time) || new Date(stop_time)>new Date(time2)) {
                errAlert("Check Date Time Input again !")
            } else {
                $("#confirm").remove();
                $.post('view/addingLineTime', 
                    {dTime:dTime,direct:direct,line:line,mc:mc,shift:shift,kg:kg,detail:detail,start_time:start_time,stop_time:stop_time,diffTime:diffTime,type:"LOSS"}, 
                function(data){
                    $(".close").click();
                    successAlert(data);
                });
            }

    	});

    	resFinal = <?php echo $resFinal; ?>;
    arrDid = [];
    function tableFinal(datax){
        let example = $('#calenz').DataTable({
            "lengthMenu": [[10, -1], [10, "All"]],
            "order": [[ 3, "desc" ]],
            
            "scrollCollapse": true,
            "paging":         false,
            dom: 'Bfrtip',
            buttons: [
                'excel',
                'selectNone',
                
                {
                    text: ' <i class="fas fa-trash i-right" style="color:red;"></i>Delete',
                    className: 'btnPractice',
                    action: function ( e, dt, node, config ) {
                        quest('Are you sure "Delete this"? !').then((result) => {
                            if (result.isConfirmed) {
                                $.post('view/deleteTimeLine',  
                                    {arrDid:arrDid},
                                    function(s){
                                    successAlert(s)
                                }); 
                            }
                        })

                    }
                },
            ],
            data: datax,
            columns:[
            
            {data:"id"},
            {data:"start_time"},
            {data:"end_time"},
            {
                "data": function(row, type, set){
                    let ml = row["diff"];
                    return parseInt(ml)/1000/60
                }
            },
            {data:"detail"},
            {data:"author"}
            ],
            select: {
                style: 'multi'
            }
        });
        example
        .on( 'select', function ( e, dt, type, indexes ) {
            var rowData = example.rows( indexes ).data().toArray();
            for (var i = 0; i < rowData.length; i++) {
                var x = arrDid.indexOf(rowData[i]['id']);
                if (x === -1) //neu ko ton tai
                    arrDid.unshift(rowData[i]['id']); //thi push 
                // console.log(arrDid)
            }
        } )
        .on( 'deselect', function ( e, dt, type, indexes ) {
            var rowDataUn = example.rows( indexes ).data().toArray();
            for (var i = 0; i < rowDataUn.length; i++) {
                var x = arrDid.indexOf(rowDataUn[i]['id']);
                arrDid.splice(x, 1);
            }
        });
    }
    tableFinal(resFinal);
    });
</script>