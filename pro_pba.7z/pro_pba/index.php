<?php
include('header.php');
$listModel = $data->cGetListModel();
?>

<body>
   <div class="container-fluid">
    <div class="row main-bar">
      <div class="location">
        <i class="fa fa-map-marker i-right" style="color:red;"> </i><span>PRODUCTION >> [SET] Octa QR Code - Stock Management</span>
        
      </div>
      <div class="bar-center">

      </div>
      <div class="option_box">
      </div>
    </div>
      <div class="row">
        <div class="mg0 left-filter" id="left-filter">
          
          <div class="panel panel-primary">
            <div class="panel-heading">
              <i class="fas fa-filter i-right"></i>Filters
            </div>
            <div class="panel-body filters-plan">
              <label>Barcode :</label>
             <input type="text" id="qr_filter" class="form-control form-control-sm">
            <label>Line :</label>
             <select id="line_filter" class="form-control form-control-sm">
                    <option></option>
                    <?php
                        for ($i=1; $i <= 7; $i++) { 
                           echo '<option value="'.($i < 10 ? 'DMC-0'.$i : "DMC-".$i).'">Line '.($i < 10 ? 'DMC-0'.$i : "DMC-".$i).'</option>';
                        }
                        for ($i=1; $i <= 7; $i++) { 
                           echo '<option value="'.($i < 10 ? 'EMS-0'.$i : "EMS-".$i).'">Line '.($i < 10 ? 'EMS-0'.$i : "EMS-".$i).'</option>';
                        }
                    ?>
                    <option value="01" selected>Line 01</option>
                    <?php
                        for ($i=2; $i <= 32; $i++) { 
                           echo '<option value="'.($i < 10 ? '0'.$i : $i).'">Line '.($i < 10 ? '0'.$i : $i).'</option>';
                        }
                    ?>
                </select>
            <label>Model Code :</label>
             <input type="text" id="model_filter" class="form-control form-control-sm" list="arrCode">
               <datalist id="arrCode">
                <?php
                foreach ($listModel as $key) {
                  ?>
                      <option value="<?php echo $key->model_code; ?>"><?php echo $key->model_code; ?></option>
                  <?php
                  }
                ?>
              </datalist>
          <label>Diff Times(hour) :</label>
             <input type="text" id="diffTime" class="form-control form-control-sm">
             <label>Limit :</label>
             <input type="text" id="limit" class="form-control form-control-sm" value="100">
            </div>
            
               
          </div>
          <button class="btn btn-primary btn-sm appy-filter form-control" id="apply"><i class="fa fa-check i-right"></i>Apply</button>
        </div>
        <div class="body-right mg0">

          <div class="mgl-5 data-content">

            <div class="panel panel-primary">
              <div class="panel-heading-content">
                <div class="title_box">
                  <i class="fas fa-info-circle i-right"></i>[SET] Octa QR Code - Stock Management
                </div>
              </div>
              <div class="panel-body-content row" id="show">
              </div>
            </div>
          </div>
        </div>
      </div>
   </div>
   
<?php
include('footer.php');
?>
<script type="text/javascript">
  $(document).ready(function(){
      loadStock()
      $('#apply').click(function(){
        loadStock()
      });
  })
</script>

