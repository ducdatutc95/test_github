<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>SET MAIN</title>

  <!-- liên kết css -->
  <link href="./vendor/css/style.css" rel="stylesheet" type="text/css" >
  <link rel="shortcut icon" type="image/png" href="./vendor/img/logo.jpg"/>
  <!-- liên kết bootstrap css -->
  <link href="./vendor/bootstrap/bootstrap.min.css" rel="stylesheet" type="text/css" >
  <link href="./vendor/bootstrap/bootstrap.css" rel="stylesheet" type="text/css" >
  <link href="./vendor/bootstrap/bootstrap-datetimepicker.css" rel="stylesheet" type="text/css" >
  <!-- liên kết datatable css -->
  <link href="./vendor/datatable/dataTables.min.css" rel="stylesheet" type="text/css" />
  <!-- liên kết font css -->
  <link rel="stylesheet" href="./vendor/fontawesome/css/all.min.css">
  <link href="./vendor/datatable/buttons.dataTables.min.css" rel="stylesheet" type="text/css" />
  <link href="./vendor/datatable/select.dataTables.css" rel="stylesheet" type="text/css" />

    <style>
        a{color: black;}
        img{max-width: 100%;}
        .para{padding-top: 3.6em;}
        i{
          cursor: pointer;
        }
        .users:hover .user{
              display: block;
            }

        .user{
      display: none;
      position:absolute;
      float: right;
      z-index: 1;
        right: 2%; 
        top: 30px;
        
      background-color: white;
      padding: 5px;
      color:#046b7b; 
      width: 15rem;
      box-shadow: rgba(0, 0, 0, 0.05) 2px 3px 3px;
      }
        @media screen and (max-width: 768px) {
          .user{
          display: none;
          position:absolute;
          float: left;
          z-index: 10;
            right: 0%; 
            top: -0.5em;
            width: 15rem;
          }

    }
    th.description {
	  vertical-align: middle;
	}
	td.description {
	  vertical-align: middle;
	}
  .donut-inner {
   margin-top: -60%;
   margin-bottom: 60%;
}
.donut-inner h5 {
   margin-bottom: 5px;
   margin-top: 0;
   color: red;
}
.donut-inner span {
   font-size: 14px;
}
    </style>
</head>

<body class="para">
<div class="fixed-CENTER">
       <nav class="navbar fixed-top navbar-expand-lg scrolling-navbar border-drt"  style="border-bottom: 4px solid #d5d5d5;font-size:16px;color:Blue; font-weight: 100;">
          <div class="container-fluid">
            <a class="navbar-brand waves-effect" href="./index.php" style = "text-align:center;">
              <img src="vendor/img/logo2.png" style="height: 50px;">
            </a>
                        
            <h2>                
              <span class="slogan-sub">MATERIAL REPORT.</span>
            </h2>
           
          </div>
      </nav>
 </div>
	<div class="container-fluid" style="margin-top: 0.5em;">
		<div class="row">
      <div class="mg0 left-filter_monitor" id="left-filter">
          
          <div class="panel panel-primary">
            <div class="panel-heading">
              <i class="fas fa-filter i-right"></i>Filters
            </div>
            <div class="filters-plan-bot_monitor">
             <label>Direct :</label>
               <select id="direct" class="form-control form-control-sm custom-select">
                  <option value="1F-KITTING">1F-KITTING</option>
                  <option value="2F-OFFICE">2F-OFFICE</option>
                  <option value="2F-UB-MOLD">2F-UB-MOLD</option>
                  <option value="2F-AUTO" selected>2F-AUTO</option>
                </select>
            <label>Date :</label>
              <input type="date" id="dTime" class="form-control form-control-sm" value="<?php 
                echo date('Y-m-d'); ?>">

              <div class="input-group input-group-sm mb-3" style="margin-top:1em;">
            <div class = "input-group-prepend" >
              <label class="input-group-text">Exp Materials :</label>
            </div>
            <select id="exp" class="form-control form-control-sm  custom-select">
              <option value="" selected></option>   
              <option value="1" selected>Exp</option>
            </select>
            </div>
            </div>
          </div>
          <button class="btn btn-primary btn-sm appy-filter form-control" id="apply"><i class="fa fa-check i-right"></i>Apply</button>
          
          <button class="btn btn-light btn-sm appy-filter form-control" id="sub_pause"><i class="fa fa-pause i-right"></i>Pause</button>
        </div>
        <div class="body-right_monitor">

          <div class="panel-body-content" id="show">
          </div>

        </div>
			</div>
		</div>
	</div>
<?php
include('footer.php');
?>

<script type="text/javascript">

	$(document).ready(function(){
      let dTime = $('#dTime').val().toUpperCase().trim();
      let exp = $('#exp').val().toUpperCase().trim();
      let direct = $('#direct').val().toUpperCase().trim();
      $.post('view/viewMaterialByDirect',{dTime:dTime,direct:direct,exp:exp}, function(data) {
        $("#show").html(data);
      });

      $('#apply').click(function(){
        let dTime = $('#dTime').val().toUpperCase().trim();
        let exp = $('#exp').val().toUpperCase().trim();
        let direct = $('#direct').val().toUpperCase().trim();
        $.post('view/viewMaterialByDirect',{dTime:dTime,direct:direct,exp:exp}, function(data) {
          $("#show").html(data);
        });
      });
	});
</script>
