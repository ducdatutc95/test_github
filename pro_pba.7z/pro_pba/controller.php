<?php
include ('model.php');
date_default_timezone_set("Asia/Ho_Chi_Minh");
class cEms {
    public function cLogin($id,$pass){
        $data = new mEms();
        $result = $data->mLogin($id,$pass);
        if ($result) {
			$sTime = date("Y-m-d h:i:s");
			$token = $result->id.$sTime;
			setcookie('token', md5($token),time() + 7*24*3600);
			$data->mSetToken($token,$id);
			if (isset($_SESSION['logError'])) {
				    unset($_SESSION['logError']);
				}
			header('Location:index');
			exit();

		}else {
			echo '<script>alert("Sai Thông Tin Tài Khoản");</script>';
		}
    }

    public function cGetUser($token){
        $data = new mEms();
        $result = $data->mGetUser($token);
        return $result;
    }
    public function cChangePass($id,$pass,$newpass,$cfpass){
        $data = new mEms();
        $result = $data->mLogin($id,$pass);
        if ($result) {
            if ($newpass == $cfpass) {
                $res = $data->mChangePass($id,$newpass);
                // echo $res;
                echo '<script>alert("Change pass success!");</script>';
                header('Location:index');
                exit();
            } else {
                echo '<script>alert("New pass and Pass confirm do not match");</script>';
                // header('Location:changePass');
                // exit();
            }
        }else {
            echo '<script>alert("Wrong old password");</script>';
            // header('Location:changePass');
            // exit();
            
        }
    }

    // end user

    public function cGetListModel(){
        $data = new mEms();
        $result = $data->mGetListModel();
        return $result;
    }

    public function cGetHisCode(){
        $data = new mEms();
        $result = $data->mGetHisCode();
        return $result;
    }

    public function cGetHisLine(){
        $data = new mEms();
        $result = $data->mGetHisLine();
        return $result;
    }
}
?>
