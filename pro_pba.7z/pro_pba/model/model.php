<?php
include('database.php');
class mEms extends database
{
    public function mGetUser($token)
    {
        $sql = "SELECT * FROM user WHERE token = '$token'";
        $this->setQuery($sql);
        return $this->loadRow(array());
    }

    public function mGetStock($qr, $line_filter, $model_filter, $diffTime, $limit)
    {
        $arr = array();
        if ($qr != '') $arr[] = "code = '$qr'";
        if ($line_filter != '') $arr[] = "line = '$line_filter'";
        if ($diffTime != 0) $arr[] = "TIMESTAMPDIFF(HOUR,lTime, NOW()) > '$diffTime'";
        $l = '';
        if ($limit > 0) {
            $l = " LIMIT " . $limit;
        }
        $queryArr = implode(" AND ", $arr);
        $sql = "SELECT * FROM pba_line";
        if (count($arr) > 0) $sql = $sql . "  WHERE " . $queryArr;
        $sql = $sql . " ORDER BY sTime DESC" . $l;
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetInvent($line_filter, $limit)
    {
        $arr = array();
        if ($line_filter != '') $arr[] = "line = '$line_filter'";
        $l = '';
        if ($limit > 0) {
            $l = " LIMIT " . $limit;
        }
        $queryArr = implode(" AND ", $arr);
        $sql = "SELECT DISTINCT id,line,author,sTime,status FROM pba_check";
        if (count($arr) > 0) $sql = $sql . "  WHERE " . $queryArr;
        $sql = $sql . " ORDER BY sTime DESC" . $l;
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetPlan($line_filter, $model_filter, $dateStart, $dateEnd)
    {
        $arr = array();
        if ($line_filter != '') $arr[] = "line = '$line_filter'";
        if ($model_filter != '') $arr[] = "model_code = '$model_filter'";
        if ($dateStart != '' && $dateEnd != '') $arr[] = "sDate BETWEEN '$dateStart' AND '$dateEnd'";
        if ($dateStart != '' && $dateEnd == '') $arr[] = "sDate >= '$dateStart'";
        if ($dateStart == '' && $dateEnd != '') $arr[] = "sDate <= '$dateEnd'";
        $queryArr = implode(" AND ", $arr);
        $sql = "SELECT * FROM pba_pro_plan";
        if (count($arr) > 0) $sql = $sql . "  WHERE " . $queryArr;

        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetPlanFromMes($line_filter, $model_filter, $dateStart, $dateEnd)
    {
        $arr = array();
        if ($line_filter != '') $arr[] = "line = '$line_filter'";
        if ($model_filter != '') $arr[] = "model = '$model_filter'";
        if ($dateStart != '' && $dateEnd != '') $arr[] = "sDate BETWEEN '$dateStart' AND '$dateEnd'";
        if ($dateStart != '' && $dateEnd == '') $arr[] = "sDate >= '$dateStart'";
        if ($dateStart == '' && $dateEnd != '') $arr[] = "sDate <= '$dateEnd'";
        $queryArr = implode(" AND ", $arr);
        $sql = "SELECT id_plan as id_plan,line as line,model as model,basic as basic,code as code, qty as qty,sDate as sDate, shift FROM pba_bom_real WHERE point =1";
        if (count($arr) > 0) $sql = $sql . " AND " . $queryArr;
        $sql .= " GROUP BY id_plan";
        // echo $sql;
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetPlanDetailFromMes($id_plan)
    {
        $sql = "SELECT id_plan as id_plan,line as line,model as model,basic as basic,code as code, qty as qty,sDate as sDate, point, shift FROM pba_bom_real WHERE point <> 0 AND id_plan='$id_plan'";
        // echo $sql;
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetModelUnique($line_filter, $dateStart, $dateEnd)
    {
        $arr = array();
        if ($line_filter != '') $arr[] = "line = '$line_filter'";
        if ($dateStart != '' && $dateEnd != '') $arr[] = "sDate BETWEEN '$dateStart' AND '$dateEnd'";
        if ($dateStart != '' && $dateEnd == '') $arr[] = "sDate >= '$dateStart'";
        if ($dateStart == '' && $dateEnd != '') $arr[] = "sDate <= '$dateEnd'";
        $queryArr = implode(" AND ", $arr);
        $sql = "SELECT DISTINCT basic as basic, id_plan, sDate, shift FROM pba_bom_real WHERE point =1";
        if (count($arr) > 0) $sql = $sql . " AND " . $queryArr;
        $sql .= " GROUP BY id_plan";
        // echo $sql;
        $this->setQuery($sql);
        return $this->loadAllRows();
    }
    public function mGetDetailPlanFromMes($line_filter, $shift, $sDate)
    {
        $arr = array();

        $sql = "SELECT * FROM pba_bom_real WHERE shift = '$shift' AND sDate = '$sDate'";
        if ($line_filter != '') {
            $sql .= " AND line = '$line_filter'";
        }
        $this->setQuery($sql);
        return $this->loadAllRows();
    }
    public function mGetQtyProd($line_filter, $model_filter)
    {
        $arr = array();
        if ($line_filter != '') $arr[] = "line = '$line_filter'";
        if ($model_filter != '') $arr[] = "model_code = '$model_filter'";
        $queryArr = implode(" AND ", $arr);
        $sql = "SELECT id_plan, SUM(qty_out) as qty_out FROM pba_pro_plan ";
        if (count($arr) > 0) $sql = $sql . "  WHERE " . $queryArr;
        $sql .= " GROUP BY id_plan";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }
    public function mGetTotalLine($line_filter)
    {
        if ($line_filter == '') $line_filter = '01';
        $sql = "SELECT * FROM pba_total_line WHERE line = '$line_filter' GROUP BY line,code";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetRemainLine($line_filter)
    {
        if ($line_filter == '') $line_filter = '01';
        $sql = "SELECT pba_pro_plan.line as line,
                pba_pro_plan.model_code as model,
                SUM((pba_pro_plan.qty-pba_pro_plan.qty_out)*pba_pro_bom.qty) as remain, 
                pba_pro_bom.code as code FROM pba_pro_bom
                LEFT JOIN pba_pro_plan ON pba_pro_plan.model_code = pba_pro_bom.model_code WHERE pba_pro_plan.line = '$line_filter'
                GROUP BY pba_pro_bom.code";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }
    public function mGetZin($dateStart, $dateEnd)
    {
        $arr = array();
        if ($dateStart != '' && $dateEnd != '') $arr[] = "sTime BETWEEN '$dateStart' AND '$dateEnd'";
        if ($dateStart != '' && $dateEnd == '') $arr[] = "sTime >= '$dateStart'";
        if ($dateStart == '' && $dateEnd != '') $arr[] = "sTime <= '$dateEnd'";
        $queryArr = implode(" AND ", $arr);
        $sql = "SELECT * FROM set_pro_zin";
        if (count($arr) > 0) $sql = $sql . "  WHERE " . $queryArr;
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetStockMaterial($line_filter, $exp)
    {
        $arr = array();
        if ($exp != '') $arr[] = " pba_pro_bom.type <> ''";
        if ($line_filter != '') $arr[] = " set_pro_material.direct = '$line_filter'";
        $sql = "SELECT set_pro_material.code as code, set_pro_material.direct as direct,set_pro_material.status as status,set_pro_material.qty as qty, pba_pro_bom.type as type FROM set_pro_material LEFT JOIN pba_pro_bom ON set_pro_material.code = pba_pro_bom.code ";
        $queryArr = implode(" AND ", $arr);
        if (count($arr) > 0) $sql = $sql . "  WHERE " . $queryArr;
        $this->setQuery($sql);
        return $this->loadAllRows();
    }
    public function mGetHisStock($qr, $line_filter, $model_filter, $dateStart, $dateEnd, $listFilterProcess)
    {
        $arr = array();
        if ($qr != '') $arr[] = "qr = '$qr'";
        if ($line_filter != '') $arr[] = "sub_lct = '$line_filter'";
        if ($listFilterProcess != '') $arr[] = "lct REGEXP '$listFilterProcess'";
        if ($model_filter != '') $arr[] = "model = '$model_filter'";

        if ($dateStart != '' && $dateEnd != '') $arr[] = "sTime BETWEEN '$dateStart' AND '$dateEnd'";
        if ($dateStart != '' && $dateEnd == '') $arr[] = "sTime >= '$dateStart'";
        if ($dateStart == '' && $dateEnd != '') $arr[] = "sTime <= '$dateEnd'";
        $queryArr = implode(" AND ", $arr);
        $sql = "SELECT * FROM set_pro_his";
        if (count($arr) > 0) $sql = $sql . "  WHERE " . $queryArr;

        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetLossTime($line_filter, $dateStart, $dateEnd)
    {
        $arr = array();
        if ($line_filter != '') $arr[] = "sub_lct = '$line_filter'";
        if ($dateStart != '' && $dateEnd != '') $arr[] = "sTime BETWEEN '$dateStart' AND '$dateEnd'";
        if ($dateStart != '' && $dateEnd == '') $arr[] = "sTime >= '$dateStart'";
        if ($dateStart == '' && $dateEnd != '') $arr[] = "sTime <= '$dateEnd'";
        $queryArr = implode(" AND ", $arr);
        $sql = "SELECT * FROM set_pro_losstime";
        if (count($arr) > 0) $sql = $sql . "  WHERE " . $queryArr;
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetCauseDetail($id)
    {

        $sql = "SELECT * FROM set_pro_losstime WHERE id = '$id'";

        $this->setQuery($sql);
        return $this->loadRow();
    }

    public function mGetBomDetail($id_plan)
    {
        $sql = "SELECT code,qty/(SELECT MIN(qty) FROM pba_bom_real WHERE id_plan = '$id_plan') as qty FROM pba_bom_real WHERE id_plan = '$id_plan'";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetPlanDetail($id_plan)
    {
        $sql = "SELECT * FROM pba_bom_real WHERE id_plan = '$id_plan'";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetBom($model_filter, $listFilterProcess)
    {
        $arr = array();
        if ($listFilterProcess != '') $arr[] = "process REGEXP '$listFilterProcess'";
        if ($model_filter != '') $arr[] = "model_code = '$model_filter'";
        if (count($arr) > 0) $queryArr = "Where " . implode(" AND ", $arr);
        $sql = "SELECT model_basic,model_code,process,Count(code) as code FROM pba_pro_bom " . $queryArr . " GROUP BY model_code,process";

        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetLct()
    {
        $sql = "SELECT * FROM set_pro_rp_lct";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetLcts()
    {
        $sql = "SELECT DISTINCT lct FROM set_pro_rp_lct ORDER BY lct ASC";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetCountbyLct()
    {
        $sql = "SELECT sub_lct,err_name, COUNT(qr) as qty, TIMESTAMPDIFF(DAY,lTime,NOW()) as dif FROMpba_lineWHERE lct= 'REPAIR' GROUP BY sub_lct, err_name, dif ORDER BY dif DESC,err_name ASC";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetQrByLct($lct)
    {
        $sql = "SELECT * FROMpba_lineWHERE lct= 'REPAIR' AND sub_lct = '$lct'";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }
    public function mGetDataCheck()
    {
        $sql = "SELECT * FROM st_main";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetDataLine()
    {
        $sql = "SELECT did as Did, code as SubCode, qty as Qty, line FROM pba_line";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mDelStockMM($did)
    {
        $sql = "DELETE FROM st_main WHERE Did = '$did'";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mDelLine($did)
    {
        $sql = "DELETE FROM pba_line WHERE did = '$did'";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mAddStockMM($did, $code, $sTime, $qty, $line, $author)
    {
        $co = $code . "xxxxxxxx00000" . $qty;
        $sql = "INSERT INTO st_main (Did,Code,SubCode,Qty,sTime) VALUES ('$did','$co', '$code', '$qty', '$sTime')";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mAddHisLine($did, $code, $sTime, $qty, $line, $author, $status)
    {
        $sql = "INSERT INTO pba_line_his (did,code,qty,line,author,sTime,status) VALUES ('$did', '$code', '$qty', '$line', '$author', '$sTime', '$status')";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mAddLine($did, $code, $sTime, $qty, $line, $author)
    {
        $sql = "INSERT INTO pba_line (did,code,qty,line,author,sTime) VALUES ('$did', '$code', '$qty', '$line', '$author', '$sTime')";
        $this->setQuery($sql);
        $this->execute(array());
    }
    public function mUpQtyPlan($line, $code, $qty)
    {
        $sql = "INSERT INTO pba_total_line (line,code,qty_need) values ('$line','$code','$qty') ON DUPLICATE KEY UPDATE qty_need = qty_need + '$qty'";
        $this->setQuery($sql);
        $this->execute(array());
    }
    public function mUpQtyLine($line, $code, $qty)
    {
        $sql = "INSERT INTO pba_total_line (line,code,qty) values ('$line','$code','$qty') ON DUPLICATE KEY UPDATE qty = qty + '$qty'";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mDownQtyLine($line, $code, $qty)
    {
        $sql = "INSERT INTO pba_total_line (line,code,qty) values ('$line','$code','-$qty') ON DUPLICATE KEY UPDATE qty = qty - '$qty'";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mDownCfProd($line, $code, $qty)
    {
        $sql = "INSERT INTO pba_total_line (line,code,qty) values ('$line','$code','-$qty') ON DUPLICATE KEY UPDATE qty = qty - '$qty', qty_need = qty_need - '$qty'";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mGetQtyProcByModel($dTime, $direct)
    {
        $sql = "SELECT model, direct,shift, SUM(qty) as qty,mc FROM set_pro_production_proc WHERE direct='$direct' AND dTime = '$dTime' GROUP BY model,shift,mc";
        // echo $sql;
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mAddQtyProductionbyModel($direct, $dTime, $mc, $shift, $model, $qty, $author)
    {
        $sql = "INSERT INTO set_pro_production_proc (direct, dTime, mc, shift,model, qty, author) VALUES ('$direct','$dTime','$mc','$shift','$model','$qty','$author')";
        $this->setQuery($sql);
        $this->execute(array());
    }
    public function mInQr($zin, $qr, $model, $lct, $sub_lct, $author, $status)
    {
        $sql = "INSERT INTO pba_line(zin, qr, model, lct, sub_lct,author,status) VALUES ('$zin','$qr', '$model', '$lct', '$sub_lct', '$author','$status')";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mExchange($qr, $lct, $sub_lct, $author, $stime, $err_name)
    {
        $sql = "UPDATEpba_lineSET lct ='$lct', sub_lct = '$sub_lct', author='$author',lTime='$stime', err_name = '$err_name' WHERE qr = '$qr'";
        $this->setQuery($sql);
        $this->execute(array());
    }
    public function mCheckQr($qr, $ltime, $author)
    {
        $sql = "UPDATEpba_lineSET ltime ='$ltime', author='$author' WHERE qr = '$qr'";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mOut($qr)
    {
        $sql = "DELETE FROMpba_lineWHERE qr = '$qr'";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mDelCause($id)
    {
        $sql = "DELETE FROM set_pro_losstime WHERE id = '$id'";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mDelQrbyZin($id)
    {
        $sql = "DELETE FROMpba_lineWHERE zin = '$id'";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mCancelZin($id)
    {
        $sql = "UPDATE set_pro_zin SET status =3 WHERE zin = '$id'";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mUpdateOutPLan($id_plan, $line, $model_code, $qty_code)
    {
        $sql = "INSERT INTO pba_pro_plan (id_plan,line,model_code,qty_out) VALUES ('$id_plan','$line','$model_code','$qty_code')";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mAddHis($zin, $qr, $model, $lct, $sub_lct, $author, $direct, $err_name, $status)
    {
        $sql = "INSERT INTO set_pro_his(zin,qr, model, lct, sub_lct,author, direct,err_name,status) VALUES ('$zin','$qr', '$model', '$lct', '$sub_lct', '$author', '$direct', '$err_name','$status')";
        $this->setQuery($sql);
        $this->execute(array());
    }
    public function mAddZin($zin, $qty, $author, $model, $sub_lct)
    {
        $sql = "INSERT INTO set_pro_zin(zin, qty, author, model,sub_lct) VALUES ('$zin','$qty','$author','$model','$sub_lct')";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mGetQr($qr)
    {
        $sql = "SELECT qr,zin,model,lct,sub_lct,err_name,status,author,sTime,lTime, TIMESTAMPDIFF(HOUR,lTime,NOW()) as dif FROMpba_lineWHERE qr = '$qr' AND status = 1";
        $this->setQuery($sql);
        return $this->loadRow();
    }
    public function mAddCause($line, $name, $detail, $start_time, $stop_time, $img, $author)
    {
        $sql = "INSERT INTO set_pro_losstime(line, name, detail, startTime,stopTime, img, author) VALUES ('$line', '$name', '$detail', '$start_time', '$stop_time', '$img', '$author')";
        $this->setQuery($sql);
        $this->execute(array());
    }
    public function mConfirmZin($zin, $line, $ltime, $author)
    {
        $sql = "UPDATE set_pro_zin SET status =2,sub_lct = '$line' WHERE zin = '$zin'";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mConfirmZinHis($zin, $line, $ltime, $author)
    {
        $sql = "UPDATE set_pro_his SET status =1,sub_lct = '$line' WHERE zin = '$zin'";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mConfirmZinP($zin, $line, $ltime, $author)
    {
        $sql = "UPDATEpba_lineSET status =1,sub_lct = '$line' WHERE zin = '$zin'";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mReturnZin($zin, $line, $ltime, $author)
    {
        $sql = "UPDATE set_pro_zin SET status = 3,sub_lct = '$line' WHERE zin = '$zin'";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mReturnZinHis($zin, $line, $ltime, $author)
    {
        $sql = "UPDATE set_pro_his SET status =2,sub_lct = '$line' WHERE zin = '$zin'";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mReturnZinP($zin, $line, $ltime, $author)
    {
        $sql = "DELETE FROMpba_lineWHERE zin = '$zin'";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mEditCause($id, $line, $name, $detail, $start_time, $stop_time, $img, $author)
    {
        if ($img) {
            $subSql = " ,img = '$img'";
        } else {
            $subSql = '';
        }
        $sql = "UPDATE set_pro_losstime SET line ='$line', name = '$name', detail='$detail', starttime='$start_time', stoptime = '$stop_time', author = '$author' WHERE id = '$id'";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mGetListModel()
    {
        $sql = "SELECT DISTINCT model FROM pba_pro_bom";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }
    public function  mGetListCode()
    {
        $sql = "SELECT DISTINCT code FROM pba_bom_real";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetDetailZin($arr)
    {
        $sql = "SELECT * FROM set_pro_his where zin IN $arr";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetListProcess()
    {
        $sql = "SELECT DISTINCT process FROM pba_pro_bom";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mAddPlan($line, $model_code, $sDate, $qty, $author)
    {
        $sql = "INSERT INTO pba_pro_plan(line, model_code, sDate,qty, author) VALUES ('$line', '$model_code', '$sDate', '$qty', '$author')";
        $this->setQuery($sql);
        $this->execute(array());
        return $this->getLastId();
    }
    public function mAddBomReal($id, $line, $model_code, $qty)
    {
        $sql = "INSERT INTO pba_bom_real(id_plan,line, model, code, qty) SELECT '$id','$line',pba_pro_bom.model, pba_pro_bom.code,pba_pro_bom.qty*'$qty' FROM pba_pro_bom WHERE pba_pro_bom.model = '$model_code'";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mEditPlan($id, $line, $model_code, $sDate, $qty, $author)
    {
        $sql = "UPDATE pba_pro_plan SET line ='$line', model_code = '$model_code', sDate='$sDate', qty = '$qty', author = '$author' WHERE id = '$id'";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mChangeLine($id, $line)
    {
        $sql = "UPDATE pba_bom_real SET line ='$line' WHERE id_plan = '$id'";
        // echo $sql;
        $this->setQuery($sql);
        $this->execute(array());
    }
    public function mChangeCode($id, $code_change)
    {
        $sql = "UPDATE pba_bom_real SET code ='$code_change' WHERE id = '$id'";
        echo $sql;
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mDelPlan($id)
    {
        $sql = "DELETE FROM pba_pro_plan WHERE id = '$id'";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mDelLct($id)
    {
        $sql = "DELETE FROM set_pro_rp_lct WHERE id = '$id'";
        $this->setQuery($sql);
        $this->execute(array());
    }


    public function mDelBom()
    {
        $sql = "DELETE  FROM pba_pro_bom";
        $this->setQuery($sql);
        $this->execute(array());
    }
    public function mUpBom($basic, $model_code, $process, $code, $desc, $qty, $author, $type)
    {
        $sql = "INSERT INTO pba_pro_bom(model_basic, model_code, process, code, detail ,qty, author, type) VALUES ('$basic', '$model_code', '$process', '$code', '$desc','$qty','$author', '$type')";
        $this->setQuery($sql);
        $this->execute(array());
    }
    public function mUpProMes($str)
    {
        $sql = "INSERT INTO pba_bom_real(id_plan, line, model, code, qty, point, basic, sDate, shift) VALUES $str";
        $this->setQuery($sql);
        $this->execute(array());
    }
    public function mDelProMes($sDate, $shift)
    {
        $sql = "DELETE FROM pba_bom_real WHERE sDate = '$sDate' AND shift = '$shift'";
        $this->setQuery($sql);
        $this->execute(array());
    }
    public function mAddLct($lct, $err_name)
    {
        $sql = "INSERT INTO set_pro_rp_lct(lct, err_name) VALUES ('$lct', '$err_name')";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mGetDataOut($date, $dateE)
    {
        $sql = "SELECT * FROM set_pro_his WHERE lct = 'OUT' AND sTime BETWEEN '$date' AND '$dateE' AND status = 1 ";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }
    public function mGetDataIn($to)
    {
        $sql = "SELECT * FROM set_pro_his WHERE direct = 'INOUT' AND lct = 'LINE' AND DATE(sTime) = '$to' AND status = 1";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetMaterialByPlan($id)
    {
        $sql = "SELECT pba_pro_plan.id as id_plan,pba_pro_plan.line as direct, pba_pro_plan.model_code as model_code, pba_pro_plan.qty as qty_plan,pba_pro_bom.model_basic as basic, pba_pro_bom.code as code, pba_pro_bom.type as type, (pba_pro_bom.qty*pba_pro_plan.qty) as qty_code , m.qty_in FROM pba_pro_bom 
                LEFT JOIN pba_pro_plan ON pba_pro_plan.model_code = pba_pro_bom.model_code AND pba_pro_plan.process = pba_pro_bom.process
                LEFT JOIN (SELECT code, SUM(qty) AS qty_in FROM set_pro_material_history WHERE id_plan = '$id' AND type = 'IN'  GROUP BY code) AS m ON pba_pro_bom.code = m.code
                WHERE pba_pro_plan.id = '$id' GROUP BY code ORDER BY type DESC,code ASC";
        // echo $sql;
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetCountImByPlan($id)
    {
        $sql = "SELECT COUNT(DISTINCT id_in) FROM set_pro_material_history WHERE type = 'IN' AND note = 'Im By Plan' AND id_plan = '$id';";
        // echo $sql;
        $this->setQuery($sql);
        return $this->loadRecord();
    }


    public function mAddMaterialHistory($id_in, $id_plan, $direct, $model_code, $code, $qty, $author, $type, $note, $status)
    {
        $sql = "INSERT INTO set_pro_material_history(id_in, id_plan, direct, model_code, code ,qty, author, type, note, status) VALUES ('$id_in', '$id_plan', '$direct', '$model_code', '$code', '$qty', '$author', '$type', '$note', '$status')";
        // echo $sql;
        $this->setQuery($sql);
        $this->execute(array());
    }
    public function mImMaterial($direct, $code, $qty, $status)
    {
        $sql = "INSERT INTO set_pro_material(direct, code ,qty, status) VALUES ('$direct', '$code', '$qty', '$status') ON DUPLICATE KEY UPDATE qty = qty+'$qty'";
        $this->setQuery($sql);
        $this->execute(array());
    }
    public function mExMaterial($direct, $code, $qty, $status)
    {
        $sql = "INSERT INTO set_pro_material(direct, code ,qty, status) VALUES ('$direct', '$code', -'$qty', '$status') ON DUPLICATE KEY UPDATE qty = qty-'$qty'";

        $this->setQuery($sql);
        $this->execute(array());
    }
    public function mUpdateResultByPlan($id, $qty_code)
    {
        $sql = "UPDATE pba_pro_plan SET qty_out = qty_out+'$qty_code' WHERE id = '$id'";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mAddResultByPlan($id_plan, $direct, $model_code, $qty_code, $proc, $author)
    {
        $sql = "INSERT INTO set_pro_production(id_plan,direct,model_code,qty_code,proc,author) VALUES ('$id_plan','$direct', '$model_code', '$qty_code','$proc','$author')";

        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mGetListMaterial()
    {
        $sql = "SELECT DISTINCT code, detail FROM pba_pro_bom";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mCheckMaterialbyBom($model_code, $proc, $direct)
    {
        $sql = "SELECT pba_pro_bom.code AS code,pba_pro_bom.type AS type,pba_pro_bom.qty AS qty, pba_pro_bom.process AS process, (set_m.qty) AS remain_qty FROM pba_pro_bom LEFT JOIN (SELECT * FROM set_pro_material WHERE set_pro_material.status = 'OK' AND set_pro_material.direct = '$direct') AS set_m ON pba_pro_bom.code = set_m.code WHERE pba_pro_bom.model = '$model_code' AND pba_pro_bom.process = '$proc'";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }
    public function mGetPlanbyDay($dTime, $direct)
    {
        $sql = "SELECT SUM(pba_pro_plan.qty) as qty, pba_pro_plan.model_code, bom.model_basic as basic FROM pba_pro_plan LEFT JOIN (SELECT DISTINCT model, model_basic FROM pba_pro_bom) as bom ON pba_pro_plan.model_code = bom.model_code WHERE pba_pro_plan.sDate = '$dTime' AND pba_pro_plan.line = '$direct' GROUP BY pba_pro_plan.model_code";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetPlanbyDay1($line_filter, $model_filter, $dTime, $listFilterProcess)
    {
        $arr = array();
        if ($line_filter != '') $arr[] = "line = '$line_filter'";
        if ($listFilterProcess != '') $arr[] = "process REGEXP '$listFilterProcess'";
        if ($model_filter != '') $arr[] = "model_code = '$model_filter'";
        if ($dTime != '') $arr[] = "sDate = '$dTime'";
        $queryArr = implode(" AND ", $arr);
        $sql = "SELECT * FROM pba_pro_plan";
        if (count($arr) > 0) $sql = $sql . "  WHERE " . $queryArr;
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    // public function mGetTracking($direct,$dTime,$listFilterDirect){
    //     $sql = "SELECT DISTINCT code, detail FROM pba_pro_bom";
    //     $this->setQuery($sql);
    //     return $this->loadAllRows();
    // }
    public function mGetUbTrackingIn($listFilterDirect, $date, $dateE)
    {
        $arr = array();
        if ($listFilterDirect != '') $arr[] = "sub_lct REGEXP '$listFilterDirect'";
        if ($date != '')  $arr[] = "sTime BETWEEN '$date' AND '$dateE'";
        $queryArr = implode(" AND ", $arr);
        $sql = "SELECT DISTINCT qr, direct as status,lct,sub_lct as line,sTime FROM set_pro_his WHERE direct ='INPUT' AND status = 1";
        if (count($arr) > 0) $sql = $sql . "  AND " . $queryArr;
        $this->setQuery($sql);
        return $this->loadAllRows();
    }
    public function mGetUbTrackingOut($listFilterDirect, $date, $dateE)
    {
        $arr = array();
        if ($listFilterDirect != '') $arr[] = "direct REGEXP '$listFilterDirect'";
        if ($date != '')  $arr[] = "sTime BETWEEN '$date' AND '$dateE'";
        $queryArr = implode(" AND ", $arr);
        $sql = "SELECT DISTINCT qr, sub_lct as status, lct,direct as line,sTime FROM set_pro_his  WHERE lct ='OUT' AND status = 1";
        if (count($arr) > 0) $sql = $sql . "  AND " . $queryArr;
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetUbTrackingErr($listFilterDirect, $date, $dateE)
    {
        $arr = array();
        if ($listFilterDirect != '') $arr[] = "direct REGEXP '$listFilterDirect'";
        if ($date != '')  $arr[] = "sTime BETWEEN '$date' AND '$dateE'";
        $queryArr = implode(" AND ", $arr);
        $sql = "SELECT DISTINCT qr, sub_lct as status, lct,direct as line,sTime FROM set_pro_his  WHERE lct ='REPAIR' AND status = 1";
        if (count($arr) > 0) $sql = $sql . "  AND " . $queryArr;
        // echo $sql;
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetM3Date($sTime)
    {
        $sql = "SELECT DISTINCT Date(sTime) as sTime FROM set_pro_his  WHERE HOUR(sTime) >=8 AND DATE(sTime) <= '$sTime' AND sub_lct = 'REPAIR' AND status = 1 ORDER BY sTime DESC LIMIT 3";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }
    public function mGetDefectData($to, $listFilterDirect)
    {

        $sql = "SELECT DISTINCT qr, sub_lct as status, lct,direct as line,sTime, err_name FROM set_pro_his  WHERE lct ='REPAIR' AND sTime >= '$to' AND status = 1";
        if ($listFilterDirect != '') $sql .= " AND direct REGEXP '$listFilterDirect'";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetM3Defect($to)
    {
        $sql = "SELECT DISTINCT err_name FROM set_pro_his WHERE sTime>='$to' AND err_name <> ''";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }
    public function mGetMaterialByDirect($direct, $date, $dateE, $exp)
    {
        $subSql = '';
        $arr = array();

        if ($exp != '') $arr[] = " pba_pro_bom.type <> ''";
        if ($direct != '') $arr[] = " set_pro_material_history.direct = '$direct'";
        if ($direct != '') $subSql = " AND direct = '$direct'";
        $sql = "SELECT DISTINCT set_pro_material_history.code as code,set_pro_material_history.direct as direct, ex.qty as ex_qty, im.qty as im_qty,stock.qty as stock_qty FROM set_pro_material_history 
            LEFT JOIN pba_pro_bom ON set_pro_material_history.code = pba_pro_bom.code
            LEFT JOIN (SELECT SUM(qty) as qty, code, direct FROM set_pro_material_history where type = 'EX'" . $subSql . " AND sTime BETWEEN '$date' AND '$dateE' AND status='OK' GROUP BY code, direct) AS ex ON set_pro_material_history.code = ex.code AND set_pro_material_history.direct = ex.direct
            LEFT JOIN (SELECT SUM(qty) as qty, code, direct FROM set_pro_material_history where type = 'IN'" . $subSql . " AND sTime BETWEEN '$date' AND '$dateE'  AND status='OK' GROUP BY code, direct) AS im ON set_pro_material_history.code = im.code AND set_pro_material_history.direct = im.direct
            LEFT JOIN (SELECT SUM(qty) as qty, code, direct FROM set_pro_material where status='OK'" . $subSql . " GROUP BY code, direct) AS stock ON set_pro_material_history.code = stock.code  AND set_pro_material_history.direct = stock.direct
            WHERE set_pro_material_history.status='OK'";
        $queryArr = implode(" AND ", $arr);
        if (count($arr) > 0) $sql = $sql . "  AND " . $queryArr;
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetInOutMaterialByDirect($direct, $date, $dateE, $exp)
    {
        $subSql = '';
        $arr = array();

        if ($exp != '') $arr[] = " pba_pro_bom.type <> ''";
        if ($direct != '') $arr[] = " set_pro_material_history.direct = '$direct'";
        if ($direct != '') $subSql = " AND direct = '$direct'";
        $sql = "SELECT DISTINCT set_pro_material_history.code as code,set_pro_material_history.direct as direct, ex.qty as ex_qty, im.qty as im_qty FROM set_pro_material_history 
            LEFT JOIN pba_pro_bom ON set_pro_material_history.code = pba_pro_bom.code
            LEFT JOIN (SELECT SUM(qty) as qty, code, direct FROM set_pro_material_history where type = 'EX'" . $subSql . " AND sTime BETWEEN '$date' AND '$dateE' AND status='OK' GROUP BY code, direct) AS ex ON set_pro_material_history.code = ex.code AND set_pro_material_history.direct = ex.direct
            LEFT JOIN (SELECT SUM(qty) as qty, code, direct FROM set_pro_material_history where type = 'IN'" . $subSql . " AND sTime BETWEEN '$date' AND '$dateE'  AND status='OK' GROUP BY code, direct) AS im ON set_pro_material_history.code = im.code AND set_pro_material_history.direct = im.direct
            WHERE set_pro_material_history.status='OK'";
        $queryArr = implode(" AND ", $arr);

        if (count($arr) > 0) $sql = $sql . "  AND " . $queryArr;
        $this->setQuery($sql);
        return $this->loadAllRows();
    }


    public function mGetInfoLastCheck($direct)
    {
        $sql = "SELECT * FROM set_pro_check where direct = '$direct' ORDER BY id DESC LIMIT 1";
        $this->setQuery($sql);
        return $this->loadRow();
    }
    public function mGetInfoLastBynow($direct, $end)
    {
        $sql = "SELECT * FROM set_pro_check where direct = '$direct' AND end = '$end'";
        $this->setQuery($sql);
        return $this->loadRow();
    }

    public function mGetDetailCheckById($id)
    {
        $sql = "SELECT * FROM set_pro_check_detail where id = '$id'";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetInfoById($id)
    {
        $sql = "SELECT * FROM set_pro_check where id = '$id'";
        $this->setQuery($sql);
        return $this->loadRow();
    }

    public function mGetListCheckByDay($direct, $dTime)
    {
        $sql = "SELECT * FROM set_pro_check where direct = '$direct' AND sDate = '$dTime' ORDER BY id DESC";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetExMaterialByDirect($direct, $date, $dateE)
    {
        $sql = "SELECT SUM(qty) as qty, code,model_code,sTime FROM set_pro_material_history where type = 'EX' AND direct = '$direct' AND sTime BETWEEN '$date' AND '$dateE' GROUP BY code";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetInMaterialByDirect($direct, $date, $dateE)
    {
        $sql = "SELECT SUM(qty) as qty, code,model_code,sTime FROM set_pro_material_history where type = 'IN' AND direct = '$direct' AND sTime BETWEEN '$date' AND '$dateE' GROUP BY code";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetMaterialCheck($id, $exp)
    {
        $sub_sql = '';
        if ($exp != '') $sub_sql = " AND pba_pro_bom.type <> ''";
        $sql = "SELECT set_pro_check_detail.code as code, set_pro_check_detail.qty as qty, set_pro_check_detail.lost FROM set_pro_check_detail LEFT JOIN pba_pro_bom ON set_pro_check_detail.code = pba_pro_bom.code WHERE set_pro_check_detail.id = '$id'" . $sub_sql;
        $this->setQuery($sql);
        return $this->loadAllRows();
    }
    public function mGetZinPending()
    {
        $sql = "SELECT zin,qty FROM set_pro_zin where status = 1";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }
    public function mGetZinRecived()
    {
        $sql = "SELECT zin,qty FROM set_pro_zin where status = 2";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mAddMaterialCheck($id, $start, $end, $author, $direct)
    {
        $sql = "INSERT INTO set_pro_check(id,start,end,author,direct) VALUES ('$id','$start','$end','$author','$direct')";

        $this->setQuery($sql);
        $this->execute(array());
    }
    public function mUpStatusCheck($id)
    {
        $sql = "UPDATE set_pro_check SET status = 1 WHERE id = '$id'";

        $this->setQuery($sql);
        $this->execute(array());
    }
    public function mDelTotal($id)
    {
        $sql = "DELETE FROM pba_total_line WHERE line = '$id'";
        $this->setQuery($sql);
        $this->execute(array());
    }
    public function mAddTotal($line, $code, $qty_real)
    {
        $sql = "INSERT INTO pba_total_line(line,code,qty) VALUES ('$line','$code','$qty_real')";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mAddMaterialCheckDetail($id, $code, $qty, $realQty, $line, $note, $author, $sTime)
    {
        $sql = "INSERT INTO pba_check(line, code, qty, qty_real, id, sTime, author, note ) VALUES ('$line','$code','$qty','$realQty','$id','$sTime','$author','$sTime')";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mGetInventById($id)
    {
        $sql = "SELECT * FROM pba_check where id = '$id'";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetInLineHis($stime)
    {
        $sql = "SELECT DISTINCT did AS did FROM pba_line_his WHERE status IN ('1', 'Gắn Feeder') AND DATE(sTime) > '$stime'";
        $this->setQuery($sql);
        // echo $sql;
        return $this->loadAllRows();
    }

    public function mGetDidDivideCut($did)
    {
        $sql = "SELECT * FROM `pba_line_his` where did ='$did' AND status IN ('1', 'Gắn Feeder')  AND sTime = (SELECT MAX(sTime) from pba_line_his where did = '$did' AND status IN ('1', 'Gắn Feeder'))";
        $this->setQuery($sql);
        // echo $sql;
        return $this->loadAllRows();
    }

    // jkkhdfjksdhf
    public function mEditCutLineHis($root_id, $qty_remain, $author_cut, $stime_cut)
    {
        $sql = "UPDATE pba_line_his SET qty ='$qty_remain', number_of_cut = number_of_cut + 1, author_cut ='$author_cut', sTime_cut = '$stime_cut' WHERE id = '$root_id'";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mEditCutLine($root_did, $qty_remain)
    {
        $sql = "UPDATE pba_line SET qty ='$qty_remain' WHERE did = '$root_did'";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mAddCutHisRoot($root_did, $root_code, $root_qty, $root_line, $root_status, $root_number_of_cut, $root_author, $root_sTime, $author_cut, $stime_cut, $did_unique)
    {
        $sql = "INSERT INTO pba_line_cut_root(did, code, qty, line, status, number_of_cut, author_root, sTime_root, author_cut, sTime_cut, did_unique) VALUES ('$root_did', '$root_code', '$root_qty', '$root_line', '$root_status', '$root_number_of_cut', '$root_author', '$root_sTime', '$author_cut', '$stime_cut', '$did_unique')";

        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mAddCutStockMM($did, $code, $subcode, $qty, $direct, $status, $stime_cut)
    {
        $code = $subcode . "xxxxxxxx00000" . $qty;
        $sql = "INSERT INTO st_main (Did,Code,SubCode,Qty,Direct, Status, sTime) VALUES ('$did','$code', '$subcode', '$qty','$direct', '$status', '$stime_cut')";

        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mAddCutHisChild($did, $code, $subcode, $qty, $author_cut, $stime_cut, $did_unique)
    {
        $sql = "INSERT INTO pba_line_cut_child(did, code, qty, author, sTime, did_unique) VALUES ('$did', '$subcode', '$qty', '$author_cut', '$stime_cut', '$did_unique')";

        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mGetHisDivideCutFeeder($line, $code, $dateStart, $timeStart, $dateEnd, $timeEnd)
    {
        $arr = array();
        if ($line != '') $arr[] = "line = '$line'";
        if ($code != '') $arr[] = "code = '$code'";

        $arr[] = "sTime BETWEEN '$dateStart" . " " . $timeStart . ":00'" . " AND " . "'$dateEnd" . " " . $timeEnd . ":00'";
        $arr[] = "status = 'Gắn Feeder'";

        $queryArr = implode(" AND ", $arr);


        $sql = "SELECT * FROM `pba_line_his`";

        if (count($arr) > 0) {
            $sql .= " WHERE " . $queryArr;
        }

        $this->setQuery($sql);
        // echo $sql;
        return $this->loadAllRows();
    }

    public function mGetHisDivideCutLine($line, $code, $dateStart, $timeStart, $dateEnd, $timeEnd)
    {
        $arr = array();
        if ($line != '') $arr[] = "line = '$line'";
        if ($code != '') $arr[] = "code = '$code'";

        $arr[] = "sTime BETWEEN '$dateStart" . " " . $timeStart . ":00'" . " AND " . "'$dateEnd" . " " . $timeEnd . ":00'";

        $queryArr = implode(" AND ", $arr);

        $sql = "SELECT * FROM pba_line";

        if (count($arr) > 0) {
            $sql .= " WHERE " . $queryArr;
        }

        $this->setQuery($sql);
        // echo $sql;
        return $this->loadAllRows();
    }

    public function mAddLack($code_hm, $type, $code, $point, $line, $name_err, $state, $author, $stime)
    {
        $sql = "INSERT INTO pba_bom_lack(code_hm, type, code, point, line, name_err, state, author, stime) VALUES ('$code_hm', '$type', '$code', '$point', '$line', '$name_err', '$state', '$author', '$stime')";
        $this->setQuery($sql);

        // print_r($sql);

        $this->execute(array());
    }

    public function  mDelLack()
    {
        $sql = "DELETE FROM pba_bom_lack";
        $this->setQuery($sql);
        $this->execute(array());
    }

    public function mGetLack($line, $type)
    {
        $arr = array();
        if ($line != "") $arr[] = "line = '$line'";
        if ($type == 'SAMPLE') $arr[] = "type = 'SAMPLE'";
        if ($type == 'DIFF_SAMPLE') $arr[] = "type <> 'SAMPLE'";
        $queryArr = implode(" AND ", $arr);

        $sql = "SELECT * FROM pba_bom_lack ";

        if (count($arr) > 0) {
            $sql .= " WHERE " . $queryArr;
        }

        $sql .= " ORDER BY code_hm ";

        $this->setQuery($sql);
        return $this->loadAllRows();
    }
}


class mFuji extends database_fuji
{
    public function mGetDataFuji($line_filter)
    {
        $sql = "SELECT LINE, MODULE,SLOT,CODE,UPPER(MODEL_NAME) AS MODEL_NAME FROM FID WHERE MODEL_NAME <> ''";
        if ($line_filter != '') {
            $sql .= " AND LINE = '$line_filter'";
        }
        $this->setQuery($sql);
        return $this->loadAllRows();
    }
}

class mSet extends databaseSet
{
    public function mGetTracking($direct, $listFilterDirect, $date, $dateE)
    {
        $arr = array();
        if ($direct != '') $arr[] = "direct = '$direct'";
        if ($listFilterDirect != '') $arr[] = "line REGEXP '$listFilterDirect'";
        if ($date != '')  $arr[] = "tTime BETWEEN '$date' AND '$dateE'";
        $queryArr = implode(" AND ", $arr);
        $sql = "SELECT DISTINCT pn, direct,line, mc,tTime FROM set_pro_track WHERE res = 'PASS'";
        if (count($arr) > 0) $sql = $sql . "  AND " . $queryArr;
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetTrackingAll($direct, $listFilterDirect, $date, $dateE)
    {
        $arr = array();
        if ($direct != '') $arr[] = "direct = '$direct'";
        if ($listFilterDirect != '') $arr[] = "line REGEXP '$listFilterDirect'";
        if ($date != '')  $arr[] = "tTime BETWEEN '$date' AND '$dateE'";
        $queryArr = implode(" AND ", $arr);
        $sql = "SELECT pn, direct,line, mc,tTime,res FROM set_pro_track";
        if (count($arr) > 0) $sql = $sql . "  WHERE " . $queryArr;
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetErrTracking($direct, $listFilterDirect, $date, $dateE)
    {
        $arr = array();
        if ($direct != '') $arr[] = "direct = '$direct'";
        if ($listFilterDirect != '') $arr[] = "line REGEXP '$listFilterDirect'";
        if ($date != '')  $arr[] = "tTime BETWEEN '$date' AND '$dateE'";
        $queryArr = implode(" AND ", $arr);
        $sql = "SELECT pn, direct,line, mc,tTime,res,err_code FROM set_pro_track WHERE res = 'FAIL'";
        if (count($arr) > 0) $sql = $sql . "  AND " . $queryArr;
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetLineConfig($direct)
    {
        $arr = array();
        $sql = "SELECT * FROM set_pro_line_config WHERE direct = '$direct' ";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetModelLcd()
    {

        $sql = "SELECT t1.*
                        FROM set_pro_track t1
                        WHERE t1.tTime = (SELECT t2.tTime
                                         FROM set_pro_track t2
                                         WHERE t2.line = t1.line AND mc = 'LCD TEST'            
                                         ORDER BY t2.tTime DESC
                                         LIMIT 1)  AND t1.mc = 'LCD TEST'";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetLineByDirect($direct)
    {
        $sql = "SELECT DISTINCT line FROM set_pro_line_config WHERE direct = '$direct'";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }



    public function mAddLineTime($dTime, $direct, $line, $mc, $shift, $kg, $detail, $start_time, $stop_time, $diffTime, $type, $author)
    {
        $sql = "INSERT INTO set_pro_time(tDate, direct, line, proc, shift, kg, detail, start_time, end_time, diff, type, author) VALUES ('$dTime', '$direct', '$line', '$mc', '$shift', '$kg', '$detail', '$start_time', '$stop_time', '$diffTime', '$type', '$author')";
        $this->setQuery($sql);
        $this->execute(array());
    }
    public function mGetTimeLine($direct, $listFilterDirect, $date, $dateE)
    {
        $arr = array();
        if ($direct != '') $arr[] = "direct = '$direct'";
        if ($listFilterDirect != '') $arr[] = "line REGEXP '$listFilterDirect'";
        if ($date != '')  $arr[] = "start_time >= '$date' AND end_time <= '$dateE'";
        $queryArr = implode(" AND ", $arr);
        $sql = "SELECT * FROM set_pro_time";
        if (count($arr) > 0) $sql = $sql . "  WHERE " . $queryArr;
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetCal($direct, $line, $mc, $shift, $kg, $type, $date, $dateE)
    {
        $sql = "SELECT * FROM set_pro_time WHERE start_time >= '$date' AND end_time <= '$dateE' AND direct = '$direct' AND line = '$line' AND proc = '$mc' AND shift = '$shift' AND kg = '$kg' AND type = '$type'";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function mGetLostTime($direct, $line, $date, $dateE)
    {
        $sql = "SELECT * FROM set_pro_time WHERE start_time >= '$date' AND end_time <= '$dateE' AND direct = '$direct' AND line REGEXP '$line'";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }

    public function  mDelTimeLine($id)
    {
        $sql = "DELETE FROM set_pro_time where id = '$id'";
        $this->setQuery($sql);
        $this->execute(array());
    }


    public function mGetDataTracking($direct, $listFilterDirect, $date, $dateE)
    {
        $arr = array();
        if ($direct != '') $arr[] = "direct = '$direct'";
        if ($listFilterDirect != '') $arr[] = "line REGEXP '$listFilterDirect'";
        if ($date != '')  $arr[] = "tTime BETWEEN '$date' AND '$dateE'";
        $queryArr = implode(" AND ", $arr);
        $sql = "SELECT * FROM set_pro_track";
        if (count($arr) > 0) $sql = $sql . "  WHERE " . $queryArr;
        $this->setQuery($sql);
        return $this->loadAllRows();
    }
}

class mDat extends databaseDucDat
{
    public function mGetBom_DucDat()
    {
        $sql = "SELECT DISTINCT codes AS codes, code_hm, qtys, models FROM compare_bom__bom WHERE states = '1'";
        $this->setQuery($sql);
        return $this->loadAllRows();
    }
}
