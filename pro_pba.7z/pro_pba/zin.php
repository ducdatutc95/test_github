<?php
include('header.php');
$listModel = $data->cGetListModel();
$listProcess = $data->cGetListProcess();

?>

<body>
   <div class="container-fluid">
    <div class="row main-bar">
      <div class="location">
        <i class="fa fa-map-marker i-right" style="color:red;"> </i><span>PRODUCTION >> [SET] Production Plan</span>
        
      </div>
      <div class="bar-center">

      </div>
      <div class="option_box">
      </div>
    </div>
      <div class="row">
        <div class="mg0 left-filter" id="left-filter">
          <div class="panel panel-primary">
            <div class="panel-heading">
              <i class="fas fa-filter i-right"></i>Filters
            </div>
            <div class="panel-body filters-plan">
            <label>Direct :</label>
             <input type="text" id="line_filter" class="form-control form-control-sm" list="arrLine">
               <datalist id="arrLine">
                  <option value="1F-KITTING">1F-KITTING</option>
                  <option value="2F-OFFICE">2F-OFFICE</option>
                  <option value="2F-UB-MOLD">2F-UB-MOLD</option>
                  <option value="2F-AUTO">2F-AUTO</option>
              </datalist>
            <label>Model Code :</label>
             <input type="text" id="model_filter" class="form-control form-control-sm" list="arrModelCode">
               <datalist id="arrModelCode">
                <?php
                foreach ($listModel as $key) {
                  ?>
                      <option value="<?php echo $key->model_code; ?>"><?php echo $key->model_code; ?></option>
                  <?php
                  }
                ?>
              </datalist>
              <datalist id="arrProcess">
                <?php
                foreach ($listProcess as $key) {
                  ?>
                      <option value="<?php echo $key->process; ?>"><?php echo $key->process; ?></option>
                  <?php
                  }
                ?>
              </datalist>
            <label>Date Start :</label>
            <input type="date" id="dateStart" class="form-control form-control-sm" value="<?php 
            $start = strtotime("-30 Day");
            echo date('Y-m-d', $start); ?>">
           <label>Date End :</label>
           <input type="date" id="dateEnd" class="form-control form-control-sm" value="<?php 
            $start = strtotime("+1 Day");
            echo date('Y-m-d', $start); ?>">
            </div>
          </div>
          <div class="panel panel-primary resouce-rack">
            <div class="panel-heading">
              <i class="fas fa-database i-right"></i>Process
            </div>
            <div class="panel-body" id="resouce_stock"></div>
          </div>
          <button class="btn btn-primary btn-sm appy-filter form-control" id="apply"><i class="fa fa-check i-right"></i>Apply</button>
        </div>
        <div class="body-right mg0">
          <div class="mgl-5 data-content">
            <div class="panel panel-primary">
              <div class="panel-heading-content">
                <div class="title_box">
                  <i class="fas fa-info-circle i-right"></i>[SET] Production Input
                </div>
              </div>
              <div class="panel-body-content row" id="show">
              </div>
            </div>
          </div>
        </div>
      </div>
   </div>
   
<?php
include('footer.php');
?>
<script type="text/javascript">
  $(document).ready(function(){
    let dataProcess = [
      {"id":"CNC","text":"CNC"},
      {"id":"BATTERY","text":"BATTERY"},
      {"id":"BONDING","text":"BONDING"},
      {"id":"FRONT","text":"FRONT"},
      {"id":"UB MOLD","text":"UB MOLD"},
      {"id":"MOLDING","text":"MOLDING"},
      {"id":"MAIN","text":"MAIN"}
    ]
  
    listFilterP = dataProcess.map(e=>{
      return e.id
    });
    let treeStatus = new Tree('#resouce_stock', {
        data: [{ id: '-1', text: 'SET', children: dataProcess }],
        closeDepth: 3,
        loaded: function () {
            this.values = listFilterP

        },
        onChange: function () {
            listFilterP = this.values
        }
    })
      loadZin(listFilterP)
      $('#apply').click(function(){
        loadZin(listFilterP)
      });
  })
</script>

